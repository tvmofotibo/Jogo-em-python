package com.dogapocalypse.classes;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import me.libraryaddict.disguise.DisguiseAPI;
import me.libraryaddict.disguise.disguisetypes.DisguiseType;
import me.libraryaddict.disguise.disguisetypes.MobDisguise;
import me.libraryaddict.disguise.disguisetypes.watchers.WolfWatcher;
import org.bukkit.DyeColor;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

/**
 * DisguiseManager — gerencia o visual de cachorro para a classe DOG.
 *
 * Usa LibsDisguises para:
 *   - Fazer o jogador aparecer como um lobo para os outros
 *   - Aplicar cor de coleira baseada no poder absorvido
 *   - Mudar tamanho quando habilidade está ativa
 *
 * O jogador ainda joga normalmente — só a aparência muda.
 */
public class DisguiseManager {

    private final DogApocalypsePlugin plugin;
    private final Map<UUID, MobDisguise> disguises = new HashMap<>();
    private static boolean libsAvailable = false;

    public DisguiseManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        // Verifica se LibsDisguises está instalado
        try {
            Class.forName("me.libraryaddict.disguise.DisguiseAPI");
            libsAvailable = true;
            plugin.getLogger().info("[Disguise] LibsDisguises detectado — visual de cachorro ativado!");
        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("[Disguise] LibsDisguises NÃO encontrado. Visual de cachorro desativado.");
            plugin.getLogger().warning("[Disguise] Instale LibsDisguises em plugins/ para ativar.");
        }
    }

    /** Aplica o disfarce de lobo ao jogador Dog */
    public void aplicarDisguiseDog(Player player) {
        if (!libsAvailable) return;
        try {
            // Remove disfarce anterior
            removerDisguise(player);

            MobDisguise disguise = new MobDisguise(DisguiseType.WOLF);
            WolfWatcher watcher = (WolfWatcher) disguise.getWatcher();

            // Coleira vermelha por padrão (sem poder)
            watcher.setCollarColor(DyeColor.RED);
            // Lobo adulto grande
            watcher.setBaby(false);
            // Lobo domesticado (não agressivo visualmente)
            watcher.setTamed(true);

            // O jogador vê a si mesmo também
            DisguiseAPI.disguiseToAll(player, disguise);

            disguises.put(player.getUniqueId(), disguise);
            player.sendMessage(MessageUtil.color("&6🐺 &fVocê agora aparece como um &6lobo mutante&f!"));

        } catch (Exception e) {
            plugin.getLogger().warning("[Disguise] Erro ao aplicar disfarce: " + e.getMessage());
        }
    }

    /** Atualiza a cor da coleira baseado no poder absorvido */
    public void atualizarCorPoder(Player player, String powerId) {
        if (!libsAvailable) return;
        MobDisguise disguise = disguises.get(player.getUniqueId());
        if (disguise == null) return;

        try {
            WolfWatcher watcher = (WolfWatcher) disguise.getWatcher();
            DyeColor cor = switch (powerId) {
                case "blaze"      -> DyeColor.ORANGE;   // Fogo = laranja
                case "spider"     -> DyeColor.BLACK;    // Aranha = preto
                case "guardian"   -> DyeColor.CYAN;     // Guardião = ciano
                case "phantom"    -> DyeColor.PURPLE;   // Fantasma = roxo
                case "iron_golem" -> DyeColor.GRAY;     // Golem = cinza
                default           -> DyeColor.RED;
            };
            watcher.setCollarColor(cor);

            // Atualiza para todos os jogadores online
            DisguiseAPI.updateDisguise(disguise);

        } catch (Exception e) {
            plugin.getLogger().warning("[Disguise] Erro ao atualizar cor: " + e.getMessage());
        }
    }

    /** Efeito visual ao ativar habilidade — lobo fica com raiva (olhos vermelhos) */
    public void ativarModoHabilidade(Player player) {
        if (!libsAvailable) return;
        MobDisguise disguise = disguises.get(player.getUniqueId());
        if (disguise == null) return;

        try {
            WolfWatcher watcher = (WolfWatcher) disguise.getWatcher();
            watcher.setAngry(true); // olhos vermelhos
            DisguiseAPI.updateDisguise(disguise);

            // Volta ao normal após 3s
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                watcher.setAngry(false);
                DisguiseAPI.updateDisguise(disguise);
            }, 60L);
        } catch (Exception e) {
            plugin.getLogger().warning("[Disguise] Erro modo habilidade: " + e.getMessage());
        }
    }

    /** Remove o disfarce (ao trocar de classe) */
    public void removerDisguise(Player player) {
        if (!libsAvailable) return;
        try {
            if (DisguiseAPI.isDisguised(player)) {
                DisguiseAPI.undisguiseToAll(player);
            }
            disguises.remove(player.getUniqueId());
        } catch (Exception e) {
            plugin.getLogger().warning("[Disguise] Erro ao remover disfarce: " + e.getMessage());
        }
    }

    public static boolean isLibsAvailable() { return libsAvailable; }
}
