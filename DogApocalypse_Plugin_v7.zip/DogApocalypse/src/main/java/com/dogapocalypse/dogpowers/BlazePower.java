package com.dogapocalypse.dogpowers;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * Blaze Power — absorbed from Flame Blaze enemies.
 * Ability: Fire Breath — projects a cone of fire in the direction the player is looking.
 */
public class BlazePower implements DogPower {

    private final DogApocalypsePlugin plugin;
    private final int cooldownTicks;
    private final int durationTicks;
    private final double range;

    public BlazePower(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        this.cooldownTicks = plugin.getConfig().getInt("dog_powers.blaze.cooldown_ticks", 80);
        this.durationTicks = plugin.getConfig().getInt("dog_powers.blaze.duration_ticks", 200);
        this.range         = plugin.getConfig().getDouble("dog_powers.blaze.fire_breath_range", 8.0);
    }

    @Override
    public String getId() { return "blaze"; }

    @Override
    public String getDisplayName() { return "&6Blaze Power"; }

    @Override
    public String getDescription() { return "Breathe fire in a cone!"; }

    @Override
    public void activate(Player player) {
        // Visual: make player glow orange
        player.setFireTicks(0); // don't actually burn the player
        player.sendMessage(MessageUtil.color("&6[Blaze] &fYou can now breathe fire! Right-click your absorber."));
        player.getWorld().spawnParticle(Particle.FLAME, player.getLocation().add(0, 1, 0), 20, 0.3, 0.3, 0.3, 0.05);
    }

    @Override
    public boolean useAbility(Player player) {
        World world = player.getWorld();
        Location origin = player.getEyeLocation();
        Vector direction = origin.getDirection().normalize();

        // Get skill strength bonus
        int strengthLevel = plugin.getPlayerDataManager().get(player).getSkillLevel("ability_strength");
        double strengthBonus = 1.0 + (strengthLevel * plugin.getConfig()
                .getDouble("skill_tree.ability_strength.strength_bonus_per_level", 0.25));

        // Spawn fire breath particles along a cone
        for (double d = 0.5; d <= range; d += 0.5) {
            // Create a slight spread for the cone
            for (int spread = -1; spread <= 1; spread++) {
                Vector offset = direction.clone().rotateAroundY(Math.toRadians(spread * 12));
                Location particleLoc = origin.clone().add(offset.multiply(d));
                world.spawnParticle(Particle.FLAME, particleLoc, 3, 0.15, 0.15, 0.15, 0.02);
                world.spawnParticle(Particle.LAVA, particleLoc, 1, 0.1, 0.1, 0.1, 0);
            }
        }

        // Play fire sound
        world.playSound(origin, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);

        // Deal damage to entities in cone
        List<Entity> nearby = player.getNearbyEntities(range, range / 2, range);
        int hitCount = 0;
        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity target)) continue;
            if (target == player) continue;

            // Check if in cone (dot product)
            Vector toTarget = target.getLocation().subtract(origin).toVector().normalize();
            double dot = direction.dot(toTarget);
            if (dot < 0.5) continue; // ~60° cone

            double dist = target.getLocation().distance(origin);
            if (dist > range) continue;

            double damage = 5.0 * strengthBonus;
            target.setFireTicks(plugin.getConfig().getInt("dog_powers.blaze.fire_duration_ticks", 60));
            ((LivingEntity) target).damage(damage, player);
            hitCount++;
        }

        player.sendMessage(MessageUtil.color("&6[Fire Breath] &fIgnited &e" + hitCount + " &ftargets!"));
        return true;
    }

    @Override
    public void deactivate(Player player) {
        player.getWorld().spawnParticle(Particle.SMOKE_LARGE,
                player.getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3, 0.02);
    }

    @Override
    public int getCooldownTicks() { return cooldownTicks; }

    @Override
    public int getDurationTicks() { return durationTicks; }
}
