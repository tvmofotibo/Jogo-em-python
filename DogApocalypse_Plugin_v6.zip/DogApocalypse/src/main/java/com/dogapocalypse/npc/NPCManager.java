package com.dogapocalypse.npc;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

// ======================================================================
// NpcData — holds one NPC's definition
// ======================================================================

/**
 * Immutable data object describing a single NPC.
 */
class NpcData {

    enum NpcType { STORY, MERCHANT, GUIDE, QUEST }

    final String id;
    final String name;
    final NpcType type;
    final String[] dialogue;   // lines to display in sequence
    final String questTrigger; // optional — null if none
    final Location location;
    final EntityType entityType;

    NpcData(String id, String name, NpcType type, String[] dialogue,
            String questTrigger, Location location, EntityType entityType) {
        this.id          = id;
        this.name        = name;
        this.type        = type;
        this.dialogue    = dialogue;
        this.questTrigger = questTrigger;
        this.location    = location;
        this.entityType  = entityType;
    }
}

// ======================================================================
// NPCManager — spawns, tracks and handles NPC interactions
// ======================================================================

/**
 * NPCManager — manages all story and guide NPCs in the game world.
 *
 * NPCs are Villager/ArmorStand entities with custom names and metadata.
 * They are persistent: respawned on plugin enable if missing.
 * Interaction is via right-click (PlayerInteractEntityEvent).
 *
 * NPC Types:
 *  STORY    — unlocks story fragments, one-time dialogue
 *  GUIDE    — repeatable hints and lore
 *  MERCHANT — sells items (simplified: gives free starter kit refill)
 *  QUEST    — triggers a level start or special event
 */
public class NPCManager implements Listener {

    private final DogApocalypsePlugin plugin;

    /** NPC entity UUID -> NpcData */
    private final Map<UUID, NpcData> activeNpcs = new HashMap<>();

    /** NPC id -> spawned entity UUID */
    private final Map<String, UUID> npcIdMap = new HashMap<>();

    /** Player UUID -> NPC id -> whether they've heard this dialogue already */
    private final Map<UUID, Set<String>> heardDialogue = new HashMap<>();

    /** Cooldown per player to prevent spam-clicking */
    private final Map<UUID, Long> interactCooldown = new HashMap<>();

    public NPCManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    // ---------------------------------------------------------------
    // Spawn all NPCs for a given level world
    // ---------------------------------------------------------------

    public void spawnAllNpcs(World world) {
        plugin.getLogger().info("[NPC] Spawnando NPCs no mundo: " + world.getName());

        List<NpcData> npcs = buildNpcDefinitions(world);
        for (NpcData data : npcs) {
            spawnNpc(data);
        }

        plugin.getLogger().info("[NPC] " + npcs.size() + " NPCs spawnados.");
    }

    // ---------------------------------------------------------------
    // NPC definitions
    // ---------------------------------------------------------------

    private List<NpcData> buildNpcDefinitions(World w) {
        List<NpcData> list = new ArrayList<>();
        int B = 64; // BASE_Y

        // --- HUB / LOBBY NPCs ---
        list.add(new NpcData("ava_intro", "&f&lAva (Memória Fantasma)", NpcData.NpcType.STORY,
            new String[]{
                "&7&o\"...Onde estou? O que aconteceu com a cidade?\"",
                "&7&o\"Não consigo me lembrar de nada...\"",
                "&7&o\"Mas esse cachorro — de alguma forma, eu confio nele.\"",
                "&6[Fale com Rex para escolher sua classe e começar.]"
            },
            null,
            new Location(w, 8, B + 1, 4),
            EntityType.VILLAGER));

        list.add(new NpcData("rex_guide", "&6Rex (Seu Cachorro)", NpcData.NpcType.GUIDE,
            new String[]{
                "&e*Rex fareja o ar e rosna para as ruínas à frente*",
                "&7[Use &e/class choose dog&7] para jogar como Rex.",
                "&7[Use &e/class choose fighter&7] ou &e/class choose archer&7 para jogar como aliado de Ava.",
                "&7Forme um grupo: &e/coop invite <amigo>",
                "&7Depois inicie a jornada: &e/level start level_1"
            },
            null,
            new Location(w, 10, B + 1, 4),
            EntityType.WOLF));

        list.add(new NpcData("survivor_camp", "&eSobrevivente — Maria", NpcData.NpcType.STORY,
            new String[]{
                "&7\"Você sobreviveu à explosão? Achei que todos tinham morrido...\"",
                "&7\"Os gorilas do Laboratório 7 escaparam há três dias.\"",
                "&7\"Estão indo em direção à cidade antiga. Você precisa detê-los.\"",
                "&c\"Faça o que fizer — não se aproxime do Laboratório. Não é seguro.\""
            },
            null,
            new Location(w, 14, B + 1, 6),
            EntityType.VILLAGER));

        list.add(new NpcData("weapons_dealer", "&bNegociante de Armas — Viktor", NpcData.NpcType.MERCHANT,
            new String[]{
                "&7\"Ah, sobreviventes! Tenho equipamentos — bons equipamentos.\"",
                "&7\"Seu kit de classe foi recarregado. Não desperdice.\"",
                "&a[Kit recarregado! Verifique seu inventário.]"
            },
            "refresh_kit",
            new Location(w, 16, B + 1, 6),
            EntityType.PILLAGER));

        // --- LEVEL 1 CHECKPOINTS ---
        list.add(new NpcData("l1_cp1_npc", "&7Fantasma — Soldado Caído", NpcData.NpcType.STORY,
            new String[]{
                "&8&o\"Defendemos essa rua por três dias...\"",
                "&8&o\"Eles continuavam vindo. Dezenas deles.\"",
                "&8&o\"A fonte está mais ao norte. Nas ruínas do laboratório.\"",
                "&8&o\"Não deixe eles vencerem.\""
            },
            null,
            new Location(w, 9, B + 1, 92),
            EntityType.ZOMBIE));

        list.add(new NpcData("l1_cp2_npc", "&eSobrevivente — Velho Chen", NpcData.NpcType.GUIDE,
            new String[]{
                "&7\"Eu vi o que fizeram com os gorilas naquele laboratório.\"",
                "&7\"Injetaram algo brilhante, verde, neles.\"",
                "&7\"O maior — eles chamavam de APEX-G1.\"",
                "&7\"Ele absorvia as mutações de cada animal que enfrentava.\"",
                "&7\"Parece familiar? É o que Rex também faz...\""
            },
            null,
            new Location(w, 9, B + 1, 162),
            EntityType.VILLAGER));

        list.add(new NpcData("l1_boss_hint", "&4Terminal Corrompido", NpcData.NpcType.GUIDE,
            new String[]{
                "&c[LOG DO SISTEMA — DIA 14]",
                "&7Contenção do APEX-G1 rompida.",
                "&7Sujeito absorveu 3 assinaturas de mutação.",
                "&7Nível de combate estimado: CRÍTICO.",
                "&cAPROXIME-SE APENAS COM EXTREMA CAUTELA."
            },
            null,
            new Location(w, 9, B + 1, 92 + 68),
            EntityType.ARMOR_STAND));

        // --- LEVEL 2 CHECKPOINTS ---
        list.add(new NpcData("l2_cp1_npc", "&2Espírito da Floresta", NpcData.NpcType.STORY,
            new String[]{
                "&2&o\"A floresta se lembra do que foi feito a ela...\"",
                "&2&o\"Cada árvore retorcida pela radiação.\"",
                "&2&o\"As criaturas aranha fazem ninhos na copa das árvores.\"",
                "&2&o\"Sua seda aprisiona tudo. Até memórias.\""
            },
            null,
            new Location(w, 9, B + 1, 1200 + 162),
            EntityType.VILLAGER));

        list.add(new NpcData("l2_cp2_npc", "&aBotânica — Dra. Lena", NpcData.NpcType.GUIDE,
            new String[]{
                "&7\"Estou documentando as mutações há semanas.\"",
                "&7\"O Monstro do Laboratório — chamam de APEX-B2.\"",
                "&7\"Foi uma fusão fracassada de 4 espécies diferentes.\"",
                "&7\"Com metade da vida, ele dispara uma mitose de emergência.\"",
                "&7\"Se divide em dois. Mate as duas partes rapidamente.\""
            },
            null,
            new Location(w, 9, B + 1, 1200 + 232),
            EntityType.VILLAGER));

        // --- LEVEL 3 CHECKPOINTS ---
        list.add(new NpcData("l3_cp1_npc", "&7Rádio da Resistência", NpcData.NpcType.STORY,
            new String[]{
                "&7[ESTÁTICA] ...esta é a última transmissão...",
                "&7O protótipo da Máquina de Guerra ainda está operacional.",
                "&7Foi projetado para caçar os fugitivos do Projeto APEX.",
                "&7Irônico — agora ele caça tudo."
            },
            null,
            new Location(w, 9, B + 1, 2400 + 92),
            EntityType.ARMOR_STAND));

        list.add(new NpcData("l3_cp2_npc", "&cFantasma Militar", NpcData.NpcType.STORY,
            new String[]{
                "&8&o\"Eu construí essa máquina... Me perdoe.\"",
                "&8&o\"Na fase 2 ele atualiza seus sistemas de armas.\"",
                "&8&o\"Fase 3 — sobrecarga. Fica instável.\"",
                "&8&o\"Ataque rápido na fase 3. Não vai durar muito.\""
            },
            null,
            new Location(w, 9, B + 1, 2400 + 162),
            EntityType.ZOMBIE));

        list.add(new NpcData("l3_cp3_npc", "&6Fragmento de Memória de Ava #9", NpcData.NpcType.STORY,
            new String[]{
                "&5&o[Flash de Memória] Uma sala branca e estéril...",
                "&5&o[Flash de Memória] Um homem fardado assina um documento.",
                "&5&o[Flash de Memória] \"O Projeto APEX está aprovado para a Fase 3.\"",
                "&5&o[Flash de Memória] Voz de Ava: \"Não. Isso tem que parar.\""
            },
            null,
            new Location(w, 9, B + 1, 2400 + 237),
            EntityType.ARMOR_STAND));

        // --- LEVEL 4 CHECKPOINTS (Dragon's Lair) ---
        list.add(new NpcData("l4_cp1_npc", "&4Fantasma Cultista do Dragão", NpcData.NpcType.STORY,
            new String[]{
                "&4&o\"Ele escolheu isso para si mesmo...\"",
                "&4&o\"O General se injetou com tudo.\"",
                "&4&o\"Dragão, gorila, chama, fantasma — todos eles.\"",
                "&4&o\"Ele disse que seria perfeito. Tornou-se um monstro.\""
            },
            null,
            new Location(w, 9, B + 1, 3600 + 102),
            EntityType.ZOMBIE));

        list.add(new NpcData("l4_cp2_npc", "&5Memória de Ava — Lembrança Completa", NpcData.NpcType.STORY,
            new String[]{
                "&f\"Lembro agora. Tudo.\"",
                "&f\"Eu criei a cura e a escondi dentro do Rex.\"",
                "&f\"Quando o General cair, Rex pode liberá-la.\"",
                "&f\"Ela vai reverter as mutações. Salvar o que sobrou.\"",
                "&6\"Rex... é hora. Vamos terminar isso.\""
            },
            null,
            new Location(w, 9, B + 1, 3600 + 187),
            EntityType.VILLAGER));

        list.add(new NpcData("l4_cp3_npc", "&4Transmissão do General", NpcData.NpcType.GUIDE,
            new String[]{
                "&4[TRANSMISSÃO DE EMERGÊNCIA]",
                "&c\"EU SOU O APEX. EU SOU A EVOLUÇÃO.\"",
                "&c\"Seu cachorro carrega a cura? Que ele venha.\"",
                "&c\"Vou absorvê-lo também. Vou absorver TUDO.\"",
                "&4[Fim da transmissão]"
            },
            null,
            new Location(w, 9, B + 1, 3600 + 257),
            EntityType.ARMOR_STAND));

        list.add(new NpcData("l4_final_npc", "&4&lANTES DA BATALHA FINAL", NpcData.NpcType.STORY,
            new String[]{
                "&f\"Ava está na entrada. Rex ao seu lado.\"",
                "&f\"Além dessa porta está o fim de tudo pelo que lutaram.\"",
                "&6Rex rosna. Suas mutações brilham com luz.",
                "&f\"O que quer que aconteça lá dentro...\" ela sussurra.",
                "&f\"...obrigada, Rex. Por tudo.\"",
                "&c[ENTRE NA ARENA PARA ENFRENTAR O DRAGÃO MUTANTE]"
            },
            null,
            new Location(w, 3, B + 1, 3600 + 282),
            EntityType.VILLAGER));

        return list;
    }

    // ---------------------------------------------------------------
    // Spawning
    // ---------------------------------------------------------------

    private void spawnNpc(NpcData data) {
        if (data.location == null || data.location.getWorld() == null) return;

        // Remove old entity if exists
        UUID oldUUID = npcIdMap.get(data.id);
        if (oldUUID != null) {
            Entity old = Bukkit.getEntity(oldUUID);
            if (old != null) old.remove();
        }

        Entity entity;

        if (data.entityType == EntityType.ARMOR_STAND) {
            ArmorStand stand = data.location.getWorld().spawn(data.location, ArmorStand.class, as -> {
                as.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                as.setCustomNameVisible(true);
                as.setGravity(false);
                as.setInvisible(true);
                as.setInvulnerable(true);
                as.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                as.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = stand;
        } else if (data.entityType == EntityType.VILLAGER) {
            Villager villager = data.location.getWorld().spawn(data.location, Villager.class, v -> {
                v.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                v.setCustomNameVisible(true);
                v.setInvulnerable(true);
                v.setAI(false);
                v.setSilent(false);
                v.setVillagerType(Villager.Type.PLAINS);
                v.setProfession(switch (data.type) {
                    case MERCHANT -> Villager.Profession.WEAPONSMITH;
                    case GUIDE    -> Villager.Profession.LIBRARIAN;
                    case QUEST    -> Villager.Profession.ARMORER;
                    default       -> Villager.Profession.NONE;
                });
                v.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                v.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = villager;
        } else if (data.entityType == EntityType.WOLF) {
            Wolf wolf = data.location.getWorld().spawn(data.location, Wolf.class, w -> {
                w.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                w.setCustomNameVisible(true);
                w.setInvulnerable(true);
                w.setAI(false);
                w.setTamed(true);
                w.setCollarColor(DyeColor.RED);
                w.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                w.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = wolf;
        } else if (data.entityType == EntityType.ZOMBIE) {
            Zombie zombie = data.location.getWorld().spawn(data.location, Zombie.class, z -> {
                z.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                z.setCustomNameVisible(true);
                z.setInvulnerable(true);
                z.setAI(false);
                z.setSilent(true);
                z.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                z.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = zombie;
        } else {
            // Pillager or fallback
            entity = data.location.getWorld().spawn(data.location, Villager.class, v -> {
                v.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                v.setCustomNameVisible(true);
                v.setInvulnerable(true);
                v.setAI(false);
                v.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                v.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
        }

        activeNpcs.put(entity.getUniqueId(), data);
        npcIdMap.put(data.id, entity.getUniqueId());

        // Ambient glow for story NPCs
        if (data.type == NpcData.NpcType.STORY && entity instanceof LivingEntity le) {
            le.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
        }
    }

    // ---------------------------------------------------------------
    // Interaction listener
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        Entity entity = event.getRightClicked();
        if (!entity.hasMetadata("da_npc")) return;
        event.setCancelled(true);

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Cooldown check (1.5s between interactions)
        long now = System.currentTimeMillis();
        Long cd = interactCooldown.get(uuid);
        if (cd != null && now - cd < 1500) return;
        interactCooldown.put(uuid, now);

        NpcData data = activeNpcs.get(entity.getUniqueId());
        if (data == null) return;

        // Particle effect on interaction
        entity.getWorld().spawnParticle(Particle.VILLAGER_HAPPY,
                entity.getLocation().add(0, 2, 0), 8, 0.4, 0.4, 0.4, 0.02);
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_AMBIENT, 0.7f, 1.1f);

        // Handle special triggers
        if ("refresh_kit".equals(data.questTrigger)) {
            plugin.getPlayerClassManager().applyClassStats(player,
                    plugin.getPlayerDataManager().get(player).getPlayerClass());
            // Regive kit
            var cls = plugin.getPlayerDataManager().get(player).getPlayerClass();
            plugin.getPlayerClassManager().setClass(player, cls);
        }

        // Mark if one-time dialogue
        boolean isNew = !hasHeard(uuid, data.id);
        if (isNew && data.type == NpcData.NpcType.STORY) {
            markHeard(uuid, data.id);
        }

        // Play dialogue
        plugin.getDialogueManager().playDialogue(player, data.name, data.dialogue);

        // Unlock story fragment for story NPCs
        if (data.type == NpcData.NpcType.STORY && isNew) {
            new BukkitRunnable() {
                @Override public void run() {
                    plugin.getDialogueManager().unlockNextFragment(player);
                }
            }.runTaskLater(plugin, 80L);
        }
    }

    // Prevent NPCs from being damaged
    @EventHandler(ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity().hasMetadata("da_npc")) {
            event.setCancelled(true);
        }
    }

    // Prevent NPCs from being pushed/moved
    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        if (event.getEntity().hasMetadata("da_npc") || event.getTarget() != null
                && event.getTarget().hasMetadata("da_npc")) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------
    // Utility
    // ---------------------------------------------------------------

    private boolean hasHeard(UUID playerUUID, String npcId) {
        Set<String> heard = heardDialogue.get(playerUUID);
        return heard != null && heard.contains(npcId);
    }

    private void markHeard(UUID playerUUID, String npcId) {
        heardDialogue.computeIfAbsent(playerUUID, k -> new HashSet<>()).add(npcId);
    }

    public void cleanupAll() {
        for (UUID entityUUID : activeNpcs.keySet()) {
            Entity e = Bukkit.getEntity(entityUUID);
            if (e != null) e.remove();
        }
        activeNpcs.clear();
        npcIdMap.clear();
    }

    public int getNpcCount() { return activeNpcs.size(); }
}
