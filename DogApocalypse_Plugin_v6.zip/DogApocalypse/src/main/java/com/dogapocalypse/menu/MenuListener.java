package com.dogapocalypse.menu;

import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Listener central que intercepta todos os cliques nos menus GUI.
 * Identifica o menu pelo título e roteia para a ação correta.
 */
public class MenuListener implements Listener {

    private final DogApocalypsePlugin plugin;

    // Jogadores aguardando digitar nome para convidar
    private final Set<UUID> aguardandoConvite = new HashSet<>();

    public MenuListener(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String titulo = event.getView().getTitle();
        ItemStack item = event.getCurrentItem();

        // Cancela clique em qualquer menu do plugin
        if (!isMeuMenu(titulo)) return;
        event.setCancelled(true);

        if (item == null || item.getType() == Material.AIR) return;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return;

        String nome = item.getItemMeta().getDisplayName();

        // Efeito sonoro de clique
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1f);

        // ── Roteamento por título do menu ──
        if (titulo.equals(MenuPrincipal.TITULO)) {
            tratarMenuPrincipal(player, nome);
        } else if (titulo.equals(MenuFases.TITULO)) {
            tratarMenuFases(player, nome);
        } else if (titulo.equals(MenuHabilidades.TITULO)) {
            tratarMenuHabilidades(player, nome);
        } else if (titulo.equals(MenuGrupo.TITULO)) {
            tratarMenuGrupo(player, nome, item);
        }
    }

    // ──────────────────────────────────────────────────────────────
    // MENU PRINCIPAL
    // ──────────────────────────────────────────────────────────────

    private void tratarMenuPrincipal(Player player, String nome) {
        String stripped = MessageUtil.strip(nome);

        if (stripped.contains("Cão Mutante")) {
            plugin.getPlayerClassManager().setClass(player, PlayerClass.DOG);
            player.closeInventory();
            player.playSound(player.getLocation(), Sound.ENTITY_WOLF_HOWL, 1f, 1f);

        } else if (stripped.contains("Lutador")) {
            plugin.getPlayerClassManager().setClass(player, PlayerClass.FIGHTER);
            player.closeInventory();
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.8f);

        } else if (stripped.contains("Arqueiro")) {
            plugin.getPlayerClassManager().setClass(player, PlayerClass.ARCHER);
            player.closeInventory();
            player.playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1f, 1.2f);

        } else if (stripped.contains("Escolher Fase")) {
            MenuFases.abrir(player, plugin);

        } else if (stripped.contains("Poder Absorvido")) {
            player.closeInventory();
            plugin.getDogPowerManager().triggerAbility(player);

        } else if (stripped.contains("Grupo")) {
            MenuGrupo.abrir(player, plugin);

        } else if (stripped.contains("Árvore de Habilidades")) {
            MenuHabilidades.abrir(player, plugin);

        } else if (stripped.contains("Fechar")) {
            player.closeInventory();
        }
    }

    // ──────────────────────────────────────────────────────────────
    // MENU FASES
    // ──────────────────────────────────────────────────────────────

    private void tratarMenuFases(Player player, String nome) {
        String stripped = MessageUtil.strip(nome);
        String levelId  = null;

        if      (stripped.contains("Fase 1")) levelId = "level_1";
        else if (stripped.contains("Fase 2")) levelId = "level_2";
        else if (stripped.contains("Fase 3")) levelId = "level_3";
        else if (stripped.contains("Fase 4")) levelId = "level_4";
        else if (stripped.contains("Voltar")) { MenuPrincipal.abrir(player, plugin); return; }
        else if (stripped.contains("Bloqueada")) {
            player.sendMessage(MessageUtil.color("&c🔒 Esta fase ainda está bloqueada! Complete as anteriores."));
            return;
        }

        if (levelId == null) return;

        player.closeInventory();
        var level = plugin.getLevelManager().getLevel(levelId);
        if (level == null || level.getSpawnLocation() == null) {
            player.sendMessage(MessageUtil.color("&cO mundo ainda está sendo gerado. Aguarde um momento!"));
            return;
        }

        // Teleporta e inicia o nível
        player.teleport(level.getSpawnLocation());
        var party = plugin.getCoopManager().getPartyMembers(player);
        final String fId = levelId;
        // Pequeno delay para o TP terminar antes de iniciar
        Bukkit.getScheduler().runTaskLater(plugin, () ->
            plugin.getLevelManager().startLevel(fId, party), 10L);
    }

    // ──────────────────────────────────────────────────────────────
    // MENU HABILIDADES
    // ──────────────────────────────────────────────────────────────

    private void tratarMenuHabilidades(Player player, String nome) {
        String stripped = MessageUtil.strip(nome);

        if (stripped.contains("Voltar")) { MenuPrincipal.abrir(player, plugin); return; }

        // Mapeia nome do item → ID da skill
        Map<String, String> nomeParaId = new LinkedHashMap<>();
        for (String id : plugin.getSkillTreeManager().getSkillIds()) {
            String dn = MessageUtil.strip(plugin.getSkillTreeManager().getDisplayName(id));
            nomeParaId.put(dn, id);
        }

        for (Map.Entry<String, String> e : nomeParaId.entrySet()) {
            if (stripped.contains(e.getKey())) {
                boolean ok = plugin.getSkillTreeManager().upgradeSkill(player, e.getValue());
                if (ok) {
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
                    // Recarrega o menu com valores atualizados
                    Bukkit.getScheduler().runTaskLater(plugin,
                        () -> MenuHabilidades.abrir(player, plugin), 1L);
                }
                return;
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // MENU GRUPO
    // ──────────────────────────────────────────────────────────────

    private void tratarMenuGrupo(Player player, String nome, ItemStack item) {
        String stripped = MessageUtil.strip(nome);

        if (stripped.contains("Voltar")) {
            MenuPrincipal.abrir(player, plugin);

        } else if (stripped.contains("Convidar Jogador")) {
            player.closeInventory();
            aguardandoConvite.add(player.getUniqueId());
            player.sendMessage(MessageUtil.color("&e&l[Grupo] &fDigite o nome do jogador que deseja convidar no chat:"));
            player.sendMessage(MessageUtil.color("&7(Digite &ccancelar &7para cancelar)"));

        } else if (stripped.contains("Sair do Grupo")) {
            plugin.getCoopManager().leaveParty(player);
            Bukkit.getScheduler().runTaskLater(plugin,
                () -> MenuGrupo.abrir(player, plugin), 2L);

        } else if (item.getType() == org.bukkit.Material.PLAYER_HEAD && !stripped.contains("(Você)")) {
            // Clicou em um membro para expulsar
            String nomeJogador = stripped;
            Player alvo = Bukkit.getPlayer(nomeJogador);
            if (alvo != null && !alvo.equals(player)) {
                plugin.getCoopManager().leaveParty(alvo);
                alvo.sendMessage(MessageUtil.color("&c[Grupo] &fVocê foi removido do grupo por &e" + player.getName()));
                player.sendMessage(MessageUtil.color("&e[Grupo] &f" + alvo.getName() + " &ffoi removido do grupo."));
                Bukkit.getScheduler().runTaskLater(plugin,
                    () -> MenuGrupo.abrir(player, plugin), 2L);
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // CHAT — captura nome do jogador para convite
    // ──────────────────────────────────────────────────────────────

    @EventHandler
    public void onChat(org.bukkit.event.player.AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!aguardandoConvite.contains(player.getUniqueId())) return;

        event.setCancelled(true);
        aguardandoConvite.remove(player.getUniqueId());
        String msg = event.getMessage().trim();

        if (msg.equalsIgnoreCase("cancelar")) {
            player.sendMessage(MessageUtil.color("&7Convite cancelado."));
            Bukkit.getScheduler().runTask(plugin, () -> MenuGrupo.abrir(player, plugin));
            return;
        }

        Player alvo = Bukkit.getPlayer(msg);
        if (alvo == null) {
            player.sendMessage(MessageUtil.color("&c[Grupo] &fJogador &e" + msg + " &fnão encontrado ou offline."));
            Bukkit.getScheduler().runTask(plugin, () -> MenuGrupo.abrir(player, plugin));
            return;
        }

        plugin.getCoopManager().invitePlayer(player, alvo);
        Bukkit.getScheduler().runTask(plugin, () -> MenuGrupo.abrir(player, plugin));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        // Limpa estado de convite se fechar qualquer menu
        if (event.getPlayer() instanceof Player p)
            aguardandoConvite.remove(p.getUniqueId());
    }

    private boolean isMeuMenu(String titulo) {
        return titulo.equals(MenuPrincipal.TITULO)
            || titulo.equals(MenuFases.TITULO)
            || titulo.equals(MenuHabilidades.TITULO)
            || titulo.equals(MenuGrupo.TITULO);
    }
}
