package com.dogapocalypse.combat;

import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.HashMap;
import java.util.UUID;

/**
 * CombatManager — calculates and applies class-specific combat modifiers.
 *
 * Fighter: extra melee damage + shield block mechanics.
 * Archer:  extra arrow damage + precision shots.
 * Dog:     slight melee bonus from Mutant Fangs item.
 */
public class CombatManager {

    private final DogApocalypsePlugin plugin;

    /** Fighter shield block cooldown: UUID -> expiry time ms */
    private final Map<UUID, Long> shieldCooldowns = new HashMap<>();

    /** Archer rapid fire cooldown */
    private final Map<UUID, Long> rapidFireCooldowns = new HashMap<>();

    public CombatManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    // ----------------------------------------------------------------
    // Damage calculation
    // ----------------------------------------------------------------

    /**
     * Applies class combat modifiers to an entity damage event.
     * Called from CombatListener.
     */
    public void applyClassDamageModifiers(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;

        PlayerClass cls = plugin.getPlayerClassManager().getClass(attacker);

        switch (cls) {
            case FIGHTER -> applyFighterDamage(event, attacker);
            case ARCHER  -> applyArcherDamage(event, attacker);
            case DOG     -> applyDogDamage(event, attacker);
        }
    }

    // Fighter: +4 bonus damage on melee, shield block reduces incoming damage
    private void applyFighterDamage(EntityDamageByEntityEvent event, Player fighter) {
        if (isMeleeAttack(fighter)) {
            double bonus = plugin.getConfig().getDouble("classes.fighter.melee_damage_bonus", 4.0);
            event.setDamage(event.getDamage() + bonus);

            // Visual slash effect
            event.getEntity().getWorld().spawnParticle(Particle.SWEEP_ATTACK,
                    event.getEntity().getLocation().add(0, 1, 0), 2, 0.2, 0.2, 0.2, 0);
        }
    }

    // Archer: +3 bonus damage on arrows, precision multiplier on long shots
    private void applyArcherDamage(EntityDamageByEntityEvent event, Player archer) {
        if (event.getDamager() instanceof Arrow arrow) {
            double bonus = plugin.getConfig().getDouble("classes.archer.arrow_damage_bonus", 3.0);
            double dist = arrow.getOrigin() != null
                    ? arrow.getOrigin().distance(event.getEntity().getLocation()) : 0;

            double multiplier = 1.0;
            // Precision bonus for shots > 15 blocks
            if (dist > 15) {
                multiplier = plugin.getConfig().getDouble("classes.archer.precision_multiplier", 1.5);
                archer.sendActionBar(MessageUtil.color("&a✦ Precision Shot!"));
                event.getEntity().getWorld().spawnParticle(Particle.CRIT,
                        event.getEntity().getLocation().add(0, 1, 0), 10, 0.2, 0.2, 0.2, 0.1);
            }

            event.setDamage((event.getDamage() + bonus) * multiplier);
        }
    }

    // Dog: small bonus from Mutant Fangs
    private void applyDogDamage(EntityDamageByEntityEvent event, Player dog) {
        if (isMeleeAttack(dog)) {
            // Fangs give +2 per enchant level 2 -> total from enchant is covered by game
            // Just add a small bonus from mutation
            event.setDamage(event.getDamage() + 1.5);
        }
    }

    // ----------------------------------------------------------------
    // Fighter Shield Block
    // ----------------------------------------------------------------

    /**
     * Checks if a Fighter is blocking and reduces incoming damage.
     * Called from CombatListener on EntityDamageByEntityEvent for the Fighter as victim.
     */
    public void applyFighterBlock(EntityDamageByEntityEvent event, Player fighter) {
        if (plugin.getPlayerClassManager().getClass(fighter) != PlayerClass.FIGHTER) return;

        ItemStack offHand = fighter.getInventory().getItemInOffHand();
        if (offHand.getType() != Material.SHIELD) return;

        // Check if player is sneaking (blocking stance)
        if (!fighter.isSneaking()) return;

        UUID uuid = fighter.getUniqueId();
        long now = System.currentTimeMillis();
        Long cd = shieldCooldowns.get(uuid);
        if (cd != null && now < cd) return; // on cooldown

        double blockChance = plugin.getConfig().getDouble("classes.fighter.shield_block_chance", 0.35);
        if (Math.random() < blockChance) {
            event.setDamage(event.getDamage() * 0.15); // block most damage
            fighter.sendActionBar(MessageUtil.color("&7🛡 Blocked!"));
            fighter.getWorld().spawnParticle(Particle.CRIT_MAGIC,
                    fighter.getLocation().add(0, 1, 0), 8, 0.2, 0.2, 0.2, 0.05);
            fighter.getWorld().playSound(fighter.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);

            int cdTicks = plugin.getConfig().getInt("classes.fighter.block_cooldown_ticks", 40);
            shieldCooldowns.put(uuid, now + (cdTicks * 50L));
        }
    }

    // ----------------------------------------------------------------
    // Utility
    // ----------------------------------------------------------------

    private boolean isMeleeAttack(Player player) {
        return player.getInventory().getItemInMainHand().getType().name().contains("SWORD")
                || player.getInventory().getItemInMainHand().getType().name().contains("AXE")
                || player.getInventory().getItemInMainHand().getType() == Material.AIR;
    }

    public void cleanupPlayer(UUID uuid) {
        shieldCooldowns.remove(uuid);
        rapidFireCooldowns.remove(uuid);
    }
}
