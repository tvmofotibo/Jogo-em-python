package com.dogapocalypse.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/**
 * Utility for chat color translation.
 */
public final class MessageUtil {

    private static final LegacyComponentSerializer SERIALIZER =
            LegacyComponentSerializer.legacyAmpersand();

    private MessageUtil() {}

    /**
     * Translates &-prefixed color codes into a colored string.
     * Use this for legacy org.bukkit.ChatColor-based APIs.
     */
    public static String color(String message) {
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', message);
    }

    /**
     * Returns an Adventure Component from an &-prefixed message.
     */
    public static Component component(String message) {
        return SERIALIZER.deserialize(message);
    }
}

    /** Remove códigos de cor de uma string (para comparações de nome de item). */
    public static String strip(String s) {
        if (s == null) return "";
        return s.replaceAll("§[0-9a-fk-or]", "").replaceAll("&[0-9a-fk-or]", "").trim();
    }
