package com.dogapocalypse.worldgen;

import com.dogapocalypse.core.DogApocalypsePlugin;
import org.bukkit.*;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * WorldGenerator v5 — Cidade expandida com laboratórios, casas, becos e mais.
 *
 * NÍVEL 1 — Cidade em Ruínas (Z=0 → Z=700)  ← muito maior
 *   • Bairro residencial (casas A, B, C...)
 *   • Laboratórios A, B, C com interior
 *   • Zona comercial + mercado
 *   • Zona industrial (fábricas com chaminés)
 *   • Estação de trem destruída
 *   • Praça central com estátua
 *   • Becos, muros, postes, entulho
 *
 * NÍVEL 2 — Floresta Infectada  (Z=1400)
 * NÍVEL 3 — Ruínas de Guerra    (Z=2800)
 * NÍVEL 4 — Covil do Dragão     (Z=4200)
 */
public class WorldGenerator {

    private final DogApocalypsePlugin plugin;
    private World mundo;

    public static final String NOME_MUNDO = "dogapocalypse_niveis";
    private static final int BASE_Y      = 64;
    private static final int ESPACAMENTO = 1400;  // mais espaço entre níveis

    // Lote conservador para Termux (celular)
    private static final int LOTE = 60;

    private final ArrayList<int[]> fila = new ArrayList<>();
    private static final Material[] MATS = Material.values();

    public WorldGenerator(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────────────────────────
    // INICIALIZAÇÃO
    // ─────────────────────────────────────────────────────────────

    public void initWorld(Runnable aoTerminar) {
        mundo = Bukkit.getWorld(NOME_MUNDO);
        if (mundo != null) {
            plugin.getLogger().info("[WorldGen] Mundo já existe, pulando geração.");
            if (aoTerminar != null) aoTerminar.run();
            return;
        }

        plugin.getLogger().info("[WorldGen] Criando mundo: " + NOME_MUNDO);
        WorldCreator c = new WorldCreator(NOME_MUNDO);
        c.type(WorldType.FLAT);
        c.generatorSettings("{\"layers\":[{\"block\":\"bedrock\",\"height\":1}],\"biome\":\"plains\"}");
        c.generateStructures(false);

        mundo = c.createWorld();
        if (mundo == null) { plugin.getLogger().severe("[WorldGen] Falha ao criar mundo!"); return; }

        mundo.setSpawnFlags(false, false);
        mundo.setGameRule(GameRule.DO_MOB_SPAWNING,       false);
        mundo.setGameRule(GameRule.DO_DAYLIGHT_CYCLE,     false);
        mundo.setGameRule(GameRule.DO_WEATHER_CYCLE,      false);
        mundo.setGameRule(GameRule.MOB_GRIEFING,          false);
        mundo.setGameRule(GameRule.KEEP_INVENTORY,        true);
        mundo.setGameRule(GameRule.ANNOUNCE_ADVANCEMENTS, false);
        mundo.setGameRule(GameRule.NATURAL_REGENERATION,  true);
        mundo.setTime(18000);

        plugin.getLogger().info("[WorldGen] Pré-carregando chunks...");
        preCarregarChunks();

        new BukkitRunnable() {
            int etapa = 0;
            @Override public void run() {
                switch (etapa++) {
                    case 0 -> { plugin.getLogger().info("[WorldGen] Gerando Nível 1: Cidade em Ruínas..."); montarNivel1(); }
                    case 1 -> { plugin.getLogger().info("[WorldGen] Gerando Nível 2: Floresta Infectada..."); montarNivel2(); }
                    case 2 -> { plugin.getLogger().info("[WorldGen] Gerando Nível 3: Ruínas de Guerra..."); montarNivel3(); }
                    case 3 -> { plugin.getLogger().info("[WorldGen] Gerando Nível 4: Covil do Dragão..."); montarNivel4(); }
                    default -> {
                        plugin.getLogger().info("[WorldGen] Todos os níveis prontos!");
                        if (aoTerminar != null) aoTerminar.run();
                        cancel();
                    }
                }
            }
        }.runTaskTimer(plugin, 10L, 80L);
    }

    private void preCarregarChunks() {
        // Nível 1 é muito maior agora (700 blocos), pré-carregar mais chunks
        for (int nivel = 1; nivel <= 4; nivel++) {
            int ozBloco  = (nivel - 1) * ESPACAMENTO;
            int comprimento = (nivel == 1) ? 720 : 420;
            int czInicio = ozBloco >> 4;
            int czFim    = (ozBloco + comprimento) >> 4;
            for (int cx = 0; cx <= 6; cx++) {
                for (int cz = czInicio; cz <= czFim; cz++) {
                    mundo.loadChunk(cx, cz, true);
                }
            }
        }
        plugin.getLogger().info("[WorldGen] Chunks pré-carregados.");
    }

    // ═══════════════════════════════════════════════════════════════
    // NÍVEL 1 — CIDADE EM RUÍNAS (EXPANDIDA)
    // ═══════════════════════════════════════════════════════════════

    private void montarNivel1() {
        fila.clear();
        int oz = 0;
        Random rng = new Random(101);

        // ── Chão urbano base ──
        camada(0, BASE_Y-1, oz,    80, 700, Material.STONE_BRICKS);
        camada(0, BASE_Y-2, oz,    80, 700, Material.COBBLESTONE);
        camada(0, BASE_Y-3, oz,    80, 700, Material.GRAVEL);

        // ── Avenida principal (eixo Z) ──
        camada(35, BASE_Y, oz,      8, 700, Material.SMOOTH_STONE);
        // Calçadas
        camada(33, BASE_Y, oz,      2, 700, Material.STONE_BRICK_SLAB);
        camada(43, BASE_Y, oz,      2, 700, Material.STONE_BRICK_SLAB);

        // ── Rua lateral (eixo X) cruzamentos ──
        camada(0, BASE_Y, oz+120,   80, 8, Material.SMOOTH_STONE);
        camada(0, BASE_Y, oz+280,   80, 8, Material.SMOOTH_STONE);
        camada(0, BASE_Y, oz+450,   80, 8, Material.SMOOTH_STONE);
        camada(0, BASE_Y, oz+600,   80, 8, Material.SMOOTH_STONE);

        // ══════════════════════════════════════════════
        // ZONA 1 — BAIRRO RESIDENCIAL (Z 10–115)
        // ══════════════════════════════════════════════

        // Casas lado esquerdo (X 1–32)
        casa(1,  BASE_Y, oz+12,  8, 5, 8,  rng, "Casa A");
        casa(12, BASE_Y, oz+12,  8, 4, 7,  rng, "Casa B");
        casa(22, BASE_Y, oz+12,  9, 5, 9,  rng, "Casa C");
        casa(1,  BASE_Y, oz+42,  10, 6, 9, rng, "Casa D");
        casa(14, BASE_Y, oz+40,  8,  5, 8, rng, "Casa E");
        casa(1,  BASE_Y, oz+75,  9,  5, 9, rng, "Casa F");
        casa(12, BASE_Y, oz+78,  7,  4, 7, rng, "Casa G");
        casa(22, BASE_Y, oz+72,  9,  6, 8, rng, "Casa H");

        // Casas lado direito (X 46–78)
        casa(46, BASE_Y, oz+10,  10, 5, 9, rng, "Casa I");
        casa(58, BASE_Y, oz+12,  8,  4, 8, rng, "Casa J");
        casa(68, BASE_Y, oz+10,  10, 6, 9, rng, "Casa K");
        casa(46, BASE_Y, oz+45,  9,  5, 8, rng, "Casa L");
        casa(58, BASE_Y, oz+48,  8,  5, 7, rng, "Casa M");
        casa(68, BASE_Y, oz+42,  10, 6, 9, rng, "Casa N");
        casa(46, BASE_Y, oz+80,  9,  4, 8, rng, "Casa O");
        casa(58, BASE_Y, oz+76,  10, 5, 9, rng, "Casa P");

        // Muro do bairro
        muro(0, BASE_Y, oz+8, 0, oz+112, 3);
        muro(78, BASE_Y, oz+8, 78, oz+112, 3);

        // Poço no centro do bairro
        poco(20, BASE_Y, oz+58);

        // ══════════════════════════════════════════════
        // ZONA 2 — PRAÇA CENTRAL (Z 128–170)
        // ══════════════════════════════════════════════
        pracaCentral(40, BASE_Y, oz+150);

        // Prédios ao redor da praça
        predio(2,  BASE_Y, oz+128, 12, 10, 10, rng, Material.STONE_BRICKS,     Material.GLASS_PANE);
        predio(16, BASE_Y, oz+130, 15, 14, 12, rng, Material.DEEPSLATE_BRICKS, Material.TINTED_GLASS);
        predio(46, BASE_Y, oz+128, 14, 12, 10, rng, Material.BRICK,            Material.GLASS_PANE);
        predio(62, BASE_Y, oz+130, 16, 16, 12, rng, Material.POLISHED_DEEPSLATE, Material.TINTED_GLASS);
        predio(2,  BASE_Y, oz+162, 12, 9,  10, rng, Material.STONE_BRICKS,     Material.GLASS_PANE);
        predio(62, BASE_Y, oz+158, 16, 11, 12, rng, Material.DEEPSLATE_BRICKS, Material.TINTED_GLASS);

        // ══════════════════════════════════════════════
        // ZONA 3 — LABORATÓRIOS (Z 190–380)
        // ══════════════════════════════════════════════

        // Laboratório A — pequeno, salas abertas (Z 195–240)
        laboratorio(2, BASE_Y, oz+195, 28, 8, 40, rng, "A");

        // Corredor entre labs
        camada(2, BASE_Y, oz+236, 28, 8, Material.SMOOTH_STONE);

        // Laboratório B — médio, com câmaras (Z 245–310)
        laboratorio(2, BASE_Y, oz+245, 34, 9, 55, rng, "B");

        // Rua entre labs e prédios
        camada(0, BASE_Y, oz+244, 80, 6, Material.SMOOTH_STONE);

        // Prédios anexos ao Lab B (lado direito)
        predio(48, BASE_Y, oz+248, 14, 12, 20, rng, Material.DEEPSLATE_BRICKS, Material.TINTED_GLASS);
        predio(64, BASE_Y, oz+248, 14, 10, 18, rng, Material.SMOOTH_STONE,     Material.GLASS_PANE);
        predio(48, BASE_Y, oz+275, 14, 14, 22, rng, Material.POLISHED_DEEPSLATE, Material.TINTED_GLASS);

        // Laboratório C — grande, com múltiplos andares (Z 320–415)
        laboratorio(2, BASE_Y, oz+320, 42, 12, 80, rng, "C");

        // Guaritas de segurança do Lab C
        guarita(46, BASE_Y, oz+322);
        guarita(46, BASE_Y, oz+410);

        // Cerca de arame farpado em torno do Lab C
        cercaArame(2, BASE_Y, oz+318, 44, 84);

        // ══════════════════════════════════════════════
        // ZONA 4 — ZONA COMERCIAL (Z 130–190 lado direito)
        // ══════════════════════════════════════════════
        mercado(46, BASE_Y, oz+175, rng);

        // ══════════════════════════════════════════════
        // ZONA 5 — ZONA INDUSTRIAL (Z 430–560)
        // ══════════════════════════════════════════════
        fabrica(2,  BASE_Y, oz+430, 24, 11, 22, rng);
        fabrica(30, BASE_Y, oz+425, 20, 9,  18, rng);
        fabrica(54, BASE_Y, oz+428, 22, 10, 20, rng);
        fabrica(2,  BASE_Y, oz+490, 28, 12, 24, rng);
        fabrica(34, BASE_Y, oz+495, 24, 10, 20, rng);

        // Tanques de combustível
        tanque(60, BASE_Y, oz+460, 8);
        tanque(60, BASE_Y, oz+500, 6);

        // ══════════════════════════════════════════════
        // ZONA 6 — ESTAÇÃO DE TREM (Z 570–610)
        // ══════════════════════════════════════════════
        estacao(2, BASE_Y, oz+570, 74, 10);

        // ══════════════════════════════════════════════
        // CHECKPOINTS + ARENA BOSS
        // ══════════════════════════════════════════════
        checkpoint(38, BASE_Y, oz+115,  "§6§l✦ PONTO DE CONTROLE 1");
        checkpoint(38, BASE_Y, oz+288,  "§6§l✦ PONTO DE CONTROLE 2");
        checkpoint(38, BASE_Y, oz+465,  "§6§l✦ PONTO DE CONTROLE 3");

        arenaChefe(40, BASE_Y, oz+645, 26, Material.BLACKSTONE, Material.CRACKED_POLISHED_BLACKSTONE_BRICKS);

        // ── Detalhes ambientais ──
        iluminacaoCidade(oz, 660);
        entulho(oz, 640, rng);
        vegetacaoUrbana(oz, 640, rng);
        carrosDestruidos(oz, 640, rng);

        processarFila();
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS — RESIDENCIAL
    // ═══════════════════════════════════════════════════════════════

    /** Casa residencial com interior básico */
    private void casa(int ox, int oy, int oz, int larg, int alt, int prof,
                      Random rng, String id) {
        Material mat = switch (rng.nextInt(4)) {
            case 0 -> Material.BRICK;
            case 1 -> Material.STONE_BRICKS;
            case 2 -> Material.COBBLESTONE;
            default -> Material.SMOOTH_STONE;
        };

        // Fundação
        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+prof; z++)
                bloco(x, oy-1, z, Material.STONE_BRICK_SLAB);

        // Paredes
        for (int y = oy; y < oy+alt; y++)
            for (int x = ox; x < ox+larg; x++)
                for (int z = oz; z < oz+prof; z++) {
                    boolean borda = x==ox||x==ox+larg-1||z==oz||z==oz+prof-1;
                    if (!borda) continue;
                    boolean janela = y==oy+2 && (z==oz||z==oz+prof-1)
                            && x>ox && x<ox+larg-1 && x%2==0;
                    if (janela)
                        bloco(x, y, z, rng.nextFloat()<0.4f ? Material.AIR : Material.GLASS_PANE);
                    else
                        bloco(x, y, z, rng.nextFloat()<0.06f ? Material.CRACKED_STONE_BRICKS : mat);
                }

        // Telhado inclinado (escadas de pedra)
        for (int d = 0; d <= larg/2; d++) {
            for (int z = oz; z < oz+prof; z++) {
                bloco(ox+d,        oy+alt+d,   z, Material.STONE_BRICK_SLAB);
                bloco(ox+larg-1-d, oy+alt+d,   z, Material.STONE_BRICK_SLAB);
            }
        }

        // Porta de entrada
        int px = ox + larg/2;
        bloco(px, oy,   oz, Material.AIR);
        bloco(px, oy+1, oz, Material.AIR);

        // Interior — móveis básicos
        bloco(ox+1, oy, oz+1, Material.CRAFTING_TABLE);
        bloco(ox+larg-2, oy, oz+1, Material.CHEST);
        if (prof > 5) {
            bloco(ox+1, oy, oz+prof-2, Material.BED);
            bloco(ox+larg-2, oy, oz+prof-2, Material.FURNACE);
        }
        bloco(ox+larg/2, oy, oz+prof/2, Material.LANTERN);

        // Calçada na frente
        for (int x = ox-1; x < ox+larg+1; x++)
            bloco(x, oy, oz-1, Material.STONE_BRICK_SLAB);
    }

    /** Poço */
    private void poco(int ox, int oy, int oz) {
        for (int x = ox-2; x <= ox+2; x++)
            for (int z = oz-2; z <= oz+2; z++)
                bloco(x, oy, z, Material.COBBLESTONE);
        for (int x = ox-1; x <= ox+1; x++)
            for (int z = oz-1; z <= oz+1; z++)
                bloco(x, oy, z, Material.AIR);
        bloco(ox, oy-1, oz, Material.WATER);
        for (int y = oy+1; y <= oy+3; y++) {
            bloco(ox-1, y, oz-1, Material.COBBLESTONE_WALL);
            bloco(ox+1, y, oz-1, Material.COBBLESTONE_WALL);
            bloco(ox-1, y, oz+1, Material.COBBLESTONE_WALL);
            bloco(ox+1, y, oz+1, Material.COBBLESTONE_WALL);
        }
        bloco(ox, oy+4, oz, Material.LANTERN);
    }

    /** Muro divisório de bairro */
    private void muro(int x1, int oy, int z1, int x2, int z2, int alt) {
        if (x1 == x2) {
            for (int z = z1; z <= z2; z++)
                for (int y = oy; y < oy+alt; y++)
                    bloco(x1, y, z, Material.COBBLESTONE_WALL);
        } else {
            for (int x = x1; x <= x2; x++)
                for (int y = oy; y < oy+alt; y++)
                    bloco(x, y, z1, Material.COBBLESTONE_WALL);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS — LABORATÓRIOS
    // ═══════════════════════════════════════════════════════════════

    /** Laboratório com letras A, B, C — interior detalhado */
    private void laboratorio(int ox, int oy, int oz, int larg, int alt, int prof,
                               Random rng, String letra) {
        // Paredes externas — concreto cinza
        for (int y = oy; y < oy+alt; y++)
            for (int x = ox; x < ox+larg; x++)
                for (int z = oz; z < oz+prof; z++) {
                    boolean borda = x==ox||x==ox+larg-1||z==oz||z==oz+prof-1;
                    if (!borda) continue;
                    // Janelas largas no 2º e 3º andares
                    boolean janela = (y==oy+3 || y==oy+5) && x%4==0
                            && x>ox+1 && x<ox+larg-2;
                    bloco(x, y, z, janela ? Material.TINTED_GLASS : Material.SMOOTH_STONE);
                }

        // Teto
        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+prof; z++)
                bloco(x, oy+alt, z, Material.SMOOTH_STONE_SLAB);

        // Piso interior
        for (int x = ox+1; x < ox+larg-1; x++)
            for (int z = oz+1; z < oz+prof-1; z++)
                bloco(x, oy, z, Material.WHITE_CONCRETE);

        // Corredores internos (paredes divisórias)
        int divisao = oz + prof/2;
        for (int x = ox+1; x < ox+larg-1; x++) {
            bloco(x, oy,   divisao, Material.SMOOTH_STONE);
            bloco(x, oy+1, divisao, Material.SMOOTH_STONE);
            bloco(x, oy+2, divisao, Material.SMOOTH_STONE);
        }
        // Porta no corredor
        int px = ox + larg/2;
        bloco(px, oy,   divisao, Material.AIR);
        bloco(px, oy+1, divisao, Material.AIR);

        // Interior — equipamentos de laboratório
        for (int i = 1; i <= 3; i++) {
            int cx = ox + (larg * i / 4);
            bloco(cx, oy+1, oz+3,        Material.BREWING_STAND);
            bloco(cx, oy+1, oz+prof-4,   Material.CAULDRON);
            bloco(cx, oy+2, oz+3,        Material.GLOWSTONE);
        }
        // Mesas
        for (int x = ox+2; x < ox+larg-2; x += 4) {
            bloco(x,   oy+1, oz+6,      Material.IRON_BLOCK);
            bloco(x+1, oy+1, oz+6,      Material.IRON_BLOCK);
            bloco(x,   oy+2, oz+6,      Material.GLASS);
            bloco(x,   oy+1, divisao+3, Material.CHEST);
        }

        // Tanques de vidro com líquido (efeito)
        for (int t = 0; t < 3; t++) {
            int tx = ox + 4 + t*(larg/3);
            bloco(tx, oy+1, oz+prof-5, Material.GLASS);
            bloco(tx, oy+2, oz+prof-5, Material.GLASS);
            bloco(tx, oy+3, oz+prof-5, Material.GLASS);
            bloco(tx, oy+2, oz+prof-6, Material.LIME_STAINED_GLASS); // líquido mutante
        }

        // Entrada principal com letreiro
        int ex = ox + larg/2 - 1;
        for (int y = oy; y <= oy+3; y++)
            for (int x = ex; x <= ex+2; x++)
                bloco(x, y, oz, Material.AIR);
        bloco(ex+1, oy+4, oz-1, Material.STONE_BRICKS);  // poste
        bloco(ex+1, oy+5, oz-1, Material.LANTERN);

        // Calçada de entrada
        for (int x = ox-1; x <= ox+larg; x++)
            bloco(x, oy, oz-1, Material.SMOOTH_STONE);
        for (int x = ox-1; x <= ox+larg; x++)
            bloco(x, oy, oz-2, Material.SMOOTH_STONE);

        // Danos de explosão (lab foi atacado)
        for (int i = 0; i < larg*alt/8; i++) {
            int dx = ox+1+rng.nextInt(larg-2);
            int dy = oy+rng.nextInt(alt-1);
            int dz = oz+1+rng.nextInt(prof-2);
            if (rng.nextFloat() < 0.4f) bloco(dx, dy, dz, Material.AIR);
            else bloco(dx, dy, dz, Material.CRACKED_STONE_BRICKS);
        }
    }

    /** Guarita de segurança */
    private void guarita(int ox, int oy, int oz) {
        for (int y = oy; y < oy+4; y++)
            for (int x = ox; x < ox+4; x++)
                for (int z = oz; z < oz+4; z++) {
                    boolean borda = x==ox||x==ox+3||z==oz||z==oz+3;
                    if (borda) bloco(x, y, z, Material.SMOOTH_STONE);
                }
        bloco(ox+1, oy, oz+1, Material.GLASS_PANE);
        bloco(ox+2, oy, oz+1, Material.GLASS_PANE);
        bloco(ox+1, oy+1, oz+1, Material.GLASS_PANE);
        bloco(ox+2, oy+1, oz+1, Material.GLASS_PANE);
        bloco(ox+1, oy, oz+3, Material.AIR);
        bloco(ox+1, oy+1, oz+3, Material.AIR);
        for (int x = ox; x < ox+4; x++)
            bloco(x, oy+4, oz, Material.SMOOTH_STONE_SLAB);
        bloco(ox+1, oy+1, oz+2, Material.CHEST);
        bloco(ox+3, oy+4, oz+1, Material.LANTERN);
    }

    /** Cerca de arame ao redor de uma área */
    private void cercaArame(int ox, int oy, int oz, int larg, int prof) {
        for (int x = ox; x <= ox+larg; x++) {
            bloco(x, oy+1, oz,      Material.IRON_BARS);
            bloco(x, oy+1, oz+prof, Material.IRON_BARS);
        }
        for (int z = oz; z <= oz+prof; z++) {
            bloco(ox,      oy+1, z, Material.IRON_BARS);
            bloco(ox+larg, oy+1, z, Material.IRON_BARS);
        }
        // Postes de suporte
        for (int x = ox; x <= ox+larg; x += 8) {
            bloco(x, oy+2, oz,      Material.IRON_BLOCK);
            bloco(x, oy+2, oz+prof, Material.IRON_BLOCK);
        }
        // Portão de entrada
        int px = ox + larg/2;
        bloco(px,   oy+1, oz, Material.AIR);
        bloco(px+1, oy+1, oz, Material.AIR);
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS — COMERCIAL
    // ═══════════════════════════════════════════════════════════════

    /** Mercado / feira com barracas */
    private void mercado(int ox, int oy, int oz, Random rng) {
        // Piso
        camada(ox, oy, oz, 28, 20, Material.CHISELED_STONE_BRICKS);

        // 3 barracas em linha
        barraca(ox+2,  oy, oz+2,  rng);
        barraca(ox+12, oy, oz+2,  rng);
        barraca(ox+2,  oy, oz+12, rng);
        barraca(ox+12, oy, oz+12, rng);

        // Poste central do mercado
        for (int y = oy+1; y <= oy+5; y++) bloco(ox+14, y, oz+10, Material.OAK_FENCE);
        bloco(ox+14, oy+6, oz+10, Material.LANTERN);
    }

    private void barraca(int ox, int oy, int oz, Random rng) {
        // Balcão
        for (int x = ox; x < ox+8; x++)
            bloco(x, oy+1, oz, Material.OAK_PLANKS);
        // Telhado de lona (lã colorida)
        Material cor = switch(rng.nextInt(4)) {
            case 0 -> Material.RED_WOOL;
            case 1 -> Material.BLUE_WOOL;
            case 2 -> Material.YELLOW_WOOL;
            default -> Material.GREEN_WOOL;
        };
        for (int x = ox-1; x <= ox+8; x++)
            for (int z = oz; z <= oz+5; z++)
                bloco(x, oy+3, z, cor);
        // Postes
        for (int y = oy+1; y <= oy+3; y++) {
            bloco(ox-1,  y, oz,   Material.OAK_FENCE);
            bloco(ox+8,  y, oz,   Material.OAK_FENCE);
            bloco(ox-1,  y, oz+5, Material.OAK_FENCE);
            bloco(ox+8,  y, oz+5, Material.OAK_FENCE);
        }
        // Mercadorias no balcão
        bloco(ox+2, oy+2, oz, Material.BARREL);
        bloco(ox+5, oy+2, oz, Material.CHEST);
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS — INDUSTRIAL
    // ═══════════════════════════════════════════════════════════════

    private void fabrica(int ox, int oy, int oz, int larg, int alt, int prof, Random rng) {
        for (int y = oy; y < oy+alt; y++)
            for (int x = ox; x < ox+larg; x++)
                for (int z = oz; z < oz+prof; z++) {
                    boolean borda = x==ox||x==ox+larg-1||z==oz||z==oz+prof-1;
                    if (borda) bloco(x, y, z, Material.BRICKS);
                }
        // Janelas industriais
        for (int z = oz+2; z < oz+prof-2; z += 5) {
            bloco(ox, oy+2, z, Material.IRON_BARS);
            bloco(ox, oy+3, z, Material.IRON_BARS);
            bloco(ox+larg-1, oy+2, z, Material.IRON_BARS);
        }
        // Teto
        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+prof; z++)
                bloco(x, oy+alt, z, Material.SMOOTH_STONE_SLAB);
        // Chaminés
        for (int i = 0; i < larg/6; i++) {
            int cx = ox+3+i*6;
            for (int y = oy+alt; y <= oy+alt+5; y++) bloco(cx, y, oz+prof/2, Material.BRICKS);
            bloco(cx, oy+alt+5, oz+prof/2, Material.CAMPFIRE);
        }
        // Porta de carga larga
        for (int y = oy; y <= oy+4; y++)
            for (int x = ox+larg/2-2; x <= ox+larg/2+2; x++)
                bloco(x, y, oz, Material.AIR);
        // Interior
        bloco(ox+2, oy+1, oz+3, Material.BLAST_FURNACE);
        bloco(ox+larg-3, oy+1, oz+3, Material.SMOKER);
        for (int x = ox+2; x < ox+larg-2; x += 5)
            bloco(x, oy+1, oz+prof-3, Material.CHEST);
    }

    /** Tanque cilíndrico de combustível */
    private void tanque(int ox, int oy, int oz, int raio) {
        for (int y = oy; y <= oy+raio; y++) {
            for (int x = ox-raio; x <= ox+raio; x++)
                for (int z = oz-raio; z <= oz+raio; z++) {
                    double d = Math.sqrt(Math.pow(x-ox,2)+Math.pow(z-oz,2));
                    if (d >= raio-0.5 && d <= raio+0.5)
                        bloco(x, y, z, Material.IRON_BLOCK);
                }
        }
        // Escada lateral
        for (int y = oy; y <= oy+raio; y++) bloco(ox+raio+1, y, oz, Material.LADDER);
        bloco(ox, oy+raio+1, oz, Material.CAMPFIRE);
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS — PRÉDIOS URBANOS
    // ═══════════════════════════════════════════════════════════════

    private void predio(int ox, int oy, int oz, int larg, int alt, int prof,
                        Random rng, Material mat, Material vidro) {
        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+prof; z++)
                bloco(x, oy-1, z, Material.STONE_BRICK_SLAB);

        for (int y = oy; y < oy+alt; y++)
            for (int x = ox; x < ox+larg; x++)
                for (int z = oz; z < oz+prof; z++) {
                    boolean borda = x==ox||x==ox+larg-1||z==oz||z==oz+prof-1;
                    if (!borda) continue;
                    boolean janela = y > oy && y < oy+alt-1 && y%2==0
                            && x!=ox && x!=ox+larg-1 && z!=oz && z!=oz+prof-1;
                    if (janela && rng.nextFloat() < 0.55f)
                        bloco(x, y, z, rng.nextFloat()<0.3f ? Material.GLASS : vidro);
                    else
                        bloco(x, y, z, rng.nextFloat()<0.08f ? Material.CRACKED_STONE_BRICKS : mat);
                }

        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+prof; z++) {
                bloco(x, oy+alt, z, Material.STONE_BRICK_SLAB);
                if (x==ox||x==ox+larg-1||z==oz||z==oz+prof-1)
                    bloco(x, oy+alt+1, z, Material.STONE_BRICK_WALL);
            }

        for (int i = 0; i < (int)(larg*alt*0.06f); i++)
            bloco(ox+rng.nextInt(larg), oy+1+rng.nextInt(alt-1), oz+rng.nextInt(prof), Material.AIR);

        int px = ox+larg/2;
        bloco(px,   oy,   oz, Material.AIR); bloco(px,   oy+1, oz, Material.AIR);
        bloco(px-1, oy,   oz, Material.AIR); bloco(px-1, oy+1, oz, Material.AIR);
        bloco(ox+larg/2, oy+alt-1, oz-1, Material.LANTERN);
    }

    private void pracaCentral(int ox, int oy, int oz) {
        for (int x = ox-12; x <= ox+12; x++)
            for (int z = oz-12; z <= oz+12; z++) {
                double d = Math.sqrt(Math.pow(x-ox,2)+Math.pow(z-oz,2));
                if (d <= 12) bloco(x, oy, z, d > 9 ? Material.STONE_BRICK_SLAB : Material.CHISELED_STONE_BRICKS);
            }
        // Estátua central
        for (int y = oy+1; y <= oy+8; y++) bloco(ox, y, oz, Material.STONE_BRICKS);
        bloco(ox, oy+9, oz, Material.CRACKED_STONE_BRICKS);
        bloco(ox, oy+10, oz, Material.STONE_BRICK_WALL);
        // Bancos e lanternas
        for (int i = 0; i < 4; i++) {
            int bx = (int)(ox+Math.cos(Math.PI/2*i)*7);
            int bz = (int)(oz+Math.sin(Math.PI/2*i)*7);
            bloco(bx, oy+1, bz, Material.STONE_BRICK_SLAB);
            bloco(bx+1, oy+1, bz, Material.STONE_BRICK_SLAB);
            bloco(bx, oy+3, bz, Material.LANTERN);
        }
        // Fonte
        for (int x = ox-2; x <= ox+2; x++)
            for (int z = oz-2; z <= oz+2; z++) {
                double d = Math.sqrt(Math.pow(x-ox,2)+Math.pow(z-oz,2));
                if (d <= 2) { bloco(x, oy, z, Material.STONE_BRICKS); bloco(x, oy-1, z, Material.WATER); }
            }
    }

    private void estacao(int ox, int oy, int oz, int larg, int alt) {
        for (int x = ox; x < ox+larg; x++)
            for (int z = oz; z < oz+12; z++)
                bloco(x, oy, z, Material.STONE_BRICKS);
        for (int x = ox; x < ox+larg; x++) {
            for (int z = oz; z < oz+12; z++) bloco(x, oy+alt, z, Material.IRON_BARS);
        }
        for (int x = ox; x < ox+larg; x += 8) {
            for (int y = oy+1; y <= oy+alt; y++) bloco(x, y, oz+11, Material.STONE_BRICKS);
            for (int y = oy+1; y <= oy+alt; y++) bloco(x, y, oz, Material.STONE_BRICKS);
        }
        for (int x = ox; x < ox+larg; x++) bloco(x, oy+1, oz+5, Material.RAIL);
        bloco(ox+larg/2, oy+1, oz-1, Material.OAK_WALL_SIGN);
        bloco(ox+larg/2, oy+2, oz, Material.LANTERN);
    }

    // ═══════════════════════════════════════════════════════════════
    // DETALHES — CARROS DESTRUÍDOS
    // ═══════════════════════════════════════════════════════════════

    private void carrosDestruidos(int oz, int prof, Random rng) {
        for (int i = 0; i < 18; i++) {
            int cx = 2 + rng.nextInt(76);
            int cz = oz + 10 + rng.nextInt(prof - 20);
            // Corpo do carro (ferro)
            for (int x = cx; x < cx+4; x++)
                for (int z = cz; z < cz+2; z++)
                    bloco(x, BASE_Y, z, Material.IRON_BLOCK);
            // Vidros quebrados
            if (rng.nextBoolean()) bloco(cx+1, BASE_Y+1, cz, Material.GLASS_PANE);
            // Fogo ocasional
            if (rng.nextFloat() < 0.3f) bloco(cx+2, BASE_Y+1, cz+1, Material.FIRE);
            // Rodas (log)
            bloco(cx,   BASE_Y, cz-1, Material.OAK_LOG);
            bloco(cx+3, BASE_Y, cz-1, Material.OAK_LOG);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // NÍVEL 2 — FLORESTA INFECTADA
    // ═══════════════════════════════════════════════════════════════

    private void montarNivel2() {
        fila.clear();
        int oz = ESPACAMENTO;
        Random rng = new Random(202);

        camada(0, BASE_Y-1, oz, 80, 380, Material.MOSS_BLOCK);
        camada(0, BASE_Y-2, oz, 80, 380, Material.MOSSY_COBBLESTONE);
        camada(0, BASE_Y-3, oz, 80, 380, Material.DIRT);

        for (int z = oz; z < oz+380; z++)
            for (int x = 36; x <= 43; x++)
                bloco(x, BASE_Y, z, Material.DIRT_PATH);

        for (int z = oz+20; z < oz+340; z += 18) {
            for (int x = 2; x <= 30; x += 8) arvoreMutante(x, BASE_Y, z, 8+rng.nextInt(8), rng);
            for (int x = 48; x <= 76; x += 8) arvoreMutante(x, BASE_Y, z, 7+rng.nextInt(9), rng);
        }

        ponteSelva(18, BASE_Y+12, oz+55,  oz+95);
        ponteSelva(18, BASE_Y+14, oz+145, oz+195);
        ponteSelva(48, BASE_Y+13, oz+85,  oz+135);
        ponteSelva(18, BASE_Y+15, oz+225, oz+275);

        pantano(0,  BASE_Y, oz+80,  80, 22, rng);
        pantano(0,  BASE_Y, oz+210, 80, 28, rng);

        ruinaAntiga(5,  BASE_Y, oz+120, 14, 6, rng);
        ruinaAntiga(55, BASE_Y, oz+175, 12, 5, rng);
        ruinaAntiga(8,  BASE_Y, oz+280, 16, 7, rng);

        tocaAranha(15, BASE_Y, oz+305, rng);

        checkpoint(38, BASE_Y, oz+120, "§6§l✦ PONTO DE CONTROLE 1");
        checkpoint(38, BASE_Y, oz+250, "§6§l✦ PONTO DE CONTROLE 2");

        arenaChefe(40, BASE_Y, oz+345, 26, Material.MOSSY_STONE_BRICKS, Material.MOSS_BLOCK);

        iluminacaoFloresta(oz, 360);
        processarFila();
    }

    // ═══════════════════════════════════════════════════════════════
    // NÍVEL 3 — RUÍNAS DE GUERRA
    // ═══════════════════════════════════════════════════════════════

    private void montarNivel3() {
        fila.clear();
        int oz = ESPACAMENTO * 2;
        Random rng = new Random(303);

        camada(0, BASE_Y-1, oz, 80, 380, Material.SMOOTH_STONE);
        camada(0, BASE_Y-2, oz, 80, 380, Material.IRON_BLOCK);
        camada(0, BASE_Y-3, oz, 80, 380, Material.COBBLESTONE);
        camada(34, BASE_Y,  oz, 8,  380, Material.GRAVEL);

        bunker(1,  BASE_Y, oz+18,  18, 6, 14);
        bunker(58, BASE_Y, oz+18,  20, 7, 16);
        trincheira(0,  BASE_Y, oz+60, 30, 4);
        trincheira(50, BASE_Y, oz+60, 28, 4);
        bunker(10, BASE_Y, oz+90,  26, 8, 18);

        veiculo(5,  BASE_Y, oz+120, rng);
        veiculo(55, BASE_Y, oz+135, rng);
        veiculo(22, BASE_Y, oz+170, rng);
        veiculo(48, BASE_Y, oz+185, rng);

        crateras(oz+110, oz+210, rng);
        complexoIndustrial(0, BASE_Y, oz+220, oz+295);
        torreVigia(60, BASE_Y, oz+155, 16);
        torreVigia(4,  BASE_Y, oz+240, 14);

        checkpoint(38, BASE_Y, oz+110, "§6§l✦ PONTO DE CONTROLE 1");
        checkpoint(38, BASE_Y, oz+215, "§6§l✦ PONTO DE CONTROLE 2");
        checkpoint(38, BASE_Y, oz+295, "§6§l✦ PONTO DE CONTROLE 3");

        arenaChefe(40, BASE_Y, oz+330, 26, Material.IRON_BLOCK, Material.CHISELED_STONE_BRICKS);

        iluminacaoGuerra(oz, 350);
        processarFila();
    }

    // ═══════════════════════════════════════════════════════════════
    // NÍVEL 4 — COVIL DO DRAGÃO
    // ═══════════════════════════════════════════════════════════════

    private void montarNivel4() {
        fila.clear();
        int oz = ESPACAMENTO * 3;
        Random rng = new Random(404);

        camada(0, BASE_Y-1, oz, 80, 380, Material.BLACKSTONE);
        camada(0, BASE_Y-2, oz, 80, 380, Material.NETHERRACK);
        camada(0, BASE_Y-3, oz, 80, 380, Material.SOUL_SAND);

        for (int z = oz+35; z < oz+340; z++)
            for (int x = 36; x <= 43; x++) {
                bloco(x, BASE_Y-1, z, Material.LAVA);
                bloco(x, BASE_Y,   z, Material.AIR);
            }

        ponteObsidiana(0,  BASE_Y, oz+90,  36, 8);
        ponteObsidiana(0,  BASE_Y, oz+185, 36, 8);
        ponteObsidiana(0,  BASE_Y, oz+275, 36, 8);

        for (int z = oz+25; z < oz+330; z += 20) {
            pilar(2+rng.nextInt(28),  BASE_Y, z, 6+rng.nextInt(8), rng);
            pilar(50+rng.nextInt(28), BASE_Y, z, 5+rng.nextInt(9), rng);
        }

        tunelLava(5,  BASE_Y, oz+55,  oz+100);
        tunelLava(50, BASE_Y, oz+140, oz+175);
        temploNether(5, BASE_Y, oz+195, 56, 18, 44);

        altar(10,  BASE_Y, oz+70,  rng);
        altar(65,  BASE_Y, oz+115, rng);
        altar(10,  BASE_Y, oz+260, rng);

        checkpoint(15, BASE_Y, oz+110, "§6§l✦ PONTO DE CONTROLE 1");
        checkpoint(63, BASE_Y, oz+195, "§6§l✦ PONTO DE CONTROLE 2");
        checkpoint(15, BASE_Y, oz+295, "§6§l✦ PONTO DE CONTROLE 3");

        arenaFinalDragao(40, BASE_Y, oz+345);

        iluminacaoNether(oz, 360);
        processarFila();
    }

    // ═══════════════════════════════════════════════════════════════
    // ESTRUTURAS COMPARTILHADAS (floresta, guerra, covil)
    // ═══════════════════════════════════════════════════════════════

    private void arvoreMutante(int ox, int oy, int oz, int alt, Random rng) {
        Material tronco = rng.nextBoolean() ? Material.DARK_OAK_LOG : Material.OAK_LOG;
        Material folha  = rng.nextBoolean() ? Material.AZALEA_LEAVES : Material.DARK_OAK_LEAVES;
        int dx=0, dz=0;
        for (int y=oy;y<oy+alt;y++) {
            bloco(ox+dx,y,oz+dz,tronco);
            if (y%4==0&&rng.nextBoolean()) dx+=rng.nextInt(3)-1;
            if (y%4==0&&rng.nextBoolean()) dz+=rng.nextInt(3)-1;
        }
        for (int g=0;g<2+rng.nextInt(3);g++) {
            int gy=oy+alt/2+rng.nextInt(alt/2);
            int gxF=ox+dx+rng.nextInt(7)-3, gzF=oz+dz+rng.nextInt(7)-3;
            for (int s=0;s<=4;s++) bloco(ox+dx+(gxF-ox-dx)*s/4,gy,oz+dz+(gzF-oz-dz)*s/4,tronco);
            for (int lx=-2;lx<=2;lx++) for (int ly=-1;ly<=1;ly++) for (int lz=-2;lz<=2;lz++)
                if (rng.nextFloat()>0.35f) bloco(gxF+lx,gy+ly,gzF+lz,folha);
        }
        int tx=ox+dx,tz=oz+dz,ty=oy+alt;
        for (int lx=-3;lx<=3;lx++) for (int ly=-1;ly<=3;ly++) for (int lz=-3;lz<=3;lz++)
            if (Math.abs(lx)+Math.abs(lz)+Math.abs(ly)<=4&&rng.nextFloat()>0.2f) bloco(tx+lx,ty+ly,tz+lz,folha);
        for (int x=ox-1;x<=ox+1;x++) for (int z=oz-1;z<=oz+1;z++) if (rng.nextBoolean()) bloco(x,oy,z,Material.MOSS_BLOCK);
    }

    private void ponteSelva(int ox,int oy,int ozI,int ozF) {
        for (int z=ozI;z<=ozF;z++) {
            bloco(ox+1,oy,z,Material.JUNGLE_PLANKS); bloco(ox+2,oy,z,Material.JUNGLE_PLANKS); bloco(ox+3,oy,z,Material.JUNGLE_PLANKS);
            if (z%2==0) { bloco(ox,oy+1,z,Material.OAK_FENCE); bloco(ox+4,oy+1,z,Material.OAK_FENCE); }
            if (z%5==0) for (int d=1;d<=3;d++) bloco(ox+2,oy-d,z,Material.VINE);
        }
    }

    private void pantano(int ox,int oy,int oz,int larg,int prof,Random rng) {
        for (int x=ox;x<ox+larg;x++) for (int z=oz;z<oz+prof;z++) {
            float r=rng.nextFloat();
            if (r<0.45f) bloco(x,oy-1,z,Material.WATER);
            else if (r<0.65f) bloco(x,oy,z,Material.LILY_PAD);
            else bloco(x,oy,z,rng.nextBoolean()?Material.GRASS_BLOCK:Material.MOSS_BLOCK);
            if (r<0.08f) bloco(x,oy+1,z,Material.BROWN_MUSHROOM);
        }
    }

    private void ruinaAntiga(int ox,int oy,int oz,int larg,int alt,Random rng) {
        for (int x=ox;x<ox+larg;x++) for (int y=oy;y<oy+alt;y++) for (int z=oz;z<oz+larg;z++) {
            boolean borda=x==ox||x==ox+larg-1||z==oz||z==oz+larg-1;
            if (borda&&rng.nextFloat()>0.25f) bloco(x,y,z,Material.MOSSY_STONE_BRICKS);
        }
        bloco(ox+larg/2,oy+1,oz+larg/2,Material.LECTERN);
    }

    private void tocaAranha(int ox,int oy,int oz,Random rng) {
        for (int x=ox;x<ox+20;x++) for (int z=oz;z<oz+20;z++) {
            bloco(x,oy,z,Material.COBWEB);
            if (rng.nextFloat()<0.3f) bloco(x,oy+1,z,Material.COBWEB);
        }
        bloco(ox+10,oy+2,oz+10,Material.SPAWNER);
    }

    private void bunker(int ox,int oy,int oz,int larg,int alt,int prof) {
        for (int y=oy;y<oy+alt;y++) for (int x=ox;x<ox+larg;x++) for (int z=oz;z<oz+prof;z++) {
            boolean borda=x==ox||x==ox+larg-1||z==oz||z==oz+prof-1||y==oy||y==oy+alt-1;
            if (borda) bloco(x,y,z,Material.SMOOTH_STONE);
        }
        for (int z=oz+2;z<oz+prof-2;z+=4) { bloco(ox,oy+2,z,Material.AIR); bloco(ox+larg-1,oy+2,z,Material.AIR); }
        for (int y=oy;y<=oy+2;y++) for (int x=ox+larg/2-1;x<=ox+larg/2+1;x++) bloco(x,y,oz+prof-1,Material.AIR);
        bloco(ox+2,oy+1,oz+2,Material.CHEST);
        bloco(ox+larg-3,oy+1,oz+2,Material.BARREL);
        for (int x=ox;x<ox+larg;x++) bloco(x,oy,oz-1,Material.SAND);
    }

    private void trincheira(int ox,int oy,int oz,int larg,int prof) {
        for (int x=ox;x<ox+larg;x++) for (int d=0;d<prof;d++) for (int y=oy-d;y<=oy;y++) bloco(x,y,oz+d,Material.AIR);
        for (int x=ox;x<ox+larg;x++) bloco(x,oy-prof+1,oz+prof/2,Material.OAK_PLANKS);
        for (int x=ox+2;x<ox+larg-2;x+=5) { bloco(x,oy-1,oz+1,Material.OAK_LOG); bloco(x,oy-1,oz+prof-2,Material.OAK_LOG); }
    }

    private void veiculo(int ox,int oy,int oz,Random rng) {
        for (int x=ox;x<ox+6;x++) for (int z=oz;z<oz+4;z++) bloco(x,oy,z,Material.IRON_BLOCK);
        for (int x=ox+1;x<ox+5;x++) for (int z=oz;z<oz+3;z++) bloco(x,oy+1,z,Material.IRON_BLOCK);
        bloco(ox,oy,oz,Material.OAK_LOG); bloco(ox+5,oy,oz,Material.OAK_LOG);
        bloco(ox,oy,oz+3,Material.OAK_LOG); bloco(ox+5,oy,oz+3,Material.OAK_LOG);
        for (int i=0;i<8;i++) bloco(ox+rng.nextInt(6),oy+rng.nextInt(2),oz+rng.nextInt(4),Material.AIR);
        if (rng.nextBoolean()) bloco(ox+3,oy+2,oz+1,Material.CAMPFIRE);
    }

    private void crateras(int ozI,int ozF,Random rng) {
        for (int i=0;i<(ozF-ozI)/10;i++) {
            int cx=5+rng.nextInt(70),cz=ozI+rng.nextInt(ozF-ozI),r=2+rng.nextInt(4);
            for (int x=cx-r;x<=cx+r;x++) for (int z=cz-r;z<=cz+r;z++) {
                if (Math.sqrt(Math.pow(x-cx,2)+Math.pow(z-cz,2))<=r) {
                    bloco(x,BASE_Y,z,Material.AIR); bloco(x,BASE_Y-1,z,Material.GRAVEL);
                }
            }
        }
    }

    private void complexoIndustrial(int ox,int oy,int ozI,int ozF) {
        int alt=oy+10;
        for (int z=ozI;z<ozF;z++) for (int x=ox+10;x<ox+60;x++) if (z%2==0) bloco(x,alt,z,Material.SMOOTH_STONE_SLAB);
        for (int z=ozI;z<ozF;z+=10) for (int x:new int[]{ox+12,ox+30,ox+48}) {
            for (int y=oy;y<=alt;y++) bloco(x,y,z,Material.IRON_BLOCK);
            bloco(x,alt+1,z,Material.IRON_BARS);
        }
    }

    private void torreVigia(int ox,int oy,int oz,int alt) {
        for (int y=oy;y<oy+alt;y++) {
            bloco(ox,y,oz,Material.IRON_BLOCK); bloco(ox+4,y,oz,Material.IRON_BLOCK);
            bloco(ox,y,oz+4,Material.IRON_BLOCK); bloco(ox+4,y,oz+4,Material.IRON_BLOCK);
        }
        for (int x=ox-1;x<=ox+5;x++) for (int z=oz-1;z<=oz+5;z++) bloco(x,oy+alt,z,Material.SMOOTH_STONE);
        for (int x=ox-1;x<=ox+5;x++) { bloco(x,oy+alt+1,oz-1,Material.IRON_BARS); bloco(x,oy+alt+1,oz+5,Material.IRON_BARS); }
        for (int y=oy;y<oy+alt;y++) bloco(ox-1,y,oz+2,Material.LADDER);
    }

    private void pilar(int ox,int oy,int oz,int alt,Random rng) {
        for (int y=oy;y<oy+alt;y++) {
            int r=Math.max(1,(alt-(y-oy))/3);
            for (int dx=-r;dx<=r;dx++) for (int dz=-r;dz<=r;dz++)
                if (Math.abs(dx)+Math.abs(dz)<=r&&rng.nextFloat()>0.15f) bloco(ox+dx,y,oz+dz,Material.BLACKSTONE);
        }
        bloco(ox,oy+alt,oz,Material.OBSIDIAN);
    }

    private void ponteObsidiana(int ox,int oy,int oz,int xI,int larg) {
        for (int x=xI;x<xI+larg;x++) {
            bloco(x,oy,oz,Material.OBSIDIAN); bloco(x,oy,oz+1,Material.OBSIDIAN);
            bloco(x,oy+1,oz-1,Material.BLACKSTONE_WALL); bloco(x,oy+1,oz+2,Material.BLACKSTONE_WALL);
        }
    }

    private void tunelLava(int ox,int oy,int ozI,int ozF) {
        for (int z=ozI;z<=ozF;z++) {
            for (int r=-4;r<=4;r++) for (int y=oy;y<=oy+6;y++) {
                double d=Math.sqrt(r*r+Math.pow(y-oy,2));
                if (d>=3.5&&d<=4.5) bloco(ox+8+r,y,z,Material.BLACKSTONE);
            }
            for (int x=ox+4;x<=ox+12;x++) bloco(x,oy,z,Material.POLISHED_BLACKSTONE_BRICKS);
        }
    }

    private void temploNether(int ox,int oy,int oz,int larg,int alt,int prof) {
        for (int x=ox;x<ox+larg;x++) for (int z=oz;z<oz+prof;z++) bloco(x,oy,z,Material.POLISHED_BLACKSTONE_BRICKS);
        for (int y=oy+1;y<oy+alt;y++) for (int x=ox;x<ox+larg;x++) for (int z=oz;z<oz+prof;z++) {
            boolean borda=x==ox||x==ox+larg-1||z==oz||z==oz+prof-1;
            if (borda) bloco(x,y,z,Material.NETHER_BRICKS);
        }
        for (int cx:new int[]{ox+4,ox+larg-5}) for (int cz:new int[]{oz+4,oz+prof-5})
            for (int y=oy+1;y<oy+alt-2;y++) bloco(cx,y,cz,Material.NETHER_BRICK_FENCE);
        bloco(ox+larg/2,oy+2,oz+prof/2,Material.RESPAWN_ANCHOR);
    }

    private void altar(int ox,int oy,int oz,Random rng) {
        for (int x=ox;x<ox+5;x++) for (int z=oz;z<oz+5;z++) bloco(x,oy,z,Material.POLISHED_BLACKSTONE_BRICKS);
        for (int y=oy+1;y<=oy+3;y++) {
            bloco(ox,y,oz,Material.BLACKSTONE); bloco(ox+4,y,oz,Material.BLACKSTONE);
            bloco(ox,y,oz+4,Material.BLACKSTONE); bloco(ox+4,y,oz+4,Material.BLACKSTONE);
        }
        bloco(ox+2,oy+1,oz+2,rng.nextBoolean()?Material.SOUL_LANTERN:Material.CRYING_OBSIDIAN);
    }

    private void arenaFinalDragao(int ox,int oy,int oz) {
        int raio=32;
        for (int x=ox-raio;x<=ox+raio;x++) for (int z=oz-raio;z<=oz+raio;z++) {
            double d=Math.sqrt(Math.pow(x-ox,2)+Math.pow(z-oz,2));
            if (d<=raio) { bloco(x,oy,z,Material.END_STONE_BRICKS); bloco(x,oy-1,z,Material.BEDROCK); }
            if (d>raio-2.5&&d<=raio) for (int y=oy+1;y<=oy+8;y++) bloco(x,y,z,Material.OBSIDIAN);
        }
        for (int i=0;i<4;i++) {
            int px=(int)(ox+Math.cos(Math.PI/2*i)*12),pz=(int)(oz+Math.sin(Math.PI/2*i)*12);
            for (int y=oy+1;y<=oy+10;y++) bloco(px,y,pz,Material.CRYING_OBSIDIAN);
            bloco(px,oy+11,pz,Material.END_ROD);
        }
        bloco(ox,oy+1,oz,Material.DRAGON_EGG);
        for (int dz=oz-3;dz<=oz+3;dz++) for (int y=oy+1;y<=oy+7;y++) bloco(ox-raio,y,dz,Material.AIR);
    }

    private void checkpoint(int ox,int oy,int oz,String nome) {
        for (int x=ox-2;x<=ox+2;x++) for (int z=oz-2;z<=oz+2;z++) bloco(x,oy,z,Material.GOLD_BLOCK);
        for (int y=oy+1;y<=oy+4;y++) bloco(ox,y,oz,Material.BEACON);
        bloco(ox,oy+5,oz,Material.GOLD_BLOCK);
        bloco(ox+3,oy+1,oz,Material.LECTERN);
    }

    private void arenaChefe(int ox,int oy,int oz,int raio,Material piso,Material parede) {
        for (int x=ox-raio;x<=ox+raio;x++) for (int z=oz-raio;z<=oz+raio;z++) {
            double d=Math.sqrt(Math.pow(x-ox,2)+Math.pow(z-oz,2));
            if (d<=raio) { bloco(x,oy,z,piso); bloco(x,oy-1,z,parede); }
            if (d>raio-2&&d<=raio) for (int y=oy+1;y<=oy+5;y++) bloco(x,y,z,parede);
        }
        for (int dz=oz-2;dz<=oz+2;dz++) for (int y=oy+1;y<=oy+4;y++) bloco(ox-raio,y,dz,Material.AIR);
    }

    // ═══════════════════════════════════════════════════════════════
    // DETALHES AMBIENTAIS
    // ═══════════════════════════════════════════════════════════════

    private void iluminacaoCidade(int oz,int prof) {
        for (int z=oz+8;z<oz+prof;z+=12) for (int x=4;x<80;x+=14) {
            bloco(x,BASE_Y+4,z,Material.LANTERN);
            bloco(x,BASE_Y+3,z,Material.IRON_BARS);
            bloco(x,BASE_Y+2,z,Material.IRON_BARS);
            bloco(x,BASE_Y+1,z,Material.IRON_BARS);
        }
    }

    private void iluminacaoFloresta(int oz,int prof) {
        for (int z=oz+10;z<oz+prof;z+=18) for (int x=15;x<65;x+=18) bloco(x,BASE_Y+2,z,Material.SOUL_LANTERN);
    }

    private void iluminacaoGuerra(int oz,int prof) {
        for (int z=oz+10;z<oz+prof;z+=14) for (int x=5;x<75;x+=16) bloco(x,BASE_Y+3,z,Material.SHROOMLIGHT);
    }

    private void iluminacaoNether(int oz,int prof) {
        for (int z=oz+12;z<oz+prof;z+=16) for (int x=5;x<75;x+=18) bloco(x,BASE_Y+5,z,Material.GLOWSTONE);
    }

    private void entulho(int oz,int prof,Random rng) {
        Material[] mats={Material.GRAVEL,Material.COBBLESTONE,Material.STONE_BRICKS,Material.CRACKED_STONE_BRICKS,Material.DIRT};
        for (int i=0;i<350;i++) bloco(1+rng.nextInt(78),BASE_Y,oz+rng.nextInt(prof),mats[rng.nextInt(mats.length)]);
    }

    private void vegetacaoUrbana(int oz,int prof,Random rng) {
        for (int i=0;i<70;i++) bloco(rng.nextInt(80),BASE_Y,oz+rng.nextInt(prof),rng.nextBoolean()?Material.SHORT_GRASS:Material.FERN);
    }

    // ═══════════════════════════════════════════════════════════════
    // MOTOR DE FILA
    // ═══════════════════════════════════════════════════════════════

    private void bloco(int x,int y,int z,Material mat) { fila.add(new int[]{x,y,z,mat.ordinal()}); }

    private void camada(int ox,int oy,int oz,int larg,int prof,Material mat) {
        for (int x=ox;x<ox+larg;x++) for (int z=oz;z<oz+prof;z++) bloco(x,oy,z,mat);
    }

    private void processarFila() {
        final List<int[]> snap = new ArrayList<>(fila);
        fila.clear();
        new BukkitRunnable() {
            int pos=0;
            @Override public void run() {
                int fim=Math.min(pos+LOTE,snap.size());
                for (int i=pos;i<fim;i++) {
                    int[] b=snap.get(i);
                    mundo.getBlockAt(b[0],b[1],b[2]).setType(MATS[b[3]],false);
                }
                pos=fim;
                if (pos>=snap.size()) cancel();
            }
        }.runTaskTimer(plugin,1L,1L);
    }

    // ═══════════════════════════════════════════════════════════════
    // API PÚBLICA
    // ═══════════════════════════════════════════════════════════════

    public World getMundo()      { return mundo; }
    public World getLevelWorld() { return mundo; }
    public boolean isGenerated() { return mundo != null; }

    public Location getLevelSpawn(int nivel) {
        int oz=(nivel-1)*ESPACAMENTO;
        return new Location(mundo,40,BASE_Y+1,oz+5);
    }

    public List<Location> getLevelCheckpoints(int nivel) {
        int oz=(nivel-1)*ESPACAMENTO;
        return switch (nivel) {
            case 1 -> List.of(
                new Location(mundo,38,BASE_Y+1,oz+115),
                new Location(mundo,38,BASE_Y+1,oz+288),
                new Location(mundo,38,BASE_Y+1,oz+465));
            case 2 -> List.of(
                new Location(mundo,38,BASE_Y+1,oz+120),
                new Location(mundo,38,BASE_Y+1,oz+250));
            case 3 -> List.of(
                new Location(mundo,38,BASE_Y+1,oz+110),
                new Location(mundo,38,BASE_Y+1,oz+215),
                new Location(mundo,38,BASE_Y+1,oz+295));
            case 4 -> List.of(
                new Location(mundo,15,BASE_Y+1,oz+110),
                new Location(mundo,63,BASE_Y+1,oz+195),
                new Location(mundo,15,BASE_Y+1,oz+295));
            default -> List.of(getLevelSpawn(nivel));
        };
    }

    public Location getBossArenaCenter(int nivel) {
        int oz=(nivel-1)*ESPACAMENTO;
        return switch (nivel) {
            case 1 -> new Location(mundo,40,BASE_Y+1,oz+645);
            case 2 -> new Location(mundo,40,BASE_Y+1,oz+345);
            case 3 -> new Location(mundo,40,BASE_Y+1,oz+330);
            case 4 -> new Location(mundo,40,BASE_Y+1,oz+345);
            default -> getLevelSpawn(nivel);
        };
    }
}
