package com.dogapocalypse.enemies;

import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

// =============================================================
// MUTANT INSECT
// =============================================================

/**
 * Fast, swarming insect-like enemy. Uses Cave Spider base.
 * Special: Poisons target on hit (handled via event).
 */
class MutantInsect extends CustomEnemy {

    MutantInsect() {
        super("mutant_insect", "&aMutant Insect", 12, 3, 0.38, null, 5);
    }

    @Override
    public void setup(LivingEntity e) {
        this.entity = e;
        e.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        e.setCustomNameVisible(true);
        var attr = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) { attr.setBaseValue(maxHealth); e.setHealth(maxHealth); }
        var spd = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(speed);
    }

    @Override
    public void tick() {
        if (!isAlive() || target == null) return;
        // Walk toward target; vanilla pathfinding handles movement
        // Special: every 5s apply brief speed burst
        specialAttackCooldown++;
        if (specialAttackCooldown >= 100) {
            entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 2, false, false));
            specialAttackCooldown = 0;
        }
    }

    @Override
    public void onDeath(Player killer) {
        Location loc = getLocation();
        if (loc == null) return;
        loc.getWorld().spawnParticle(Particle.SLIME, loc, 10, 0.4, 0.4, 0.4, 0.05);
        loc.getWorld().playSound(loc, Sound.ENTITY_SPIDER_DEATH, 1f, 1.5f);
    }
}

// =============================================================
// RADIOACTIVE MONKEY
// =============================================================

/**
 * Agile, jumping enemy. Uses Pillager base.
 * Special: Leap toward target every 6s.
 */
class RadioactiveMonkey extends CustomEnemy {

    RadioactiveMonkey() {
        super("radioactive_monkey", "&2Radioactive Monkey", 20, 5, 0.32, null, 10);
    }

    @Override
    public void setup(LivingEntity e) {
        this.entity = e;
        e.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        e.setCustomNameVisible(true);
        var attr = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) { attr.setBaseValue(maxHealth); e.setHealth(maxHealth); }
        var spd = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(speed);
        // Glow green to simulate radiation
        e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
    }

    @Override
    public void tick() {
        if (!isAlive() || target == null) return;
        specialAttackCooldown++;
        if (specialAttackCooldown >= 120) {
            // Leap
            Vector toTarget = target.getLocation().subtract(entity.getLocation()).toVector();
            double dist = toTarget.length();
            if (dist < 20) {
                toTarget.normalize().multiply(1.2).setY(0.8);
                entity.setVelocity(toTarget);
                entity.getWorld().spawnParticle(Particle.VILLAGER_ANGRY,
                        entity.getLocation().add(0, 1, 0), 5, 0.2, 0.2, 0.2, 0);
            }
            specialAttackCooldown = 0;
        }
    }

    @Override
    public void onDeath(Player killer) {
        Location loc = getLocation();
        if (loc == null) return;
        loc.getWorld().spawnParticle(Particle.VILLAGER_ANGRY, loc.add(0,1,0), 15, 0.5, 0.5, 0.5, 0.05);
        loc.getWorld().playSound(loc, Sound.ENTITY_PILLAGER_DEATH, 1f, 0.8f);
        // Leave a small radiation cloud
        loc.getWorld().spawnParticle(Particle.ENTITY_EFFECT, loc, 30, 0.5, 0.5, 0.5, 0, Color.fromRGB(0, 200, 0));
    }
}

// =============================================================
// INFECTED WOLF
// =============================================================

/**
 * Fast aggressive wolf-type enemy. High damage.
 * Special: Howl that buffs nearby enemies every 8s.
 */
class InfectedWolf extends CustomEnemy {

    InfectedWolf() {
        super("infected_wolf", "&cInfected Wolf", 25, 7, 0.40, null, 12);
    }

    @Override
    public void setup(LivingEntity e) {
        this.entity = e;
        e.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        e.setCustomNameVisible(true);
        var attr = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) { attr.setBaseValue(maxHealth); e.setHealth(maxHealth); }
        var spd = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(speed);
    }

    @Override
    public void tick() {
        if (!isAlive()) return;
        specialAttackCooldown++;
        if (specialAttackCooldown >= 160) {
            // Howl: buff nearby hostile entities
            entity.getWorld().getNearbyEntities(entity.getLocation(), 10, 5, 10).forEach(e -> {
                if (e instanceof Monster) {
                    ((Monster) e).addPotionEffect(
                            new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 80, 0, false, false));
                }
            });
            entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_WOLF_HOWL, 1f, 0.8f);
            entity.getWorld().spawnParticle(Particle.NOTE, entity.getLocation().add(0,2,0), 10, 0.5, 0.3, 0.5, 1);
            specialAttackCooldown = 0;
        }
    }

    @Override
    public void onDeath(Player killer) {
        Location loc = getLocation();
        if (loc == null) return;
        loc.getWorld().playSound(loc, Sound.ENTITY_WOLF_DEATH, 1f, 0.7f);
        loc.getWorld().spawnParticle(Particle.CRIT, loc.add(0,1,0), 20, 0.4, 0.4, 0.4, 0.1);
    }
}

// =============================================================
// FLAME BLAZE (Absorbable -> BlazePower)
// =============================================================

/**
 * A mutated blaze-type creature. Killing it lets Dog players absorb Blaze Power.
 */
class FlameBlaze extends CustomEnemy {

    FlameBlaze() {
        super("flame_blaze", "&6Flame Blaze", 18, 4, 0.28, "blaze", 15);
    }

    @Override
    public void setup(LivingEntity e) {
        this.entity = e;
        e.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        e.setCustomNameVisible(true);
        var attr = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) { attr.setBaseValue(maxHealth); e.setHealth(maxHealth); }
        e.setFireTicks(Integer.MAX_VALUE); // permanently on fire
    }

    @Override
    public void tick() {
        if (!isAlive() || target == null) return;
        specialAttackCooldown++;
        if (specialAttackCooldown >= 60) {
            // Shoot fire charge at target
            entity.getWorld().spawnParticle(Particle.FLAME, entity.getLocation().add(0,1,0), 5, 0.1, 0.1, 0.1, 0.05);
            entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 0.8f, 1.0f);
            specialAttackCooldown = 0;
        }
    }

    @Override
    public void onDeath(Player killer) {
        Location loc = getLocation();
        if (loc == null) return;
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 40, 0.5, 0.5, 0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.LAVA, loc, 20, 0.3, 0.3, 0.3, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_DEATH, 1f, 0.8f);
    }
}

// =============================================================
// IRON SENTINEL (Absorbable -> IronGolemPower)
// =============================================================

/**
 * A massive robotic guardian. Killing it lets Dog players absorb Iron Golem Power.
 */
class IronSentinel extends CustomEnemy {

    IronSentinel() {
        super("iron_sentinel", "&7Iron Sentinel", 40, 9, 0.20, "iron_golem", 25);
    }

    @Override
    public void setup(LivingEntity e) {
        this.entity = e;
        e.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        e.setCustomNameVisible(true);
        var attr = e.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attr != null) { attr.setBaseValue(maxHealth); e.setHealth(maxHealth); }
        var spd = e.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(speed);
        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, Integer.MAX_VALUE, 1, false, false));
    }

    @Override
    public void tick() {
        if (!isAlive() || target == null) return;
        specialAttackCooldown++;
        if (specialAttackCooldown >= 140) {
            // Shockwave stomp
            Location loc = entity.getLocation();
            entity.getWorld().getNearbyEntities(loc, 4, 2, 4).forEach(e -> {
                if (e instanceof Player p) {
                    Vector kb = p.getLocation().subtract(loc).toVector().setY(0.5).normalize().multiply(1.5);
                    p.setVelocity(kb);
                    p.damage(4.0, entity);
                }
            });
            entity.getWorld().spawnParticle(Particle.BLOCK_CRUMBLE, loc, 30, 1.0, 0.1, 1.0, 0.3,
                    Material.IRON_BLOCK.createBlockData());
            entity.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_STEP, 1f, 0.8f);
            specialAttackCooldown = 0;
        }
    }

    @Override
    public void onDeath(Player killer) {
        Location loc = getLocation();
        if (loc == null) return;
        loc.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, loc, 5, 0.5, 0.5, 0.5, 0);
        loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_DEATH, 1f, 0.9f);
        loc.getWorld().spawnParticle(Particle.CRIT, loc.add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.2);
    }
}

// =============================================================
// FACTORY
// =============================================================

/**
 * Factory that creates CustomEnemy instances by typeId.
 */
public class EnemyTypes {

    private EnemyTypes() {}

    public static CustomEnemy create(String typeId) {
        return switch (typeId.toLowerCase()) {
            case "mutant_insect"     -> new MutantInsect();
            case "radioactive_monkey" -> new RadioactiveMonkey();
            case "infected_wolf"     -> new InfectedWolf();
            case "flame_blaze"       -> new FlameBlaze();
            case "iron_sentinel"     -> new IronSentinel();
            default -> null;
        };
    }
}
