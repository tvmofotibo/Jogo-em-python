package com.dogapocalypse.enemies;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Base representation of a custom enemy in DogApocalypse.
 * Each enemy wraps a Bukkit LivingEntity and provides:
 *  - Custom AI tick method
 *  - On-death callback
 *  - Configurable stats from config.yml
 */
public abstract class CustomEnemy {

    protected final String typeId;
    protected final String displayName;
    protected LivingEntity entity;
    protected double maxHealth;
    protected double damage;
    protected double speed;
    protected String absorbablePower;  // null if not absorbable
    protected int xpReward;

    /** Target acquired by this enemy */
    protected Player target;

    /** Ticks since last special attack */
    protected int specialAttackCooldown = 0;

    public CustomEnemy(String typeId, String displayName,
                       double maxHealth, double damage, double speed,
                       String absorbablePower, int xpReward) {
        this.typeId          = typeId;
        this.displayName     = displayName;
        this.maxHealth       = maxHealth;
        this.damage          = damage;
        this.speed           = speed;
        this.absorbablePower = absorbablePower;
        this.xpReward        = xpReward;
    }

    /**
     * Attach to a newly-spawned entity and configure it.
     */
    public abstract void setup(LivingEntity entity);

    /**
     * Called every 10 ticks by EnemyManager to drive custom AI.
     */
    public abstract void tick();

    /**
     * Called when this enemy dies.
     * @param killer The player who dealt the killing blow (may be null).
     */
    public abstract void onDeath(Player killer);

    // ----------------------------------------------------------------
    // Getters
    // ----------------------------------------------------------------

    public String getTypeId()          { return typeId; }
    public String getDisplayName()     { return displayName; }
    public LivingEntity getEntity()    { return entity; }
    public double getMaxHealth()       { return maxHealth; }
    public double getDamage()          { return damage; }
    public String getAbsorbablePower() { return absorbablePower; }
    public int getXpReward()           { return xpReward; }
    public Player getTarget()          { return target; }
    public void setTarget(Player target) { this.target = target; }

    public boolean isAbsorbable() {
        return absorbablePower != null && !absorbablePower.isEmpty();
    }

    public boolean isAlive() {
        return entity != null && !entity.isDead() && entity.isValid();
    }

    public Location getLocation() {
        return entity != null ? entity.getLocation() : null;
    }
}
