package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class StoryCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public StoryCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.story")) {
            sender.sendMessage(MessageUtil.color("&cSem permissão.")); return true;
        }
        if (args.length == 0) { sender.sendMessage(MessageUtil.color("&7Usage: &e/story <progress|reset> [player]")); return true; }
        Player target = args.length >= 2 ? Bukkit.getPlayer(args[1]) : (sender instanceof Player p ? p : null);
        if (target == null) { sender.sendMessage(MessageUtil.color("&cJogador não encontrado.")); return true; }

        if (args[0].equalsIgnoreCase("progress")) {
            plugin.getDialogueManager().unlockNextFragment(target);
            sender.sendMessage(MessageUtil.color("&aUnlocked fragment for " + target.getName()));
        } else if (args[0].equalsIgnoreCase("reset")) {
            plugin.getPlayerDataManager().get(target).setStoryFragments(0);
            sender.sendMessage(MessageUtil.color("&aReset story for " + target.getName()));
        }
        return true;
    }
}
