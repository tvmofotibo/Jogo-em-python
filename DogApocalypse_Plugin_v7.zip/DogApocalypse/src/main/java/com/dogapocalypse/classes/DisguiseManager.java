package com.dogapocalypse.classes;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.scoreboard.*;

import java.util.*;

/**
 * DisguiseManager — visual de cachorro SEM dependências externas.
 *
 * Como funciona (100% API vanilla do Paper):
 *  1. Equipa o jogador com armadura de couro colorida (cor marrom/laranja = cachorro)
 *  2. Usa scoreboards para exibir o ícone 🐺 no nome do jogador
 *  3. Muda as cores conforme o poder absorvido
 *  4. Remove tudo ao trocar de classe
 *
 * Limitação: o jogador ainda aparece como humano para outros,
 * mas tem visual temático claro. Para disfarce real precisaria
 * de LibsDisguises — isso é um bom substituto sem dependência.
 */
public class DisguiseManager {

    private final DogApocalypsePlugin plugin;

    // Armadura salva antes de equipar o kit do cachorro
    private final Map<UUID, ItemStack[]> armorAnterior = new HashMap<>();
    // Jogadores com visual ativo
    private final Set<UUID> comVisual = new HashSet<>();

    public DisguiseManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        plugin.getLogger().info("[Disguise] Modo visual nativo ativado (sem LibsDisguises).");
    }

    // ── Aplica o visual de cachorro ──────────────────────────────────
    public void aplicarDisguiseDog(Player player) {
        removerDisguise(player); // limpa antes de reaplicar

        // Salva armadura atual
        armorAnterior.put(player.getUniqueId(),
            player.getInventory().getArmorContents().clone());

        // Equipa armadura de couro marrom (cor de cachorro)
        aplicarCorArmadura(player, Color.fromRGB(101, 67, 33)); // marrom

        // Prefixo no nome via scoreboard
        aplicarPrefixoScoreboard(player, "§6🐺 ");

        comVisual.add(player.getUniqueId());
        player.sendMessage(MessageUtil.color(
            "&6🐺 &fVocê está jogando como &6Cão Mutante&f!"));
    }

    // ── Atualiza cor da armadura conforme poder absorvido ────────────
    public void atualizarCorPoder(Player player, String powerId) {
        if (!comVisual.contains(player.getUniqueId())) return;

        Color cor = switch (powerId) {
            case "blaze"      -> Color.fromRGB(255, 120, 0);   // laranja fogo
            case "spider"     -> Color.fromRGB(30,  30,  30);  // preto aranha
            case "guardian"   -> Color.fromRGB(0,   180, 200); // ciano guardião
            case "phantom"    -> Color.fromRGB(100, 0,   180); // roxo fantasma
            case "iron_golem" -> Color.fromRGB(150, 150, 150); // cinza golem
            default           -> Color.fromRGB(101, 67,  33);  // marrom padrão
        };
        aplicarCorArmadura(player, cor);
    }

    // ── Efeito visual ao ativar habilidade (armadura dourada por 3s) ─
    public void ativarModoHabilidade(Player player) {
        if (!comVisual.contains(player.getUniqueId())) return;
        aplicarCorArmadura(player, Color.fromRGB(255, 215, 0)); // dourado
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && comVisual.contains(player.getUniqueId())) {
                // Volta para a cor do poder atual
                var poder = plugin.getDogPowerManager().getActivePower(player);
                if (poder != null) atualizarCorPoder(player, poder.getId());
                else aplicarCorArmadura(player, Color.fromRGB(101, 67, 33));
            }
        }, 60L);
    }

    // ── Remove o visual (ao trocar de classe) ───────────────────────
    public void removerDisguise(Player player) {
        UUID uuid = player.getUniqueId();
        if (!comVisual.contains(uuid)) return;

        // Restaura armadura anterior
        ItemStack[] anterior = armorAnterior.remove(uuid);
        if (anterior != null) {
            player.getInventory().setArmorContents(anterior);
        } else {
            // Limpa armadura se não tinha nada
            player.getInventory().setHelmet(null);
            player.getInventory().setChestplate(null);
            player.getInventory().setLeggings(null);
            player.getInventory().setBoots(null);
        }

        // Remove prefixo do scoreboard
        removerPrefixoScoreboard(player);
        comVisual.remove(uuid);
    }

    // ── Internos ────────────────────────────────────────────────────

    private void aplicarCorArmadura(Player player, Color cor) {
        ItemStack capacete    = criarPeca(Material.LEATHER_HELMET,    cor);
        ItemStack peitoral    = criarPeca(Material.LEATHER_CHESTPLATE, cor);
        ItemStack calca       = criarPeca(Material.LEATHER_LEGGINGS,   cor);
        ItemStack botas       = criarPeca(Material.LEATHER_BOOTS,      cor);

        player.getInventory().setHelmet(capacete);
        player.getInventory().setChestplate(peitoral);
        player.getInventory().setLeggings(calca);
        player.getInventory().setBoots(botas);
    }

    private ItemStack criarPeca(Material mat, Color cor) {
        ItemStack item = new ItemStack(mat);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        if (meta != null) {
            meta.setColor(cor);
            meta.setDisplayName(MessageUtil.color("&6Armadura do Cão"));
            item.setItemMeta(meta);
        }
        return item;
    }

    private void aplicarPrefixoScoreboard(Player player, String prefixo) {
        Scoreboard sb = player.getScoreboard();
        if (sb == null || sb == Bukkit.getScoreboardManager().getMainScoreboard()) {
            sb = Bukkit.getScoreboardManager().getNewScoreboard();
        }

        Team team = sb.getTeam("da_dog");
        if (team == null) team = sb.registerNewTeam("da_dog");

        team.setPrefix(MessageUtil.color(prefixo));
        team.addEntry(player.getName());
        player.setScoreboard(sb);
    }

    private void removerPrefixoScoreboard(Player player) {
        Scoreboard sb = player.getScoreboard();
        if (sb == null) return;
        Team team = sb.getTeam("da_dog");
        if (team != null) team.removeEntry(player.getName());
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    public static boolean isLibsAvailable() { return false; }
}
