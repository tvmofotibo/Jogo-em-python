package com.dogapocalypse.classes;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.core.PlayerDataManager;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import com.dogapocalypse.classes.DisguiseManager;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

/**
 * Manages class assignment, stat application and class-specific item kits.
 */
public class PlayerClassManager {

    private final DogApocalypsePlugin plugin;

    private final DisguiseManager disguiseManager;

    public PlayerClassManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        this.disguiseManager = new DisguiseManager(plugin);
    }

    public DisguiseManager getDisguiseManager() { return disguiseManager; }

    // ----------------------------------------------------------------
    // Class Selection
    // ----------------------------------------------------------------

    /**
     * Assigns a class to a player and applies corresponding stats/kit.
     *
     * @param player     The player receiving the class.
     * @param playerClass The class to assign.
     */
    public void setClass(Player player, PlayerClass playerClass) {
        PlayerDataManager.PlayerData data = plugin.getPlayerDataManager().get(player);
        PlayerClass previousClass = data.getPlayerClass();

        // Remove effects from old class
        removeClassEffects(player, previousClass);

        // Assign new class
        data.setPlayerClass(playerClass);
        plugin.getPlayerDataManager().save(player.getUniqueId());

        // Apply new class stats
        applyClassStats(player, playerClass);

        // Give class kit
        giveClassKit(player, playerClass);

        // Visual feedback
        EffectUtil.spawnParticleCircle(player.getLocation(), Particle.TOTEM, 30, 1.5);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);

        // Disfarce visual
        if (playerClass == PlayerClass.DOG) {
            disguiseManager.aplicarDisguiseDog(player);
        } else {
            disguiseManager.removerDisguise(player);
        }

        // Notify player
        player.sendMessage(MessageUtil.color("&8[&6Classe&8] &fVocê agora é " + playerClass.getDisplayName() + "&f!"));
        player.sendMessage(MessageUtil.color("&7" + playerClass.getDescription()));
    }

    /**
     * Returns the current class of a player.
     */
    public PlayerClass getClass(Player player) {
        return plugin.getPlayerDataManager().get(player).getPlayerClass();
    }

    public PlayerClass getClass(UUID uuid) {
        return plugin.getPlayerDataManager().get(uuid).getPlayerClass();
    }

    public boolean isDog(Player player) {
        return getClass(player) == PlayerClass.DOG;
    }

    public boolean isFighter(Player player) {
        return getClass(player) == PlayerClass.FIGHTER;
    }

    public boolean isArcher(Player player) {
        return getClass(player) == PlayerClass.ARCHER;
    }

    // ----------------------------------------------------------------
    // Stats Application
    // ----------------------------------------------------------------

    /**
     * Applies base health and speed for a given class.
     */
    public void applyClassStats(Player player, PlayerClass playerClass) {
        double health;
        double speed;

        switch (playerClass) {
            case DOG -> {
                health = plugin.getConfig().getDouble("classes.dog.base_health", 18.0);
                speed  = plugin.getConfig().getDouble("classes.dog.base_speed", 0.35);
            }
            case FIGHTER -> {
                health = plugin.getConfig().getDouble("classes.fighter.base_health", 24.0);
                speed  = plugin.getConfig().getDouble("classes.fighter.base_speed", 0.28);
            }
            case ARCHER -> {
                health = plugin.getConfig().getDouble("classes.archer.base_health", 16.0);
                speed  = plugin.getConfig().getDouble("classes.archer.base_speed", 0.30);
            }
            default -> {
                health = 20.0;
                speed  = 0.25;
            }
        }

        // Apply max health
        var maxHealthAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealthAttr != null) {
            maxHealthAttr.setBaseValue(health);
            player.setHealth(Math.min(player.getHealth(), health));
        }

        // Apply speed
        var speedAttr = player.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.setBaseValue(speed);
        }

        // Dog specific permanent effects
        if (playerClass == PlayerClass.DOG) {
            // Slightly reduced fall damage handled in listener; we can use slow falling as partial mitigation
            player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 1, false, false, false));
        }

        // Archer gets permanent night vision (mutated eyes)
        if (playerClass == PlayerClass.ARCHER) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, false));
        }

        // Fighter gets permanent slow but has extra health (already set above)
        // nothing extra needed
    }

    /**
     * Removes class-specific effects when switching away from a class.
     */
    private void removeClassEffects(Player player, PlayerClass oldClass) {
        if (oldClass == null) return;

        switch (oldClass) {
            case DOG -> {
                player.removePotionEffect(PotionEffectType.JUMP);
                plugin.getDogPowerManager().clearPower(player);
                disguiseManager.removerDisguise(player);
            }
            case ARCHER -> player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            default -> { /* Fighter has no persistent effects */ }
        }

        // Reset speed and health to vanilla
        var maxHealthAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealthAttr != null) maxHealthAttr.setBaseValue(20.0);

        var speedAttr = player.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) speedAttr.setBaseValue(0.2);
    }

    /**
     * Gives the player starter items appropriate for their class.
     */
    private void giveClassKit(Player player, PlayerClass playerClass) {
        // Clear hotbar slots 0–3 for class items
        for (int i = 0; i < 4; i++) {
            player.getInventory().setItem(i, null);
        }

        switch (playerClass) {
            case DOG -> KitFactory.giveDogKit(player);
            case FIGHTER -> KitFactory.giveFighterKit(player);
            case ARCHER -> KitFactory.giveArcherKit(player);
        }
    }
}
