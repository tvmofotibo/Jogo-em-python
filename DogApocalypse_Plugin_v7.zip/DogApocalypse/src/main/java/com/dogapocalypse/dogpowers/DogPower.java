package com.dogapocalypse.dogpowers;

import org.bukkit.entity.Player;

/**
 * Interface that all dog-absorbed powers must implement.
 *
 * Each power has three lifecycle methods:
 *  - activate()    : called when the power is absorbed
 *  - useAbility()  : called when the player triggers the power
 *  - deactivate()  : called when the power expires or is replaced
 */
public interface DogPower {

    /**
     * Unique identifier for this power (matches config key, e.g. "blaze").
     */
    String getId();

    /**
     * Human-readable display name (with color codes).
     */
    String getDisplayName();

    /**
     * Short description shown in the HUD.
     */
    String getDescription();

    /**
     * Called when the player first absorbs this power.
     * Apply visual effects, start periodic tasks, etc.
     *
     * @param player The dog-class player who absorbed the power.
     */
    void activate(Player player);

    /**
     * Called when the player uses the power ability (right-click totem / /dogpower activate).
     *
     * @param player The dog-class player.
     * @return true if the ability was used successfully (triggers cooldown).
     */
    boolean useAbility(Player player);

    /**
     * Called when the power expires, is replaced, or the player switches class.
     * Remove any ongoing effects.
     *
     * @param player The dog-class player.
     */
    void deactivate(Player player);

    /**
     * Cooldown in ticks between ability uses.
     */
    int getCooldownTicks();

    /**
     * How long this power lasts before expiring (in ticks).
     */
    int getDurationTicks();
}
