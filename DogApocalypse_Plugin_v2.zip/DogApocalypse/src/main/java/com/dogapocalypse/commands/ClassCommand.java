package com.dogapocalypse.commands;

import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class ClassCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public ClassCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only."); return true; }
        if (args.length < 2 || !args[0].equalsIgnoreCase("choose")) {
            player.sendMessage(MessageUtil.color("&7Usage: &e/class choose <dog|fighter|archer>"));
            PlayerClass cur = plugin.getPlayerClassManager().getClass(player);
            player.sendMessage(MessageUtil.color("&7Current: " + cur.getDisplayName()));
            return true;
        }
        PlayerClass chosen = PlayerClass.fromString(args[1]);
        if (chosen == null) { player.sendMessage(MessageUtil.color("&cUnknown class.")); return true; }
        plugin.getPlayerClassManager().setClass(player, chosen);
        return true;
    }
}
