package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class BossCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public BossCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.boss")) {
            sender.sendMessage(MessageUtil.color("&cSem permissão.")); return true;
        }
        if (args.length < 2) { sender.sendMessage(MessageUtil.color("&7Usage: &e/boss <spawn|kill> <bossType>")); return true; }

        if (args[0].equals("spawn")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
            var boss = plugin.getBossManager().spawnBoss(args[1], player.getLocation());
            sender.sendMessage(boss == null
                ? MessageUtil.color("&cUnknown boss: " + args[1])
                : MessageUtil.color("&aSpawned: " + args[1]));
        } else if (args[0].equals("kill")) {
            var boss = plugin.getBossManager().getActiveBoss(args[1]);
            if (boss == null) { sender.sendMessage(MessageUtil.color("&cNo active boss: " + args[1])); return true; }
            if (boss.isAlive()) boss.getEntity().setHealth(0);
            sender.sendMessage(MessageUtil.color("&aKilled: " + args[1]));
        }
        return true;
    }
}
