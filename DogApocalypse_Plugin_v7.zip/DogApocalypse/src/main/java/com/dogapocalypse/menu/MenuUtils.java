package com.dogapocalypse.menu;

import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/** Utilitários para criar itens de menu com visual bonito. */
public class MenuUtils {

    /** Cria um item de menu com nome e lore coloridos. */
    public static ItemStack item(Material mat, String nome, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        meta.setDisplayName(MessageUtil.color(nome));
        if (lore.length > 0) {
            meta.setLore(Arrays.stream(lore)
                .map(MessageUtil::color)
                .collect(Collectors.toList()));
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS,
                ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_POTION_EFFECTS);
        it.setItemMeta(meta);
        return it;
    }

    /** Item com brilho encantado (destaque visual). */
    public static ItemStack itemBrilhante(Material mat, String nome, String... lore) {
        ItemStack it = item(mat, nome, lore);
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        meta.addEnchant(Enchantment.LUCK, 1, true);
        it.setItemMeta(meta);
        return it;
    }

    /** Vidro colorido para preencher bordas do menu. */
    public static ItemStack borda(Material vidro) {
        ItemStack it = new ItemStack(vidro);
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        meta.setDisplayName(" ");
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    public static final ItemStack SLOT_VAZIO = borda(Material.BLACK_STAINED_GLASS_PANE);
}
