package com.dogapocalypse.menu;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Menu principal — /menu
 * 
 *  Slot layout (54 slots = 6 linhas):
 *  ┌──────────────────────────────────┐
 *  │  B  B  B  B  B  B  B  B  B      │  linha 0 — borda
 *  │  B  🐺  B  ⚔  B  🏹  B  B  B   │  linha 1 — classes
 *  │  B  B  B  B  B  B  B  B  B      │  linha 2 — borda
 *  │  B  🗺  B  ⚡  B  👥  B  📖  B  │  linha 3 — ações
 *  │  B  B  B  B  B  B  B  B  B      │  linha 4 — borda
 *  │  B  B  B  B  ❌  B  B  B  B    │  linha 5 — fechar
 *  └──────────────────────────────────┘
 */
public class MenuPrincipal {

    public static final String TITULO = "§8§l⚙ Menu Principal";

    public static void abrir(Player player, DogApocalypsePlugin plugin) {
        Inventory inv = Bukkit.createInventory(null, 54, TITULO);

        var data  = plugin.getPlayerDataManager().get(player);
        var classe = plugin.getPlayerClassManager().getClass(player);
        var poder  = plugin.getDogPowerManager().getActivePower(player);

        // ── Bordas ──
        Material borda = Material.GRAY_STAINED_GLASS_PANE;
        Material borda2 = Material.BLACK_STAINED_GLASS_PANE;
        for (int i = 0; i < 9; i++) {
            inv.setItem(i,      MenuUtils.borda(borda));
            inv.setItem(18 + i, MenuUtils.borda(borda));
            inv.setItem(36 + i, MenuUtils.borda(borda));
            inv.setItem(45 + i, MenuUtils.borda(borda));
        }
        for (int i = 9; i < 54; i += 9) {
            inv.setItem(i,     MenuUtils.borda(borda2));
            inv.setItem(i + 8, MenuUtils.borda(borda2));
        }

        // ── LINHA 1 — Escolha de Classe ──
        // Cão
        inv.setItem(10, MenuUtils.itemBrilhante(Material.BONE,
            "&6&l🐺 Cão Mutante",
            "&7Rápido e adaptável.",
            "&7Absorve poderes ao matar inimigos.",
            "",
            "&eClique para escolher esta classe!"
        ));

        // Lutador
        inv.setItem(12, MenuUtils.item(Material.IRON_SWORD,
            "&c&l⚔ Lutador",
            "&7Guerreiro corpo-a-corpo poderoso.",
            "&7Mais saúde e dano de melee.",
            "",
            "&eClique para escolher esta classe!"
        ));

        // Arqueiro
        inv.setItem(14, MenuUtils.item(Material.BOW,
            "&a&l🏹 Arqueiro",
            "&7Atacante preciso de longa distância.",
            "&7Visão noturna e dano crítico à distância.",
            "",
            "&eClique para escolher esta classe!"
        ));

        // Classe atual
        inv.setItem(16, MenuUtils.itemBrilhante(Material.NETHER_STAR,
            "&f&lSua Classe Atual",
            "&7" + classe.getDisplayName(),
            "&7Pontos de habilidade: &e" + data.getSkillPoints(),
            "&7Fragmentos de história: &d" + data.getStoryFragments() + "/12"
        ));

        // ── LINHA 3 — Ações ──
        // Fases / Níveis
        inv.setItem(28, MenuUtils.item(Material.MAP,
            "&b&l🗺 Jogar — Escolher Fase",
            "&7Inicie uma fase ou continue de onde parou.",
            "&7Fase atual: &e" + data.getCurrentLevel(),
            "",
            "&eClique para abrir o menu de fases!"
        ));

        // Poderes (só para Cão)
        if (poder != null) {
            inv.setItem(30, MenuUtils.itemBrilhante(Material.TOTEM_OF_UNDYING,
                "&5&l⚡ Poder Absorvido",
                "&f" + poder.getDisplayName(),
                "&7" + poder.getDescription(),
                "",
                "&eClique para ativar o poder!"
            ));
        } else {
            inv.setItem(30, MenuUtils.item(Material.GRAY_DYE,
                "&8⚡ Sem Poder Absorvido",
                "&7Mate inimigos especiais para absorver poderes.",
                "&8(Apenas classe Cão)"
            ));
        }

        // Grupo / Coop
        var membros = plugin.getCoopManager().getPartyMembers(player);
        inv.setItem(32, MenuUtils.item(Material.PLAYER_HEAD,
            "&e&l👥 Grupo",
            "&7Membros: &f" + membros.size() + "/4",
            "",
            "&eClique para gerenciar seu grupo!"
        ));

        // Habilidades (árvore de skills)
        inv.setItem(34, MenuUtils.item(Material.EXPERIENCE_BOTTLE,
            "&a&l✦ Árvore de Habilidades",
            "&7Pontos disponíveis: &e" + data.getSkillPoints(),
            "&8(Apenas classe Cão)",
            "",
            "&eClique para ver e melhorar habilidades!"
        ));

        // ── Fechar ──
        inv.setItem(49, MenuUtils.item(Material.BARRIER,
            "&c&lFechar",
            "&7Fecha este menu."
        ));

        player.openInventory(inv);
    }
}
