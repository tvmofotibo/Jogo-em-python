package com.dogapocalypse.levels;

import org.bukkit.Location;

public class LevelData {
    public final String levelId;
    public final String displayName;
    public final int levelIndex;
    public final int enemyWaves;
    public final String bossId;
    public final int checkpointCount;
    public Location spawnLocation;

    public LevelData(String levelId, String displayName, int levelIndex,
              int enemyWaves, String bossId, int checkpointCount) {
        this.levelId         = levelId;
        this.displayName     = displayName;
        this.levelIndex      = levelIndex;
        this.enemyWaves      = enemyWaves;
        this.bossId          = bossId;
        this.checkpointCount = checkpointCount;
    }

    public Location getSpawnLocation() { return spawnLocation; }
}
