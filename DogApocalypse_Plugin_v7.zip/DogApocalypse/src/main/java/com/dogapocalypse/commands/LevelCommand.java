package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class LevelCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public LevelCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.level")) {
            sender.sendMessage(MessageUtil.color("&cSem permissão.")); return true;
        }
        if (args.length < 2) { sender.sendMessage(MessageUtil.color("&7Usage: &e/level <start|tp> <levelId>")); return true; }

        String action  = args[0].toLowerCase();
        String levelId = args[1].toLowerCase();

        if (action.equals("start")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
            var party = plugin.getCoopManager().getPartyMembers(player);
            if (!plugin.getLevelManager().startLevel(levelId, party))
                sender.sendMessage(MessageUtil.color("&cFailed to start: " + levelId));
        } else if (action.equals("tp")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
            var level = plugin.getLevelManager().getLevel(levelId);
            if (level == null) { player.sendMessage(MessageUtil.color("&cNível desconhecido.")); return true; }
            Location loc = level.getSpawnLocation();
            if (loc == null) { player.sendMessage(MessageUtil.color("&cWorld not ready.")); return true; }
            player.teleport(loc);
            player.sendMessage(MessageUtil.color("&aTeleportado para &e" + levelId));
        } else {
            sender.sendMessage(MessageUtil.color("&cUnknown action."));
        }
        return true;
    }
}
