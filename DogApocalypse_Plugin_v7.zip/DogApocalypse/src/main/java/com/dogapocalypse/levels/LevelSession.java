package com.dogapocalypse.levels;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class LevelSession {
    public final String levelId;
    final List<UUID> participants;
    public int currentWave = 0;
    public boolean bossSpawned = false;
    public boolean completed = false;
    public long startTime;

    public LevelSession(String levelId, List<UUID> participants) {
        this.levelId      = levelId;
        this.participants = new ArrayList<>(participants);
        this.startTime    = System.currentTimeMillis();
    }

    public boolean isBossSpawned() { return bossSpawned; }
    public boolean isCompleted()   { return completed; }
    public List<UUID> getParticipants() { return Collections.unmodifiableList(participants); }
}
