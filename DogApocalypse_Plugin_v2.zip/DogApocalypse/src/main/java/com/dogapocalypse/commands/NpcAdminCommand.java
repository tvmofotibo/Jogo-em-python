package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/**
 * /npc command — admin NPC management.
 * Usage: /npc respawn | /npc count
 */
public class NpcAdminCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    public NpcAdminCommand(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin")) {
            sender.sendMessage(MessageUtil.color("&cNo permission."));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(MessageUtil.color("&7Usage: &e/npc <respawn|count>"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "respawn" -> {
                if (plugin.getWorldGenerator().getLevelWorld() == null) {
                    sender.sendMessage(MessageUtil.color("&cLevel world not ready yet."));
                    return true;
                }
                plugin.getNpcManager().cleanupAll();
                plugin.getNpcManager().spawnAllNpcs(plugin.getWorldGenerator().getLevelWorld());
                sender.sendMessage(MessageUtil.color("&aNPCs respawned: "
                        + plugin.getNpcManager().getNpcCount()));
            }
            case "count" -> sender.sendMessage(MessageUtil.color(
                    "&7Active NPCs: &e" + plugin.getNpcManager().getNpcCount()));
            default -> sender.sendMessage(MessageUtil.color("&cUnknown sub-command."));
        }
        return true;
    }
}
