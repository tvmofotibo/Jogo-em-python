"""
FORGOTTEN PAWS  —  Dark Cartoon Platformer  (Cuphead-inspired)
Pygame + Pygbag (WebAssembly)

BUG FIX (buttons not working):
  The root cause was draw-order vs event-order:
    - tap_zones is populated during draw()
    - events were processed BEFORE the first draw() ever ran
    - so on frame 0 (and after any clear), tap_zones was empty
  FIX: loop order is now  DRAW → flip → process_events → update
       This guarantees tap_zones always has valid zones when clicks arrive.

ART: Cuphead-inspired — high-contrast ink outlines, cream/sepia backgrounds,
     bold cartoon silhouettes, ink-splat particles, retro serif title font feel,
     film-grain scanlines overlay, bouncy squash-stretch animation.
"""

import asyncio, math, random, sys
import pygame

pygame.init()
W, H = 960, 540
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("FORGOTTEN PAWS")
clock  = pygame.time.Clock()
FPS    = 60
GRAVITY = 0.6

# ── Cuphead palette ────────────────────────────────────────────────────────────
CREAM   = (255, 248, 220)
SEPIA   = (180, 140,  80)
INK     = ( 20,  12,   8)
RED     = (210,  35,  20)
GREEN   = ( 40, 180,  50)
BLUE    = ( 30,  90, 210)
YELLOW  = (240, 200,  20)
PURPLE  = (140,  40, 200)
ORANGE  = (230, 110,  20)
CYAN    = ( 20, 190, 200)
PINK    = (230,  60, 140)
GOLD    = (230, 175,  20)
WHITE   = (255, 255, 255)
BLACK   = (  0,   0,   0)
GREY    = (120, 110, 100)
DARK_RED= (120,  10,  10)
BROWN   = (100,  60,  20)

# ── Fonts ──────────────────────────────────────────────────────────────────────
def _f(sz, bold=False):
    try:    return pygame.font.SysFont("serif", sz, bold=bold)
    except: return pygame.font.Font(None, sz)

F_TITLE = _f(64, True)
F_BIG   = _f(48, True)
F_MED   = _f(26, True)
F_SM    = _f(16, True)
F_TINY  = _f(12)

def lerp(a, b, t): return a + (b-a)*t
def clamp(v, lo, hi): return max(lo, min(hi, v))

# ── Film grain / scanline overlay (created once) ───────────────────────────────
_GRAIN = pygame.Surface((W, H), pygame.SRCALPHA)
_rng_g = random.Random(77)
for _y in range(0, H, 2):          # scanlines
    pygame.draw.line(_GRAIN, (0,0,0,18), (0,_y), (W,_y))
for _ in range(4000):               # grain dots
    _gx = _rng_g.randint(0, W-1); _gy = _rng_g.randint(0, H-1)
    _ga = _rng_g.randint(0, 28)
    _GRAIN.set_at((_gx, _gy), (0,0,0,_ga))

# ── Ink-outline helper ─────────────────────────────────────────────────────────
def ink_rect(surf, col, r, outline=2):
    shadow = r.move(3, 3)
    pygame.draw.rect(surf, INK, shadow)
    pygame.draw.rect(surf, col, r)
    pygame.draw.rect(surf, INK, r, outline)

def ink_circle(surf, col, cx, cy, r, outline=2):
    pygame.draw.circle(surf, INK, (cx+2, cy+2), r)
    pygame.draw.circle(surf, col, (cx, cy), r)
    pygame.draw.circle(surf, INK, (cx, cy), r, outline)

def ink_poly(surf, col, pts, outline=2):
    shifted = [(x+2, y+2) for x,y in pts]
    pygame.draw.polygon(surf, INK, shifted)
    pygame.draw.polygon(surf, col, pts)
    pygame.draw.polygon(surf, INK, pts, outline)

# =============================================================================
# INK-SPLAT PARTICLE SYSTEM  (Cuphead style)
# =============================================================================
class Particle:
    __slots__ = ("x","y","vx","vy","r","g","b","life","ml","sz","rot","rspd")
    def __init__(self, x, y, vx, vy, col, life, sz=4):
        self.x,self.y = float(x),float(y)
        self.vx,self.vy = float(vx),float(vy)
        self.r,self.g,self.b = col
        self.life = life; self.ml = life; self.sz = sz
        self.rot = random.uniform(0, math.tau)
        self.rspd = random.uniform(-0.3, 0.3)
    def update(self):
        self.x += self.vx; self.y += self.vy
        self.vy += 0.25; self.vx *= 0.88
        self.rot += self.rspd; self.life -= 1
    def draw(self, surf, cx):
        if self.life <= 0: return
        a = self.life / self.ml
        sz = max(2, int(self.sz * a))
        sx, sy = int(self.x - cx), int(self.y)
        if -sz < sx < W+sz and -sz < sy < H+sz:
            col = (int(self.r*a), int(self.g*a), int(self.b*a))
            # ink-splat: slightly irregular blob
            pygame.draw.circle(surf, INK, (sx+1,sy+1), sz)
            pygame.draw.circle(surf, col, (sx,sy), sz)
            if sz > 3:
                pygame.draw.circle(surf, INK, (sx,sy), sz, 1)

class PS:
    def __init__(self): self.p = []
    def emit(self, x, y, vx, vy, col, life, sz=4):
        self.p.append(Particle(x, y, vx, vy, col, life, sz))
    def burst(self, x, y, col, n=12, spd=5, sz=4):
        for _ in range(n):
            a = random.uniform(0, math.tau); s = random.uniform(spd*.3, spd)
            self.emit(x, y, math.cos(a)*s, math.sin(a)*s, col,
                      random.randint(20,45), sz)
    def ink_splat(self, x, y, col=INK):
        self.burst(x, y, col, 16, 6, 5)
        self.burst(x, y, CREAM, 8, 3, 2)
    def spark(self, x, y):  self.burst(x, y, YELLOW, 10, 7, 3)
    def magic(self, x, y, col=PURPLE): self.burst(x, y, col, 14, 4, 3)
    def absorb(self, x, y):
        for _ in range(20):
            a = random.uniform(0, math.tau); r = random.uniform(20, 60)
            ox, oy = x+math.cos(a)*r, y+math.sin(a)*r
            self.emit(ox, oy, -math.cos(a)*3, -math.sin(a)*3, GREEN, 40, 4)
    def update(self):
        live = []
        for p in self.p:
            p.update()
            if p.life > 0: live.append(p)
        self.p = live
    def draw(self, surf, cx):
        for p in self.p: p.draw(surf, cx)

ps = PS()

# floating damage text
class FT:
    def __init__(self, x, y, txt, col, life=65):
        self.x,self.y = float(x),float(y)
        self.txt,self.col = txt,col
        self.life = self.ml = life
        self.scale = 1.4  # pops big then shrinks (Cuphead juice)
    def update(self):
        self.y -= 1.1; self.life -= 1
        self.scale = lerp(self.scale, 1.0, 0.12)
    def draw(self, surf, cx):
        a = clamp(self.life/self.ml, 0, 1)
        col = tuple(int(c*a) for c in self.col)
        sz = max(10, int(20 * self.scale * a))
        try:
            fnt = pygame.font.SysFont("serif", sz, bold=True)
        except:
            fnt = pygame.font.Font(None, sz)
        s = fnt.render(self.txt, True, INK)
        s2 = fnt.render(self.txt, True, col)
        bx, by = int(self.x-cx-s.get_width()//2), int(self.y)
        surf.blit(s, (bx+2, by+2))
        surf.blit(s2, (bx, by))

floats = []
def add_float(x, y, txt, col=YELLOW): floats.append(FT(x,y,txt,col))

# =============================================================================
# MOBILE / TOUCH CONTROLS
# =============================================================================
class TBtn:
    def __init__(self, lbl, cx, cy, r, col, act):
        self.lbl,self.cx,self.cy,self.r,self.col,self.act = lbl,cx,cy,r,col,act
        self.pressed = False
    def hit(self, x, y): return math.hypot(x-self.cx, y-self.cy) <= self.r * 1.5
    def draw(self, surf):
        c = tuple(min(255,v+60) for v in self.col) if self.pressed else self.col
        # ink shadow
        pygame.draw.circle(surf, INK, (self.cx+3, self.cy+3), self.r)
        pygame.draw.circle(surf, c, (self.cx, self.cy), self.r)
        pygame.draw.circle(surf, INK, (self.cx, self.cy), self.r, 3)
        if self.pressed:
            pygame.draw.circle(surf, WHITE, (self.cx, self.cy), self.r//2, 2)
        s = F_TINY.render(self.lbl, True, INK if self.pressed else WHITE)
        surf.blit(s, (self.cx-s.get_width()//2, self.cy-s.get_height()//2))

ACTS = ("left","right","up","down","attack","ranged","special")

class Mobile:
    def __init__(self):
        self.state = {a:False for a in ACTS}
        R = 34; lx,ly = 90,H-95; rx,ry = W-95,H-95
        self.btns = [
            TBtn("◀", lx-R-8, ly,     R, (60,60,80),   "left"),
            TBtn("▶", lx+R+8, ly,     R, (60,60,80),   "right"),
            TBtn("▼", lx,     ly+R+8, R, (60,60,60),   "down"),
            TBtn("▲", lx,     ly-R-8, R, (60,80,60),   "up"),
            TBtn("ATK", rx,       ry,     R, (160,30,20), "attack"),
            TBtn("TIR", rx-R*2-8, ry,     R, (20,50,160), "ranged"),
            TBtn("ESP", rx-R-4,   ry-R*2-8,R,(110,20,140),"special"),
            TBtn("⬆",  rx-R*2-8, ry-R*2-8,R,(20,120,40), "up"),
        ]
    def handle(self, ev):
        FDOWN = getattr(pygame, "FINGERDOWN", -1)
        FUP   = getattr(pygame, "FINGERUP",   -2)
        if ev.type == pygame.MOUSEBUTTONDOWN:
            x,y = ev.pos
            for b in self.btns:
                if b.hit(x,y): b.pressed=True; self.state[b.act]=True
        elif ev.type == FDOWN:
            x,y = int(ev.x*W), int(ev.y*H)
            for b in self.btns:
                if b.hit(x,y): b.pressed=True; self.state[b.act]=True
        elif ev.type in (pygame.MOUSEBUTTONUP, FUP):
            for b in self.btns: b.pressed = False
            self.state = {a:False for a in ACTS}
        elif ev.type == pygame.MOUSEMOTION and ev.buttons[0]:
            x,y = ev.pos
            for b in self.btns:
                b.pressed = b.hit(x,y); self.state[b.act] = b.pressed
    def draw(self, surf):
        for b in self.btns: b.draw(surf)

mobile = Mobile()

class MK:   # merged keyboard + mobile for P1
    MAP = {pygame.K_a:"left",pygame.K_d:"right",pygame.K_w:"up",
           pygame.K_s:"down",pygame.K_z:"attack",pygame.K_x:"ranged",pygame.K_c:"special"}
    def __init__(self): self._kb = None
    def refresh(self):  self._kb = pygame.key.get_pressed()
    def __getitem__(self, k):
        kb  = self._kb[k] if self._kb else False
        mob = mobile.state.get(self.MAP.get(k,""), False)
        return kb or mob

mk = MK()

# =============================================================================
# TAP ZONES  — populated during draw, consumed during next frame's events
# =============================================================================
tap_zones = {}

def tap_btn(surf, name, lbl, cx, cy, bw, bh, col, font=None, hover=False):
    """Draw an ink-outlined cartoon button and register its tap zone."""
    if font is None: font = F_MED
    r = pygame.Rect(cx-bw//2, cy-bh//2, bw, bh)
    tap_zones[name] = r
    # shadow
    sh = r.inflate(0,0).move(5,5)
    pygame.draw.rect(surf, INK, sh)
    # face
    face_col = tuple(min(255,c+40) for c in col) if hover else col
    pygame.draw.rect(surf, face_col, r)
    pygame.draw.rect(surf, INK, r, 3)
    # inner highlight line
    pygame.draw.line(surf, tuple(min(255,c+80) for c in col),
                     (r.left+4, r.top+3), (r.right-4, r.top+3), 2)
    s = font.render(lbl, True, INK)
    surf.blit(s, (cx-s.get_width()//2, cy-s.get_height()//2))

# =============================================================================
# POWERS / CHARS
# =============================================================================
POWERS = {
    "none":     {"name":"—",       "col":GREEN},
    "fire":     {"name":"FOGO",    "col":(255,80,10)},
    "climb":    {"name":"ESCALAR", "col":BROWN},
    "electric": {"name":"ELÉTR",   "col":YELLOW},
}
EPWR = {"rat":"none","insect":"electric","monkey":"climb",
        "robot":"electric","dragon":"fire","skeleton":"none"}

CDEFS = [
    (0, "REX",  GREEN,  4.5, 15.0,  90, 120, 1),
    (1, "VALE", ORANGE, 3.8, 14.0,  85, 100, 2),
    (2, "ZAP",  CYAN,   3.2, 13.0, 120,  60, 3),
    (3, "MAGO", PURPLE, 3.0, 13.5,  80, 150, 4),
    (4, "KIRA", PINK,   4.2, 13.5, 100,  80, 0),
]
CTRL = [
    [pygame.K_a,   pygame.K_d,    pygame.K_w,   pygame.K_s,    pygame.K_z, pygame.K_x, pygame.K_c],
    [pygame.K_LEFT,pygame.K_RIGHT, pygame.K_UP,  pygame.K_DOWN, pygame.K_u, pygame.K_i, pygame.K_o],
    [pygame.K_j,   pygame.K_l,    pygame.K_i,   pygame.K_k,    pygame.K_n, pygame.K_m, pygame.K_COMMA],
    [pygame.K_KP4, pygame.K_KP6,  pygame.K_KP8, pygame.K_KP5,  pygame.K_KP7,pygame.K_KP9,pygame.K_KP1],
    [pygame.K_F1,  pygame.K_F3,   pygame.K_F2,  pygame.K_F4,   pygame.K_F5,pygame.K_F6,pygame.K_F7],
]

# =============================================================================
# PLATFORM  (Cuphead: thick ink outline, brick texture)
# =============================================================================
class Platform:
    def __init__(self, x, y, w, h, col=(80,55,30), soil=(55,38,18)):
        self.x,self.y,self.w,self.h = x,y,w,h
        self.col,self.soil = col,soil
    def rect(self): return pygame.Rect(self.x,self.y,self.w,self.h)
    def draw(self, surf, cx):
        sx = self.x - cx
        if sx+self.w < -8 or sx > W+8: return
        r = pygame.Rect(int(sx), self.y, self.w, self.h)
        # soil
        pygame.draw.rect(surf, self.soil, r)
        # top grass strip
        top = pygame.Rect(int(sx), self.y, self.w, 10)
        pygame.draw.rect(surf, (60,130,40), top)
        pygame.draw.rect(surf, INK, top, 2)
        # outline
        pygame.draw.rect(surf, INK, r, 3)
        # brick lines
        for i in range(0, self.w, 40):
            lx = int(sx)+i
            pygame.draw.line(surf, INK, (lx, self.y+12), (lx, self.y+self.h), 1)
        for j in range(self.y+18, self.y+self.h, 14):
            pygame.draw.line(surf, INK, (int(sx), j), (int(sx)+self.w, j), 1)

class Spike:
    def __init__(self, x, y, n=5): self.x,self.y,self.n=x,y,n; self.w=n*14
    def draw(self, surf, cx):
        sx = int(self.x-cx)
        if sx+self.w < -8 or sx > W+8: return
        for i in range(self.n):
            bx = sx+i*14
            pts = [(bx,self.y+22),(bx+7,self.y),(bx+14,self.y+22)]
            ink_poly(surf, RED, pts, 2)
    def hurt(self, players):
        for p in players:
            if p.dead or p.inv > 0: continue
            if (p.x+p.w > self.x and p.x < self.x+self.w and
                    p.y+p.h > self.y and p.y+p.h < self.y+24):
                p.take_damage(40)

# =============================================================================
# COLLECTIBLE  (cartoon style — bouncing stars and hearts)
# =============================================================================
class Collectible:
    def __init__(self, x, y, ct):
        self.x,self.y = float(x),float(y); self.ct=ct; self.done=False
        self.bob = random.uniform(0, math.tau)
    def update(self, players, gs):
        if self.done: return
        for p in players:
            if p.dead: continue
            if abs(p.x-self.x)<30 and abs(p.y-self.y)<30:
                self.done=True; self._apply(p,gs)
    def _apply(self, p, gs):
        if self.ct=="health":
            p.hp = min(p.max_hp, p.hp+32)
            add_float(self.x,self.y-12,"+32 HP",GREEN)
            ps.burst(self.x,self.y,GREEN,10,4)
        elif self.ct=="memory":
            gs.score+=500; gs.mem_count+=1
            add_float(self.x,self.y-12,"✦ MEMÓRIA",PURPLE)
            ps.magic(self.x,self.y)
            if gs.mem_count==2: gs.trigger_mem=True
        elif self.ct=="powerup":
            p.mp=p.max_mp
            add_float(self.x,self.y-12,"PODER MAX!",YELLOW)
            ps.burst(self.x,self.y,YELLOW,12,5)
    def draw(self, surf, cx):
        if self.done: return
        sx = int(self.x-cx)
        bob = int(math.sin(pygame.time.get_ticks()*0.005+self.bob)*7)
        sy = int(self.y)+bob
        if sx<-30 or sx>W+30: return
        t = pygame.time.get_ticks()*0.003
        if self.ct=="health":
            # pulsing heart
            sc = 1.0+0.1*math.sin(t*4)
            r = int(13*sc)
            ink_circle(surf, RED, sx, sy-4, r, 2)
            ink_circle(surf, RED, sx+int(r*0.9), sy-4, r, 2)
            pts = [(sx-r,sy-4),(sx+r+int(r*0.9),sy-4),(sx+int(r*0.45),sy+r+4)]
            ink_poly(surf, RED, pts, 1)
        elif self.ct=="memory":
            for i in range(5):
                a = math.tau/5*i - math.pi/2 + t
                ink_circle(surf, PURPLE,
                           sx+int(math.cos(a)*12), sy+int(math.sin(a)*12), 5, 1)
            ink_circle(surf, (200,160,255), sx, sy, 6, 2)
        elif self.ct=="powerup":
            pts = []
            for i in range(10):
                a = math.tau/10*i - math.pi/2
                rr = 14 if i%2==0 else 7
                pts.append((sx+int(math.cos(a)*rr), sy+int(math.sin(a)*rr)))
            ink_poly(surf, YELLOW, pts, 2)

# =============================================================================
# PRISON  (thick bars, Kira silhouette inside)
# =============================================================================
class Prison:
    def __init__(self, x, y):
        self.x,self.y = x,y; self.w,self.h = 90,130
        self.freed=False; self.hp=3; self.shake=0; self._lt=-9999
    def try_break(self, players, gs):
        if self.freed: return True
        if self.shake>0: self.shake-=1
        t = pygame.time.get_ticks()
        for p in players:
            if p.dead: continue
            dist = math.hypot(p.x-(self.x+self.w//2), p.y-(self.y+self.h//2))
            if dist<110 and p.state=="attack" and p.st>10 and t-self._lt>700:
                self.hp-=1; self.shake=16; self._lt=t; p.st=0
                ps.spark(self.x+self.w//2, self.y+self.h//2)
                add_float(self.x+self.w//2, self.y-18, f"GRADES {self.hp}/3!", YELLOW)
                if self.hp<=0:
                    self.freed=True
                    ps.ink_splat(self.x+self.w//2, self.y+self.h//2, GOLD)
                    add_float(self.x+self.w//2, self.y-40, "✦ KIRA LIVRE! ✦", GOLD)
                    return True
        return False
    def draw(self, surf, cx):
        if self.freed: return
        off = random.randint(-3,3) if self.shake>0 else 0
        sx = int(self.x-cx)+off; sy = self.y
        # back wall
        pygame.draw.rect(surf, (50,30,15), (sx,sy,self.w,self.h))
        pygame.draw.rect(surf, INK, (sx,sy,self.w,self.h), 3)
        # bars
        bc = [GOLD,(210,160,40),(140,90,20)][3-self.hp]
        for bx in range(sx+10, sx+self.w-4, 16):
            pygame.draw.line(surf, INK,  (bx+1,sy+1), (bx+1,sy+self.h+1), 7)
            pygame.draw.line(surf, bc,   (bx,sy),     (bx,sy+self.h),     5)
        pygame.draw.line(surf, INK, (sx,sy+2), (sx+self.w,sy+2), 5)
        pygame.draw.line(surf, bc,  (sx,sy),   (sx+self.w,sy),   3)
        pygame.draw.line(surf, INK, (sx,sy+self.h), (sx+self.w,sy+self.h), 4)
        # Kira silhouette — pink cartoon girl
        ink_circle(surf, PINK, sx+self.w//2, sy+24, 14, 2)   # head
        # body
        ink_rect(surf, PINK, pygame.Rect(sx+self.w//2-10, sy+36, 20, 30), 2)
        # hair
        pts = [(sx+self.w//2-14,sy+16),(sx+self.w//2+14,sy+16),
               (sx+self.w//2+16,sy+30),(sx+self.w//2-16,sy+30)]
        ink_poly(surf, (180,40,100), pts, 1)
        # chain
        for i in range(5):
            cx2 = sx+self.w//2-12+i*6; cy2 = sy+62+i*5
            pygame.draw.circle(surf, GREY, (cx2,cy2), 3)
            pygame.draw.circle(surf, INK,  (cx2,cy2), 3, 1)
        hint = F_TINY.render("ATAQUE as grades!", True, INK)
        hs = pygame.Surface((hint.get_width()+6, hint.get_height()+4))
        hs.fill(GOLD); hs.blit(hint,(3,2))
        surf.blit(hs, (sx+self.w//2-hs.get_width()//2, sy-20))

# =============================================================================
# PROJECTILE
# =============================================================================
class Proj:
    def __init__(self, x, y, vx, vy, col, dmg, life, ptype, owner=-1):
        self.x,self.y = float(x),float(y)
        self.vx,self.vy = float(vx),float(vy)
        self.col,self.dmg,self.life = col,dmg,life
        self.ptype,self.owner = ptype,owner
        self.w,self.h = 12,8; self.dead = False
        self.trail = []
    def update(self, platforms, players, enemies, gs):
        self.trail.append((self.x, self.y))
        if len(self.trail)>6: self.trail.pop(0)
        self.x+=self.vx; self.y+=self.vy; self.vy+=0.04; self.life-=1
        if self.life<=0: self.dead=True; return
        r = pygame.Rect(int(self.x),int(self.y),self.w,self.h)
        for p in platforms:
            if r.colliderect(p.rect()):
                ps.spark(self.x,self.y); self.dead=True; return
        if self.ptype=="player":
            for e in enemies:
                if e.dead: continue
                if r.colliderect(e.rect()):
                    att = next((p for p in players if p.slot==self.owner),None)
                    e.take_damage(self.dmg, att, gs)
                    ps.ink_splat(self.x,self.y,self.col); self.dead=True; return
            if gs.boss and not gs.boss.dead and r.colliderect(gs.boss.rect()):
                gs.boss.take_damage(self.dmg,gs)
                ps.spark(self.x,self.y); self.dead=True; return
        else:
            for p in players:
                if p.dead or p.inv>0: continue
                if r.colliderect(p.rect()):
                    p.take_damage(self.dmg); self.dead=True; return
    def draw(self, surf, cx):
        # draw trail
        for i,(tx,ty) in enumerate(self.trail):
            a = (i+1)/len(self.trail) * 0.5
            r = max(2,int(self.w//2*a))
            tc = tuple(int(c*a*0.6) for c in self.col)
            pygame.draw.circle(surf, tc, (int(tx-cx),int(ty)), r)
        sx = int(self.x-cx)
        if -20<sx<W+20:
            ink_circle(surf, self.col, sx+self.w//2, int(self.y)+self.h//2,
                       self.w//2, 1)

# =============================================================================
# ENEMY  (Cuphead cartoon designs)
# =============================================================================
EDAT = {
    "rat":      (45, 22,24, 2.2,  8,  50),
    "insect":   (38, 20,20, 1.8, 12,  75),
    "monkey":   (65, 26,36, 3.0, 15, 100),
    "robot":    (85, 30,40, 2.0, 20, 150),
    "dragon":   (130,44,40, 2.8, 25, 200),
    "skeleton": (55, 26,40, 2.0, 14, 120),
}
ECOL = {
    "rat":(160,100,60),"insect":(50,140,20),"monkey":(120,70,20),
    "robot":(70,110,140),"dragon":(180,20,20),"skeleton":(220,210,190)
}

class Enemy:
    def __init__(self, et, x, y):
        self.et=et; hp,w,h,spd,dmg,sc = EDAT[et]
        self.hp=float(hp); self.mhp=float(hp)
        self.w,self.h=w,h; self.spd=spd; self.dmg=dmg; self.sc=sc
        self.col=ECOL[et]
        self.x,self.y=float(x),float(y-h)
        self.vx=self.vy=0.0; self.on_gnd=False; self.facing=-1
        self.dead=False; self.stun=0; self.acd=0
        self.pd=-1; self.pt=0; self.sx=float(x)
        self.at=self.af=0
        # squash/stretch
        self.sq=1.0; self.st2=1.0
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)
    def take_damage(self, dmg, att, gs):
        if self.dead: return
        self.hp-=dmg; self.stun=16
        add_float(self.x+self.w//2, self.y-8, f"-{int(dmg)}", RED)
        self.sq=1.4; self.st2=0.7   # squash on hit
        if self.hp<=0: self._die(att,gs)
    def _die(self, att, gs):
        self.dead=True
        ps.ink_splat(self.x+self.w//2, self.y+self.h//2, self.col)
        gs.score+=self.sc
        rex=next((p for p in gs.players if p.is_rex and not p.dead),None)
        if rex and math.hypot(rex.x-self.x,rex.y-self.y)<240: rex.absorb(self.et)
    def update(self, platforms, players, gs):
        if self.dead: return
        # restore squash/stretch
        self.sq=lerp(self.sq,1.0,0.2); self.st2=lerp(self.st2,1.0,0.2)
        if self.stun>0: self.stun-=1; return
        if self.acd>0: self.acd-=1
        self.at+=1
        if self.at>=8: self.at=0; self.af=(self.af+1)%4
        near=None; nd=9999.0
        for p in players:
            if p.dead: continue
            d=math.hypot(p.x-self.x,p.y-self.y)
            if d<nd: nd=d; near=p
        if near and nd<280:
            self.facing=1 if near.x>self.x else -1
            self.vx=self.facing*self.spd
            if self.on_gnd and near.y<self.y-50 and random.random()<0.025: self.vy=-13
            if nd<self.w+20 and self.acd==0: near.take_damage(self.dmg); self.acd=60
            if self.et in("insect","robot","skeleton") and self.acd==0 and 90<nd<290:
                dx=near.x-self.x; dy=near.y-self.y; dd=math.hypot(dx,dy) or 1
                col=(80,220,80) if self.et=="insect" else (200,200,200)
                gs.projectiles.append(Proj(self.x+self.w//2,self.y+self.h//2,
                    dx/dd*6,dy/dd*6,col,self.dmg,70,"enemy"))
                self.acd=90
        else:
            self.pt+=1
            if self.pt>80: self.pd*=-1; self.pt=0
            if abs(self.x-self.sx)>160: self.pd=1 if self.sx>self.x else -1
            self.vx=self.pd*self.spd*0.4; self.facing=self.pd
        self.vy+=GRAVITY; self.vy=min(self.vy,16)
        self.x+=self.vx; self.y+=self.vy; self.vx*=0.84
        self.on_gnd=False; er=self.rect()
        for p in platforms:
            pr=p.rect()
            if er.colliderect(pr) and self.vy>=0 and er.bottom-pr.top<24 and er.top<pr.top:
                self.y=pr.top-self.h; self.vy=0; self.on_gnd=True
    def draw(self, surf, cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-80 or sx>W+80: return
        c=self.col
        # squash-stretch offset
        sqx=int(self.w*self.sq); sqy=int(self.h*self.st2)
        ox=sx+(self.w-sqx)//2; oy=sy+(self.h-sqy)
        et=self.et
        if et=="rat":
            ink_circle(surf,c,ox+sqx//2,oy+sqy//2,sqx//2+2,2)
            ink_circle(surf,(220,160,140),ox+sqx//2+int(self.facing*4),oy+sqy//4,sqx//3,2)
            # eye
            ink_circle(surf,WHITE,ox+sqx//2+int(self.facing*8),oy+sqy//4-2,4,1)
            ink_circle(surf,INK,ox+sqx//2+int(self.facing*9),oy+sqy//4-2,2,0)
            # ear
            ink_poly(surf,(220,140,120),[(ox+sqx//2,oy-4),(ox+sqx//2+6,oy+10),(ox+sqx//2-6,oy+10)],1)
        elif et=="insect":
            ink_circle(surf,c,ox+sqx//2,oy+sqy//2,sqx//2,2)
            ink_circle(surf,(150,255,100),ox+sqx//2,oy+sqy//4,sqx//3+2,2)
            for side in(-1,1):
                pygame.draw.line(surf,INK,(ox+sqx//2,oy+sqy//2),(ox+sqx//2+side*sqx,oy+sqy//3),2)
                pygame.draw.line(surf,INK,(ox+sqx//2,oy+sqy//2),(ox+sqx//2+side*sqx,oy+sqy//2+4),2)
            ink_circle(surf,RED,ox+sqx//2+int(self.facing*10),oy+sqy//4-2,3,1)
        elif et=="monkey":
            ink_circle(surf,c,ox+sqx//2,oy+sqy//2+4,sqx//2+3,3)
            ink_circle(surf,(180,130,60),ox+sqx//2,oy+sqy//4,sqx//2+2,2)
            ink_circle(surf,(220,170,90),ox+sqx//2+int(self.facing*4),oy+sqy//3,sqx//3,1)
            ink_circle(surf,RED,ox+sqx//2+int(self.facing*12),oy+sqy//4-2,4,1)
        elif et=="robot":
            ink_rect(surf,c,pygame.Rect(ox+2,oy+sqy//3,sqx-4,sqy*2//3),3)
            ink_rect(surf,(80,130,160),pygame.Rect(ox+4,oy,sqx-8,sqy//3+2),2)
            ink_circle(surf,CYAN,ox+sqx//3,oy+sqy//6,4,1)
            ink_circle(surf,CYAN,ox+sqx*2//3,oy+sqy//6,4,1)
            pygame.draw.line(surf,INK,(ox+2,oy+sqy//3),(ox+sqx-2,oy+sqy//3),2)
        elif et=="dragon":
            ink_circle(surf,c,ox+sqx//2,oy+sqy//2,sqx//2+4,3)
            ink_circle(surf,(220,60,20),ox+sqx//2+int(self.facing*8),oy+sqy//3,sqx//3,2)
            ink_circle(surf,YELLOW,ox+sqx//2+int(self.facing*14),oy+sqy//3-2,5,1)
            ink_poly(surf,(80,0,0),[(ox+sqx//2,oy-2),(ox+sqx//2+int(self.facing*4),oy-14),(ox+sqx//2+int(self.facing*10),oy)],1)
            # wing
            ink_poly(surf,(120,0,0),[(ox,oy+4),(ox-int(self.facing*20),oy-12),(ox,oy+sqy//2)],1)
        elif et=="skeleton":
            ink_circle(surf,c,ox+sqx//2,oy+4,sqx//2,2)
            pygame.draw.circle(surf,INK,(ox+sqx//3,oy+2),3)
            pygame.draw.circle(surf,INK,(ox+sqx*2//3,oy+2),3)
            ink_rect(surf,c,pygame.Rect(ox+sqx//4,oy+sqy//3,sqx//2,sqy*2//3),2)
            pygame.draw.line(surf,INK,(ox+2,oy+sqy//2),(ox+sqx-2,oy+sqy//2),2)
            for i in range(3): pygame.draw.line(surf,INK,(ox+4+i*6,oy+sqy//3+2),(ox+4+i*6,oy+sqy//2),1)
        # HP bar above enemy
        bw=self.w; pct=max(0,self.hp/self.mhp)
        pygame.draw.rect(surf,INK,(sx,sy-10,bw+2,7))
        pygame.draw.rect(surf,(60,0,0),(sx,sy-10,bw,6))
        hcol=GREEN if pct>0.5 else (YELLOW if pct>0.25 else RED)
        pygame.draw.rect(surf,hcol,(sx,sy-10,int(bw*pct),6))

# =============================================================================
# BOSS  (Cuphead massive cartoon villain)
# =============================================================================
class Boss:
    def __init__(self, bt, x, y, name):
        self.bt,self.name = bt,name
        self.x,self.y = float(x),float(y)
        self.w=110 if bt=="dragon_boss" else 92
        self.h=140 if bt=="dragon_boss" else 120
        self.mhp = 1000 if bt=="dragon_boss" else 800
        self.hp = float(self.mhp)
        self.vx=self.vy=0.0; self.on_gnd=False; self.facing=-1
        self.dead=False; self.rage=False
        self.acd=0; self.ap=0; self.stun=0; self.af=self.at=0
        self.sq=1.0; self.st2=1.0   # squash-stretch
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)
    def take_damage(self, dmg, gs):
        if self.dead: return
        self.hp-=dmg; add_float(self.x+self.w//2,self.y-16,f"-{int(dmg)}",RED)
        ps.spark(self.x+self.w//2+random.randint(-40,40),self.y+self.h//2)
        self.sq=1.5; self.st2=0.65
        if not self.rage and self.hp<self.mhp*0.4:
            self.rage=True
            add_float(self.x+self.w//2,self.y-48,"⚡ FASE 2!",RED)
            ps.ink_splat(self.x+self.w//2,self.y+self.h//2,RED)
        if self.hp<=0: self._die(gs)
    def _die(self, gs):
        self.dead=True; gs.score+=5000
        for _ in range(8): ps.ink_splat(self.x+self.w//2+random.randint(-60,60),
                                         self.y+random.randint(0,80),YELLOW)
        gs.boss_bar=False; gs.level_cleared=True
    def update(self, platforms, players, gs):
        if self.dead or self.stun>0: self.stun-=1; return
        self.sq=lerp(self.sq,1.0,0.15); self.st2=lerp(self.st2,1.0,0.15)
        self.at+=1
        if self.at>=6: self.at=0; self.af=(self.af+1)%4
        alive=[p for p in players if not p.dead]
        if not alive: return
        near=min(alive,key=lambda p:math.hypot(p.x-self.x,p.y-self.y))
        self.facing=1 if near.x>self.x else -1
        spd=4.5 if self.rage else 3.0
        self.vx=self.facing*spd
        lw=gs.level_width
        if self.x<lw-700: self.vx=abs(self.vx)
        if self.x+self.w>lw-10: self.vx=-abs(self.vx)
        if self.on_gnd and near.y<self.y-80 and random.random()<0.03: self.vy=-17
        self.acd-=1
        if self.acd<=0:
            self.acd=40 if self.rage else 70
            self.ap=(self.ap+1)%3; self._atk(near,players,gs)
        self.vy+=GRAVITY; self.vy=min(self.vy,18)
        self.x+=self.vx; self.y+=self.vy; self.vx*=0.86
        self.on_gnd=False; br=self.rect()
        for p in platforms:
            pr=p.rect()
            if br.colliderect(pr) and self.vy>=0 and br.bottom-pr.top<26 and br.top<pr.top:
                self.y=pr.top-self.h; self.vy=0; self.on_gnd=True
                self.sq=0.7; self.st2=1.4  # squash on land
        for pl in players:
            if pl.dead or pl.inv>0: continue
            if br.colliderect(pl.rect()): pl.take_damage(28 if self.rage else 20)
    def _atk(self, near, players, gs):
        cx=self.x+self.w//2; cy=self.y+self.h//3
        if self.ap==0:
            cnt=6 if self.rage else 4
            for i in range(cnt):
                dx=near.x-self.x; dy=near.y-self.y; dd=math.hypot(dx,dy) or 1
                sp=(i-cnt//2)*0.4
                gs.projectiles.append(Proj(cx,cy,dx/dd*8+sp,dy/dd*8,
                    DARK_RED,26,90,"enemy"))
        elif self.ap==1:
            if self.on_gnd:
                for pl in players:
                    if not pl.dead and abs(pl.x-self.x)<240: pl.vy=-13; pl.take_damage(18)
                ps.burst(cx,self.y+self.h,BROWN,24,8)
        else:
            self.vx=self.facing*16
    def draw(self, surf, cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-180 or sx>W+180: return
        sqx=int(self.w*self.sq); sqy=int(self.h*self.st2)
        ox=sx+(self.w-sqx)//2; oy=sy+(self.h-sqy)
        bob=int(math.sin(self.af*math.pi/2)*6)
        rc=RED if self.rage else DARK_RED
        lc=tuple(max(0,c-40) for c in rc)
        if self.bt=="dragon_boss":
            # wings
            for side,fac in ((-1,-1),(1,1)):
                wpts=[(ox+sqx//2,oy+60+bob),
                      (ox+sqx//2+side*sqx,oy+20+bob),
                      (ox+sqx//2+side*(sqx+30),oy+90+bob),
                      (ox+sqx//2+side*sqx,oy+110+bob)]
                ink_poly(surf,lc,wpts,3)
            # body
            ink_circle(surf,rc,ox+sqx//2,oy+80+bob,sqx//2+10,4)
            # neck+head
            ink_circle(surf,rc,ox+sqx//2+self.facing*20,oy+30+bob,sqx//3+8,3)
            ink_circle(surf,rc,ox+sqx//2+self.facing*40,oy+10+bob,sqx//3,3)
            # eyes
            ex=ox+sqx//2+self.facing*48; ey=oy+8+bob
            ink_circle(surf,YELLOW,ex,ey,9,2)
            ink_circle(surf,INK,ex+self.facing*2,ey,5,0)
            # horns
            for i in(-1,1):
                ink_poly(surf,(30,0,0),
                    [(ex+i*6,ey-8),(ex+i*14,ey-28),(ex+i*8,ey-8)],2)
            # fire breath
            if self.rage:
                for i in range(4):
                    a=math.radians(-20+i*15)*self.facing
                    ps.emit(ex+self.facing*12,ey+4,
                            math.cos(a)*6+random.uniform(-1,1),
                            math.sin(a)*2+random.uniform(-1,1),
                            (255,80+i*30,i*10),20,5)
        else:  # monkey boss
            # legs
            for side,off2 in ((-1,10),(1,sqx-22)):
                ink_circle(surf,rc,ox+off2,oy+sqy+bob,14,3)
            # body
            ink_circle(surf,rc,ox+sqx//2,oy+sqy//2+10+bob,sqx//2+12,4)
            # arms
            for side in(-1,1):
                ink_circle(surf,rc,ox+sqx//2+side*(sqx//2+20),oy+sqy//3+bob,18,3)
            # head
            ink_circle(surf,rc,ox+sqx//2,oy+10+bob,sqx//2+5,4)
            ink_circle(surf,(200,140,70),ox+sqx//2+self.facing*10,oy+20+bob,sqx//3,2)
            # eyes
            for side in(-1,1):
                ex2=ox+sqx//2+side*18; ey2=oy+6+bob
                ink_circle(surf,YELLOW if self.rage else WHITE,ex2,ey2,8,2)
                ink_circle(surf,INK,ex2+side,ey2,4,0)
            # radioactive symbol
            ink_circle(surf,(0,200,0),ox+sqx//2,oy+sqy//2+10+bob,14,3)
            pygame.draw.line(surf,INK,(ox+sqx//2,oy+sqy//2+bob),(ox+sqx//2,oy+sqy//2+22+bob),3)

# =============================================================================
# PLAYER  (Cuphead cartoon style, squash/stretch)
# =============================================================================
class Player:
    PW, PH = 30, 42
    def __init__(self, cid, slot):
        d = next(x for x in CDEFS if x[0]==cid)
        _,nm,col,spd,jmp,hp,mp,cs = d
        self.cid=cid; self.name=nm; self.color=col
        self.speed=spd; self.jf=jmp; self.max_hp=hp; self.max_mp=mp
        self.ctrl=CTRL[cs]
        self.is_rex=(cid==0); self.is_mago=(cid==3); self.is_kira=(cid==4)
        self.slot=slot
        self.x=80.0+slot*40; self.y=380.0
        self.vx=self.vy=0.0; self.w,self.h=self.PW,self.PH
        self.on_gnd=False; self.jl=2; self.facing=1
        self.hp=float(hp); self.mp=float(mp)
        self.dead=False; self.inv=0; self.acd=0; self.scd=0
        self.at=self.af=0; self.state="idle"; self.st=0
        self.power="none"; self.ptimer=0; self.pbank=["none"]
        self._jh=self._ah=self._sh=self._slh=False
        # squash/stretch
        self.sq=1.0; self.st2=1.0
        # parry system (Cuphead mechanic)
        self.parry_cd=0; self.parry_active=False
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)
    @property
    def invincible(self): return self.inv  # compat alias

    def update(self, keys, platforms, gs):
        if self.dead: return
        c=self.ctrl
        def K(i):
            if self.slot==0: return keys[c[i]]
            return pygame.key.get_pressed()[c[i]]

        self.sq=lerp(self.sq,1.0,0.2); self.st2=lerp(self.st2,1.0,0.2)
        if self.acd>0: self.acd-=1
        if self.scd>0: self.scd-=1
        if self.inv>0: self.inv-=1
        if self.parry_cd>0: self.parry_cd-=1
        if self.ptimer>0: self.ptimer-=1
        elif self.is_rex and self.power!="none": self.power="none"

        mv=False
        if K(0): self.vx=-self.speed; self.facing=-1; mv=True
        elif K(1): self.vx=self.speed; self.facing=1; mv=True
        else: self.vx*=0.72

        if K(2):
            if not self._jh and self.jl>0:
                self.vy=-self.jf; self.jl-=1
                ps.burst(self.x+self.w//2,self.y+self.h,self.color,8,3)
                self.sq=1.5; self.st2=0.6; self._jh=True
        else: self._jh=False

        if K(3) and self.on_gnd and not self._slh:
            self.vx+=self.facing*10
            ps.burst(self.x+self.w//2,self.y+self.h,SEPIA,5,2)
            self._slh=True
        elif not K(3): self._slh=False

        if K(4) and self.acd==0 and not self._ah:
            self._attack(gs); self.acd=20; self._ah=True
            self.state="attack"; self.st=14
        elif not K(4): self._ah=False

        if K(5) and self.acd==0 and not self._ah:
            self._ranged(gs); self.acd=25; self._ah=True
        
        if K(6) and self.scd==0 and self.mp>=30 and not self._sh:
            self._special(gs); self.scd=90; self.mp-=30
            self._sh=True; self.state="special"; self.st=22
        elif not K(6): self._sh=False

        self.vy+=GRAVITY; self.vy=min(self.vy,18)
        self.x+=self.vx; self.y+=self.vy
        if self.x<0: self.x=0
        if self.x+self.w>gs.level_width: self.x=gs.level_width-self.w

        prev_gnd=self.on_gnd; self.on_gnd=False
        r=self.rect()
        for p in platforms:
            pr=p.rect()
            if not r.colliderect(pr): continue
            ox=min(r.right-pr.left,pr.right-r.left)
            oy2=min(r.bottom-pr.top,pr.bottom-r.top)
            if oy2<=ox:
                if self.vy>=0 and r.centery<pr.centery:
                    self.y=float(pr.top-self.h); self.vy=0; self.on_gnd=True; self.jl=2
                elif self.vy<0 and r.centery>pr.centery:
                    self.y=float(pr.bottom); self.vy=0
            else:
                if r.centerx<pr.centerx: self.x=float(pr.left-self.w)
                else: self.x=float(pr.right)
                self.vx=0
            r=self.rect()

        # squash on land
        if not prev_gnd and self.on_gnd:
            self.sq=1.4; self.st2=0.65

        if self.y>H+150: self.take_damage(9999)
        self.mp=min(self.max_mp,self.mp+0.05)
        self.at+=1
        if self.at>=7: self.at=0; self.af=(self.af+1)%4
        if self.st>0: self.st-=1
        else:
            self.state="jump" if not self.on_gnd else ("run" if mv else "idle")

    def _attack(self, gs):
        cx=self.x+self.w//2+self.facing*34; cy=self.y+self.h//2
        hit=False
        for e in gs.enemies:
            if e.dead: continue
            if abs(e.x+e.w//2-cx)<62 and abs(e.y+e.h//2-cy)<50:
                d=random.randint(20,32)
                if self.is_rex and self.power=="fire": d=int(d*1.6)
                if self.is_rex and self.power=="electric": d=int(d*1.35)
                if self.is_mago: d=int(d*0.85)
                e.take_damage(d,self,gs); ps.ink_splat(e.x+e.w//2,e.y+e.h//2,RED); hit=True
        if gs.boss and not gs.boss.dead:
            b=gs.boss
            if abs(b.x+b.w//2-cx)<72 and abs(b.y+b.h//2-cy)<72:
                gs.boss.take_damage(random.randint(16,26),gs); ps.spark(b.x+b.w//2,b.y+b.h//2)
        if not hit: ps.spark(cx,cy)

    def _ranged(self, gs):
        col=self.color; spd=10; dmg=14
        if self.is_rex:
            if self.power=="fire": col=(255,80,10); dmg=22
            if self.power=="electric": col=YELLOW; dmg=18
        if self.is_mago: col=PURPLE; dmg=24; spd=11
        # Cuphead: three-round burst for style
        for i in range(2):
            spread=random.uniform(-0.5,0.5)
            gs.projectiles.append(Proj(
                self.x+self.w//2, self.y+self.h//2-6+spread*4,
                self.facing*(spd-i*1.5), spread,
                col, dmg-i*3, 85, "player", self.slot))

    def _special(self, gs):
        cx=self.x+self.w//2; cy=self.y+self.h//2
        if self.is_rex:
            if self.power=="fire":
                for dy in (-1.5,0,1.5):
                    gs.projectiles.append(Proj(cx,cy,self.facing*10,dy,(255,80,10),34,65,"player",self.slot))
                ps.burst(cx,cy,(255,80,10),20,8)
            elif self.power=="electric":
                for e in gs.enemies:
                    if not e.dead and math.hypot(e.x-self.x,e.y-self.y)<180:
                        e.take_damage(40,self,gs); ps.spark(e.x+e.w//2,e.y+e.h//2)
                if gs.boss: gs.boss.take_damage(30,gs)
                ps.burst(cx,cy,YELLOW,22,9)
            else:
                for i in range(8):
                    a=math.tau/8*i
                    gs.projectiles.append(Proj(cx,cy,math.cos(a)*7,math.sin(a)*7,GREEN,24,50,"player",self.slot))
                ps.magic(cx,cy)
        elif self.is_mago:
            ps.burst(cx,cy,PURPLE,35,10); ps.burst(cx,cy,(200,100,255),20,14)
            for e in gs.enemies:
                if not e.dead:
                    d=math.hypot(e.x-self.x,e.y-self.y)
                    if d<320: e.take_damage(int(65*(1-d/320)+18),self,gs); ps.magic(e.x+e.w//2,e.y+e.h//2)
            if gs.boss: gs.boss.take_damage(44,gs)
            self.vy=-10
        elif self.is_kira:
            self.vx=self.facing*20; self.inv=26
            for e in gs.enemies:
                if not e.dead and abs(e.x-self.x)<200 and abs(e.y-self.y)<55:
                    e.take_damage(48,self,gs); ps.ink_splat(e.x+e.w//2,e.y+e.h//2,PINK)
            ps.burst(cx,cy,PINK,18,6)
        elif self.name=="VALE":
            for i in range(7):
                gs.projectiles.append(Proj(cx+self.facing*i*20,cy-34,
                    self.facing*5,-7+i*0.6,ORANGE,20,85,"player",self.slot))
            ps.burst(cx,cy,ORANGE,12,5)
        elif self.name=="ZAP":
            for e in gs.enemies:
                if not e.dead and math.hypot(e.x-self.x,e.y-self.y)<150:
                    e.take_damage(50,self,gs); e.stun=65; ps.spark(e.x+e.w//2,e.y+e.h//2)
            if gs.boss and math.hypot(gs.boss.x-self.x,gs.boss.y-self.y)<150: gs.boss.take_damage(35,gs)
            ps.burst(cx,cy,CYAN,22,7)

    def absorb(self, et):
        if not self.is_rex: return
        pwr=EPWR.get(et,"none")
        if pwr!="none" and pwr not in self.pbank: self.pbank.append(pwr)
        self.power=pwr; self.ptimer=720
        ps.absorb(self.x+self.w//2,self.y+self.h//2)
        if pwr!="none": add_float(self.x,self.y-28,f"✦ {POWERS[pwr]['name']}!",POWERS[pwr]['col'])

    def take_damage(self, dmg):
        if self.inv>0 or self.dead: return
        self.hp-=dmg; self.inv=52; self.state="hurt"; self.st=18
        ps.ink_splat(self.x+self.w//2,self.y+self.h//2,self.color)
        self.sq=0.6; self.st2=1.6
        if self.hp<=0:
            self.hp=0; self.dead=True
            ps.ink_splat(self.x+self.w//2,self.y+self.h//2,self.color)
            ps.ink_splat(self.x+self.w//2,self.y+self.h//2,INK)

    def draw(self, surf, cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-80 or sx>W+80: return
        if self.inv>0 and (self.inv//4)%2==1: return
        sqx=int(self.w*self.sq); sqy=int(self.h*self.st2)
        ox=sx+(self.w-sqx)//2; oy=sy+(self.h-sqy)
        if   self.is_rex:  self._draw_rex(surf,ox,oy,sqx,sqy)
        elif self.is_mago: self._draw_mago(surf,ox,oy,sqx,sqy)
        else:              self._draw_human(surf,ox,oy,sqx,sqy)
        # name tag
        ns=F_TINY.render(self.name,True,INK)
        nb=pygame.Surface((ns.get_width()+4,ns.get_height()+2))
        nb.fill(self.color); nb.blit(ns,(2,1))
        surf.blit(nb,(sx+self.w//2-nb.get_width()//2,sy-16))
        if self.is_rex and self.power!="none":
            pc=POWERS[self.power]
            ic=F_TINY.render(f"[{pc['name']}]",True,pc['col'])
            surf.blit(ic,(sx-2,sy-28))

    def _draw_human(self, surf, ox, oy, sqx, sqy):
        c=self.color; dc=tuple(max(0,v-80) for v in c)
        # legs (run bob)
        lg=int(math.sin(self.af*math.pi/2)*8) if self.state=="run" else 0
        ink_rect(surf,dc,pygame.Rect(ox+4,oy+sqy*2//3,sqx//2-2,sqy//3+lg),2)
        ink_rect(surf,dc,pygame.Rect(ox+sqx//2+2,oy+sqy*2//3,sqx//2-2,sqy//3-lg),2)
        # body
        ink_rect(surf,c,pygame.Rect(ox,oy+sqy//3,sqx,sqy//2),3)
        # head
        ink_circle(surf,(230,190,150),ox+sqx//2,oy+sqy//5,sqx//2-2,3)
        # hair
        ink_rect(surf,dc,pygame.Rect(ox,oy,sqx,sqy//5+4),2)
        # eye
        ex=ox+sqx//2+self.facing*10
        ink_circle(surf,WHITE,ex,oy+sqy//5-2,5,2)
        ink_circle(surf,INK,ex+self.facing*2,oy+sqy//5-2,3,0)
        # attack arm flash
        if self.state=="attack" and self.st>4:
            pts=[(ox+sqx//2+self.facing*8,oy+sqy//2-4),
                 (ox+sqx//2+self.facing*36,oy+sqy//2-8),
                 (ox+sqx//2+self.facing*36,oy+sqy//2+4)]
            ink_poly(surf,WHITE,pts,2)

    def _draw_rex(self, surf, ox, oy, sqx, sqy):
        pwr=self.power; gc=POWERS[pwr]['col'] if pwr!="none" else GREEN
        # body
        ink_circle(surf,(110,72,30),ox+sqx//2,oy+sqy*2//3,sqx//2+3,3)
        if pwr!="none": pygame.draw.circle(surf,gc,(ox+sqx//2,oy+sqy*2//3),sqx//2+5,3)
        # head
        ink_circle(surf,(125,82,36),ox+sqx//2+self.facing*6,oy+sqy//3,sqx//2-2,3)
        # ears/horns
        ink_poly(surf,(90,55,20),[(ox+sqx//2,oy+sqy//6),(ox+sqx//2-6,oy-8),(ox+sqx//2+6,oy+sqy//6)],1)
        ink_poly(surf,(90,55,20),[(ox+sqx//2+10,oy+sqy//6),(ox+sqx//2+16,oy-6),(ox+sqx//2+20,oy+sqy//6)],1)
        # eye
        ex=ox+sqx//2+self.facing*14
        ink_circle(surf,WHITE,ex,oy+sqy//4,5,2)
        ink_circle(surf,gc,ex+self.facing,oy+sqy//4,3,0)
        # nose
        ink_circle(surf,(200,140,80),ox+sqx//2+self.facing*18,oy+sqy//3,4,1)
        # tail
        tw=int(math.sin(pygame.time.get_ticks()*0.01)*12)
        ink_poly(surf,(90,55,20),[(ox,oy+sqy*2//3),(ox-14+tw,oy+sqy//2),(ox-10+tw,oy+sqy*3//4)],2)
        if pwr=="fire": ps.emit(ox+sqx//2+self.facing*20,oy+sqy//3,
                                self.facing*2+random.uniform(-1,1),random.uniform(-2,0),(255,80,10),12,3)
        elif pwr=="electric":
            for _ in range(2 if random.random()<0.3 else 0):
                ps.emit(ox+sqx//2,oy+sqy//3,random.uniform(-4,4),random.uniform(-4,4),YELLOW,10,2)

    def _draw_mago(self, surf, ox, oy, sqx, sqy):
        c=PURPLE
        # robe
        ink_poly(surf,(70,10,100),
            [(ox,oy+sqy),(ox+sqx,oy+sqy),(ox+sqx-4,oy+sqy//3),(ox+4,oy+sqy//3)],3)
        ink_poly(surf,c,
            [(ox+3,oy+sqy-3),(ox+sqx-3,oy+sqy-3),(ox+sqx-7,oy+sqy//3+3),(ox+7,oy+sqy//3+3)],2)
        # robe stars
        for i in range(3):
            star_x=ox+8+i*sqx//4; star_y=oy+sqy//2+i*8
            pygame.draw.circle(surf,(200,160,255),(star_x,star_y),2)
        # head
        ink_circle(surf,(230,190,150),ox+sqx//2,oy+sqy//4,sqx//2-4,3)
        # wizard hat
        ink_poly(surf,(50,0,80),
            [(ox-2,oy+sqy//8),(ox+sqx+2,oy+sqy//8),
             (ox+sqx,oy+sqy//8-5),(ox+sqx//2,oy-28),(ox+2,oy+sqy//8-5)],2)
        pygame.draw.rect(surf,(80,0,140),(ox-4,oy+sqy//8-5,sqx+8,7))
        pygame.draw.rect(surf,INK,(ox-4,oy+sqy//8-5,sqx+8,7),2)
        # eyes
        ink_circle(surf,CYAN,ox+sqx//2-8,oy+sqy//4-2,4,1)
        ink_circle(surf,CYAN,ox+sqx//2+8,oy+sqy//4-2,4,1)
        # staff (right side)
        sx2=ox+sqx+3
        pygame.draw.line(surf,INK,(sx2+1,oy-8+1),(sx2+1,oy+sqy+1),4)
        pygame.draw.line(surf,(130,90,20),(sx2,oy-8),(sx2,oy+sqy),3)
        ink_circle(surf,PURPLE,sx2,oy-10,8,2)
        # orb glow
        if (pygame.time.get_ticks()//200)%2==0:
            pygame.draw.circle(surf,(220,160,255),(sx2,oy-10),10,1)
        if self.state=="attack" and self.st>4:
            pygame.draw.arc(surf,(200,100,255),
                (ox+self.facing*2,oy+sqy//4-6,34,22),0,math.pi,4)

# =============================================================================
# LEVEL DATA
# =============================================================================
def _p(*a, **k): return Platform(*a, **k)
def _s(x,y,n=4): return Spike(x,y,n)
def _e(t,x,y):   return Enemy(t,x,y)
def _c(x,y,t):   return Collectible(x,y,t)

def make_lv1():
    GS_COL=(80,55,30); GS_SOIL=(55,38,18)
    def gp(*a): return Platform(*a,col=GS_COL,soil=GS_SOIL)
    plats=[
        gp(0,460,400,60),gp(460,460,340,60),gp(860,460,500,60),
        gp(1420,460,380,60),gp(1860,460,300,60),gp(2220,460,580,60),
        gp(2860,460,440,60),gp(3360,460,340,60),
        gp(180,356,160,18),gp(490,310,130,18),gp(700,268,110,18),
        gp(900,334,180,18),gp(1140,284,130,18),gp(1400,312,150,18),
        gp(1600,252,110,18),gp(1860,322,140,18),gp(2070,270,160,18),
        gp(2300,310,130,18),gp(2510,258,110,18),gp(2710,330,190,18),
        gp(2960,268,160,18),gp(3110,218,130,18),gp(3310,302,180,18),
    ]
    return dict(
        name="ATO I — CIDADE DESTRUÍDA", width=3700,
        platforms=plats,
        spikes=[_s(400,440,3),_s(1370,440,3),_s(1820,440,4)],
        enemies=[
            _e("rat",600,420),_e("rat",860,420),_e("insect",1010,294),
            _e("rat",1200,420),_e("insect",1470,272),_e("robot",1700,420),
            _e("skeleton",1960,242),_e("robot",2240,420),_e("insect",2430,218),
            _e("robot",2620,290),_e("robot",2900,420),_e("skeleton",3090,178),
            _e("rat",3200,420),_e("dragon",3280,420),
        ],
        collectibles=[
            _c(300,316,"memory"),_c(900,294,"health"),_c(1590,212,"memory"),
            _c(2500,218,"health"),_c(3100,178,"powerup"),
        ],
        boss=Boss("dragon_boss",3500,310,"DRAGÃO ALFA"),
        prison=Prison(590,388),
        bg_top=(28,18,44),bg_bot=(18,12,32),accent=(44,28,68),
        memory="...fogo por toda parte...\nRex... esse nome...\nalgo quente ao meu lado\nno incêndio.",
    )

def make_lv2():
    GS_COL=(40,90,30); GS_SOIL=(25,60,15)
    def gp(*a): return Platform(*a,col=GS_COL,soil=GS_SOIL)
    plats=[
        gp(0,460,360,60),gp(420,460,360,60),gp(840,460,360,60),
        gp(1260,460,440,60),gp(1760,460,360,60),gp(2180,460,500,60),
        gp(2740,460,400,60),gp(3200,460,400,60),gp(3660,460,100,60),
        gp(180,352,150,18),gp(460,302,130,18),gp(660,252,110,18),
        gp(910,312,170,18),gp(1110,262,130,18),gp(1360,292,160,18),
        gp(1610,232,130,18),gp(1860,302,150,18),gp(2060,252,140,18),
        gp(2360,282,130,18),gp(2610,222,120,18),gp(2860,302,190,18),
        gp(3060,252,150,18),gp(3310,212,140,18),gp(3560,272,170,18),
    ]
    return dict(
        name="ATO II — FLORESTA MUTANTE", width=3860,
        platforms=plats,
        spikes=[_s(370,440,3),_s(810,440,3),_s(1710,440,4),_s(2700,440,3)],
        enemies=[
            _e("monkey",510,420),_e("rat",770,420),_e("monkey",960,272),
            _e("insect",1160,222),_e("monkey",1410,252),_e("skeleton",1660,192),
            _e("monkey",1910,420),_e("insect",2110,212),_e("monkey",2410,242),
            _e("insect",2660,182),_e("robot",2910,262),_e("monkey",3110,212),
            _e("skeleton",3360,172),_e("monkey",3610,232),
        ],
        collectibles=[
            _c(260,312,"memory"),_c(820,212,"health"),_c(1600,192,"memory"),
            _c(2600,182,"powerup"),_c(3300,172,"health"),
        ],
        boss=Boss("monkey_boss",3660,330,"MACACO ALFA RADIOATIVO"),
        prison=None,
        bg_top=(8,22,8),bg_bot=(4,14,4),accent=(12,36,12),
        memory="...Rex... eu me lembro...\num filhote que me lambeu o rosto\nno laboratório em chamas.",
    )

LEVELS = [make_lv1, make_lv2]

# =============================================================================
# GAME STATE
# =============================================================================
class GS:
    def __init__(self):
        self.screen="title"; self.score=0; self.num_players=1; self.cur=0
        self.players=[]; self.platforms=[]; self.spikes=[]
        self.enemies=[]; self.collectibles=[]; self.projectiles=[]
        self.boss=None; self.boss_active=False; self.boss_bar=False
        self.level_cleared=False; self.game_over=False
        self.cam_x=0.0; self.level_width=3700
        self.mem_count=0; self.trigger_mem=False; self.mem_text=""
        self.level_name=""; self.level_mem=""
        self.frame=0; self.sel_num=1
        self.vic_t=0; self.mem_t=0
        self.prison=None; self.kira_freed=False
        self.bg_top=(28,18,44); self.bg_bot=(18,12,32); self.accent=(44,28,68)
    def load(self, idx):
        global floats; floats=[]; ps.p=[]
        d=LEVELS[idx]()
        self.platforms=d["platforms"]; self.spikes=d["spikes"]
        self.enemies=d["enemies"]; self.collectibles=d["collectibles"]
        self.boss=d["boss"]; self.projectiles=[]
        self.boss_active=False; self.boss_bar=False
        self.level_cleared=False; self.game_over=False; self.cam_x=0.0
        self.level_width=d["width"]; self.level_name=d["name"]; self.level_mem=d["memory"]
        self.vic_t=0; self.score=0; self.mem_count=0; self.trigger_mem=False
        self.prison=d.get("prison"); self.kira_freed=False
        self.bg_top=d["bg_top"]; self.bg_bot=d["bg_bot"]; self.accent=d["accent"]
    def _mkp(self, kira=False):
        chars=[0,1,2,3][:self.num_players]
        if kira: chars.append(4)
        self.players=[Player(cid,i) for i,cid in enumerate(chars)]
    def start(self):
        self.cur=0; self.mem_count=0; self.load(0); self._mkp(False); self.screen="game"
    def restart(self):
        kf=self.kira_freed; self.load(self.cur); self._mkp(kf); self.screen="game"
    def next_level(self):
        kf=self.kira_freed; self.cur=(self.cur+1)%len(LEVELS)
        self.load(self.cur); self._mkp(kf); self.screen="game"
    def free_kira(self):
        if self.kira_freed: return
        self.kira_freed=True
        k=Player(4,len(self.players))
        if self.prison: k.x=self.prison.x+20; k.y=self.prison.y-55
        self.players.append(k)

gs = GS()

# =============================================================================
# BACKGROUND  (Cuphead: sepia art-deco + parallax)
# =============================================================================
def draw_bg(surf, cx):
    bt,bb,ac=gs.bg_top,gs.bg_bot,gs.accent
    # gradient sky
    for y in range(0, H, 2):
        t=y/H
        c=(int(lerp(bt[0],bb[0],t)),int(lerp(bt[1],bb[1],t)),int(lerp(bt[2],bb[2],t)))
        pygame.draw.line(surf,c,(0,y),(W,y))
    # moon / sun
    moon_x=W//4; moon_y=H//5
    ink_circle(surf,CREAM,moon_x,moon_y,38,4)
    # craters
    for cx2,cy2,r2 in [(moon_x-12,moon_y+8,7),(moon_x+14,moon_y-12,5),(moon_x+4,moon_y+16,4)]:
        pygame.draw.circle(surf,SEPIA,(cx2,cy2),r2)
        pygame.draw.circle(surf,INK,(cx2,cy2),r2,1)
    # stars (parallax layer 0)
    rng=random.Random(55)
    for _ in range(100):
        px=(rng.randint(0,W*4)-int(cx*0.05))%W
        py=rng.randint(0,int(H*0.6))
        r2=rng.randint(1,2)
        pygame.draw.circle(surf,CREAM,(px,py),r2)
    # far buildings (parallax layer 1)
    rng2=random.Random(9); off=int(cx*0.25)
    for i in range(16):
        bx=(rng2.randint(0,W*2)-off%(W*2)+W*4)%(W*2)-50
        bh=rng2.randint(60,180); bw=rng2.randint(20,50)
        col=(ac[0]+8,ac[1]+8,ac[2]+16)
        pygame.draw.rect(surf,col,(bx,H-bh-44,bw,bh))
        # windows
        for wy in range(H-bh-30,H-44,18):
            for wx2 in range(bx+4,bx+bw-4,10):
                wcol=GOLD if random.Random(wy*wx2).random()>0.5 else col
                pygame.draw.rect(surf,wcol,(wx2,wy,6,9))
        pygame.draw.rect(surf,INK,(bx,H-bh-44,bw,bh),2)
    # mid buildings (parallax layer 2)
    rng3=random.Random(17); off2=int(cx*0.5)
    for i in range(22):
        bx=(rng3.randint(0,W*3)-off2%(W*3)+W*6)%(W*3)-30
        bh=rng3.randint(30,100); bw=rng3.randint(12,32)
        col=(ac[0]+18,ac[1]+18,ac[2]+28)
        pygame.draw.rect(surf,col,(bx,H-bh-40,bw,bh))
        pygame.draw.rect(surf,INK,(bx,H-bh-40,bw,bh),2)

# =============================================================================
# HUD  (Cuphead-style health pips and thick ink borders)
# =============================================================================
_OV_BLK = pygame.Surface((W,H)); _OV_BLK.set_alpha(190); _OV_BLK.fill(BLACK)
_OV_MEM = pygame.Surface((W,H)); _OV_MEM.set_alpha(200); _OV_MEM.fill((20,0,40))

def draw_hud(surf):
    # top bar
    pygame.draw.rect(surf,INK,(0,0,W,54))
    pygame.draw.rect(surf,(30,20,10),(0,0,W,52))
    pygame.draw.rect(surf,INK,(0,52,W,2))
    sw=190
    for i,p in enumerate(gs.players):
        ox=4+i*sw; c=p.color
        lbl=("💀" if p.dead else "")+p.name
        ns=F_TINY.render(lbl,True,CREAM); surf.blit(ns,(ox,3))
        # HP pips (Cuphead style)
        pips=6; hp_pct=max(0,p.hp/p.max_hp)
        for j in range(pips):
            filled=j/pips < hp_pct
            col=RED if filled else (50,10,10)
            rx=ox+j*22; ry=16
            pygame.draw.rect(surf,INK,(rx+1,ry+1,18,10))
            pygame.draw.rect(surf,col,(rx,ry,18,10))
            pygame.draw.rect(surf,INK,(rx,ry,18,10),2)
            if filled: pygame.draw.line(surf,(255,100,100),(rx+3,ry+3),(rx+14,ry+3),2)
        # MP bar
        bw=130; bh=6
        pygame.draw.rect(surf,INK,(ox,29,bw+2,bh+2))
        pygame.draw.rect(surf,(10,10,50),(ox,29,bw,bh))
        pygame.draw.rect(surf,BLUE,(ox,29,int(bw*max(0,p.mp/p.max_mp)),bh))
        if p.is_rex and p.power!="none":
            pc=POWERS[p.power]
            surf.blit(F_TINY.render(f"[{pc['name']} {p.ptimer//60}s]",True,pc['col']),(ox,37))
    # level name centered
    ls=F_SM.render(gs.level_name,True,CREAM)
    lbg=pygame.Surface((ls.get_width()+12,ls.get_height()+4)); lbg.fill((30,20,10))
    pygame.draw.rect(lbg,INK,(0,0,lbg.get_width(),lbg.get_height()),2)
    lbg.blit(ls,(6,2)); surf.blit(lbg,(W//2-lbg.get_width()//2,3))
    # score
    sc=F_TINY.render(f"✦ {gs.score:,}",True,GOLD); surf.blit(sc,(W//2-sc.get_width()//2,22))
    # prison hint
    if gs.prison and not gs.prison.freed and not gs.kira_freed:
        ht=F_TINY.render("KIRA está presa — ataque as grades!",True,GOLD)
        surf.blit(ht,(W//2-ht.get_width()//2,38))
    elif gs.kira_freed:
        ht=F_TINY.render("✦ KIRA LIBERTADA! ✦",True,GOLD); surf.blit(ht,(W//2-ht.get_width()//2,38))
    # boss bar
    if gs.boss_bar and gs.boss and not gs.boss.dead:
        bx=W//2-230; by=H-40; bw=460; bh=16
        pygame.draw.rect(surf,INK,(bx-2,by-2,bw+4,bh+4))
        pygame.draw.rect(surf,(60,0,0),(bx,by,bw,bh))
        pct=max(0,gs.boss.hp/gs.boss.mhp)
        col=RED if pct>0.3 else GOLD
        pygame.draw.rect(surf,col,(bx,by,int(bw*pct),bh))
        pygame.draw.line(surf,WHITE,(bx,by),(bx+int(bw*pct),by),3)
        bn=F_SM.render(f"⚔ {gs.boss.name} ⚔",True,CREAM)
        surf.blit(bn,(W//2-bn.get_width()//2,H-58))
    # controls hint
    hint=F_TINY.render("P1:WASD+ZXC  P2:←→↑+UIO  P3:JLI+NM,  P4:Numpad  Mobile:botões tela",True,GREY)
    surf.blit(hint,(W//2-hint.get_width()//2,H-13))

# =============================================================================
# MENU SCREENS  (Cuphead ink-art style)
# =============================================================================
def draw_title(surf):
    # Sepia-toned background with moon and stars already drawn if we had bg
    surf.fill((16,10,8))
    # stars
    rng=random.Random(123)
    for _ in range(120): surf.set_at((rng.randint(0,W),rng.randint(0,H//2)),(200,180,140))
    # decorative ink border
    pygame.draw.rect(surf,INK,(0,0,W,H),6)
    pygame.draw.rect(surf,GOLD,(8,8,W-16,H-16),2)
    # art-deco corner ornaments
    for bx2,by2 in [(20,20),(W-60,20),(20,H-60),(W-60,H-60)]:
        pygame.draw.rect(surf,GOLD,(bx2,by2,40,40),1)
        pygame.draw.line(surf,GOLD,(bx2,by2),(bx2+40,by2+40),1)
    # title
    t=pygame.time.get_ticks()/1000.0
    # ink-drop shadow + main text
    for offx,offy,c in [(4,4,INK),(2,2,(80,60,20)),(0,0,CREAM)]:
        s1=F_TITLE.render("FORGOTTEN",True,c)
        s2=F_TITLE.render("PAWS",True,c)
        surf.blit(s1,(W//2-s1.get_width()//2+offx,70+offy))
        surf.blit(s2,(W//2-s2.get_width()//2+offx,132+offy))
    # sub
    fl=0.85+0.15*math.sin(t*2.2)
    sc=tuple(int(c*fl) for c in GOLD)
    sub=F_SM.render("~ Uma história de memória e lealdade ~",True,sc)
    surf.blit(sub,(W//2-sub.get_width()//2,196))
    # divider line
    pygame.draw.line(surf,GOLD,(W//2-200,218),(W//2+200,218),2)
    # buttons
    tap_btn(surf,"tap_play","▶  JOGAR",W//2,272,280,56,DARK_RED)
    tap_btn(surf,"tap_exit","SAIR",    W//2,346,180,46,(50,35,15))
    hint=F_TINY.render("Toque/clique • teclado também funciona",True,SEPIA)
    surf.blit(hint,(W//2-hint.get_width()//2,H-20))
    # film grain
    surf.blit(_GRAIN,(0,0))

def draw_char_select(surf):
    surf.fill((10,8,6))
    pygame.draw.rect(surf,INK,(0,0,W,H),6)
    pygame.draw.rect(surf,GOLD,(8,8,W-16,H-16),1)
    s=F_BIG.render("ESCOLHA OS GUERREIROS",True,CREAM)
    surf.blit(s,(W//2-s.get_width()//2,14))
    h2=F_SM.render("(KIRA está presa — resgate-a no Ato I!)",True,GOLD)
    surf.blit(h2,(W//2-h2.get_width()//2,52))
    # player count
    tap_btn(surf,"tap_pl_less","◀",W//2-96,82,44,36,(50,35,15),F_MED)
    cs=F_MED.render(f"{gs.sel_num} jogador{'es' if gs.sel_num>1 else ''}",True,CREAM)
    surf.blit(cs,(W//2-cs.get_width()//2,70))
    tap_btn(surf,"tap_pl_more","▶",W//2+96,82,44,36,(50,35,15),F_MED)
    # character cards
    CDSC=[(0,"REX",GREEN,"Absorve poderes","P2:←→↑+UIO"),
          (1,"VALE",ORANGE,"Arco + flecha","P3:JLI+NM,"),
          (2,"ZAP",CYAN,"Campo elétrico","P4:Numpad"),
          (3,"MAGO",PURPLE,"Arcane Nova","P1:WASD+ZXC"),
          (4,"KIRA",PINK,"🔒 PRESA","Resgate-a!")]
    cw,ch=158,170; gap=8; total=len(CDSC)*(cw+gap)-gap; sx0=W//2-total//2
    for i,(cid,nm,col,atk,ctrl) in enumerate(CDSC):
        cx2=sx0+i*(cw+gap); cy2=100; locked=(cid==4)
        active=(i<gs.sel_num) and not locked
        bc=col if active else (GOLD if locked else (40,30,20))
        # card shadow
        pygame.draw.rect(surf,INK,(cx2+4,cy2+4,cw,ch))
        pygame.draw.rect(surf,(18,13,8),(cx2,cy2,cw,ch))
        pygame.draw.rect(surf,bc,(cx2,cy2,cw,ch),3)
        # char icon circle
        ink_circle(surf,bc,cx2+cw//2,cy2+34,22,2)
        ns2=F_MED.render("🔒" if locked else str(i+1),True,bc)
        surf.blit(ns2,(cx2+cw//2-ns2.get_width()//2,cy2+24))
        # name
        nm2=F_MED.render(nm,True,col if active else (100,80,50) if not locked else GOLD)
        surf.blit(nm2,(cx2+cw//2-nm2.get_width()//2,cy2+62))
        # divider
        pygame.draw.line(surf,bc,(cx2+8,cy2+82),(cx2+cw-8,cy2+82),1)
        for j,line in enumerate([atk,ctrl]):
            ls=F_TINY.render(line,True,CREAM if active else (70,55,35))
            surf.blit(ls,(cx2+6,cy2+88+j*22))
        if active:
            p2=F_TINY.render(f"P{i+1}",True,col); surf.blit(p2,(cx2+5,cy2+5))
    tap_btn(surf,"tap_start","▶ INICIAR AVENTURA",W//2,296,320,54,DARK_RED)
    tap_btn(surf,"tap_back","◀ VOLTAR",           W//2,364,200,44,(50,35,15))
    surf.blit(_GRAIN,(0,0))

def draw_game_over(surf):
    surf.blit(_OV_BLK,(0,0))
    t=pygame.time.get_ticks()
    ox=int(math.sin(t*0.01)*5)
    # big ink text
    for dx,dy,c in [(4,4,INK),(2,2,(80,0,0)),(0,0,RED)]:
        go=F_BIG.render("VOCÊ CAIU",True,c); surf.blit(go,(W//2-go.get_width()//2+ox+dx,155+dy))
    sb=F_SM.render("O apocalipse não perdoa...",True,SEPIA); surf.blit(sb,(W//2-sb.get_width()//2,222))
    tap_btn(surf,"tap_restart","↺ TENTAR NOVAMENTE",W//2,312,310,52,DARK_RED)
    tap_btn(surf,"tap_menu","MENU",                 W//2,380,190,44,(50,35,15))

def draw_victory(surf):
    surf.blit(_OV_BLK,(0,0))
    t=pygame.time.get_ticks()/1000.0
    fc=tuple(int(c*(0.8+0.2*math.sin(t*3))) for c in GOLD)
    for dx,dy,c in [(4,4,INK),(2,2,BROWN),(0,0,fc)]:
        vt=F_BIG.render("✦ VITÓRIA ✦",True,c); surf.blit(vt,(W//2-vt.get_width()//2+dx,128+dy))
    sc=F_MED.render(f"PONTUAÇÃO: {gs.score:,}",True,CREAM); surf.blit(sc,(W//2-sc.get_width()//2,208))
    mem=F_SM.render("Uma memória retornou...",True,PURPLE); surf.blit(mem,(W//2-mem.get_width()//2,254))
    tap_btn(surf,"tap_next","▶ PRÓXIMA FASE",W//2,336,270,52,(20,80,20))
    tap_btn(surf,"tap_menu","MENU",          W//2,404,190,44,(50,35,15))

def draw_memory(surf):
    surf.blit(_OV_MEM,(0,0))
    pygame.draw.rect(surf,PURPLE,(W//2-310,140,620,240),2)
    pygame.draw.rect(surf,GOLD,(W//2-308,142,616,236),1)
    for dx,dy,c in [(3,3,INK),(0,0,(200,160,255))]:
        ts=F_MED.render("✦ FRAGMENTO DE MEMÓRIA ✦",True,c)
        surf.blit(ts,(W//2-ts.get_width()//2+dx,158+dy))
    for i,line in enumerate(gs.mem_text.split("\n")):
        ls=F_SM.render(line.strip(),True,CREAM); surf.blit(ls,(W//2-ls.get_width()//2,228+i*32))
    tap_btn(surf,"tap_continue","CONTINUAR",W//2,H-58,230,44,(60,30,100))

# =============================================================================
# TAP HANDLER
# =============================================================================
def handle_tap(name, paused):
    if   name=="tap_play":     gs.screen="char_select"
    elif name=="tap_exit":     pygame.quit(); raise SystemExit
    elif name=="tap_pl_less":  gs.sel_num=max(1,gs.sel_num-1); gs.num_players=gs.sel_num
    elif name=="tap_pl_more":  gs.sel_num=min(4,gs.sel_num+1); gs.num_players=gs.sel_num
    elif name=="tap_start":    gs.start()
    elif name=="tap_back":     gs.screen="title"
    elif name=="tap_restart":  gs.restart()
    elif name=="tap_menu":     gs.screen="title"
    elif name=="tap_next":     gs.next_level()
    elif name=="tap_continue": gs.screen="game"
    elif name=="tap_pause":    paused[0]=not paused[0]

# =============================================================================
# MAIN LOOP
# KEY FIX: order is  DRAW → flip → process_events → update
# This guarantees tap_zones is always populated when clicks arrive.
# =============================================================================
async def main():
    paused = [False]

    while True:
        clock.tick(FPS)
        mk.refresh()
        gs.frame += 1

        # ── 1. DRAW (populates tap_zones) ────────────────────────────────────
        tap_zones.clear()
        cx = int(gs.cam_x)

        if gs.screen == "title":
            draw_title(screen)

        elif gs.screen == "char_select":
            draw_char_select(screen)

        elif gs.screen in ("game","memory","game_over","victory"):
            draw_bg(screen, cx)
            for p in gs.platforms:      p.draw(screen, cx)
            for s in gs.spikes:         s.draw(screen, cx)
            for c in gs.collectibles:   c.draw(screen, cx)
            for proj in gs.projectiles: proj.draw(screen, cx)
            for e in gs.enemies:        e.draw(screen, cx)
            if gs.prison and not gs.prison.freed: gs.prison.draw(screen, cx)
            if gs.boss_active and gs.boss and not gs.boss.dead:
                gs.boss.draw(screen, cx)
            for p in gs.players: p.draw(screen, cx)
            ps.draw(screen, cx)
            for ft in floats: ft.draw(screen, cx)
            draw_hud(screen)
            screen.blit(_GRAIN, (0,0))

            if gs.screen == "game":
                mobile.draw(screen)
                tap_btn(screen,"tap_pause","II" if not paused[0] else "▶",
                        W//2,36,52,26,(50,35,15),F_SM)
                if paused[0]:
                    screen.blit(_OV_BLK,(0,0))
                    for dx,dy,c in [(3,3,INK),(0,0,CREAM)]:
                        ps2=F_BIG.render("PAUSADO",True,c)
                        screen.blit(ps2,(W//2-ps2.get_width()//2+dx,H//2-30+dy))
                    tap_btn(screen,"tap_menu","MENU",W//2,H//2+55,170,46,(50,35,15))

            elif gs.screen == "memory":
                gs.mem_t+=1; draw_memory(screen)
            elif gs.screen == "game_over":
                draw_game_over(screen)
            elif gs.screen == "victory":
                draw_victory(screen)

        # ── 2. FLIP ───────────────────────────────────────────────────────────
        pygame.display.flip()

        # ── 3. PROCESS EVENTS (tap_zones now valid from above draw) ──────────
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: pygame.quit(); raise SystemExit

            if gs.screen == "game": mobile.handle(ev)

            # Handle clicks: MOUSEBUTTONDOWN for desktop, FINGERDOWN for Pygbag/touch
            # FINGER coords are normalized 0.0-1.0, must multiply by W,H
            clicked = False; click_x = 0; click_y = 0
            if ev.type == pygame.MOUSEBUTTONDOWN:
                click_x, click_y = ev.pos; clicked = True
            elif ev.type == getattr(pygame, "FINGERDOWN", None):
                click_x = int(ev.x * W); click_y = int(ev.y * H); clicked = True
            if clicked:
                for name,r in list(tap_zones.items()):
                    if r.collidepoint(click_x, click_y):
                        handle_tap(name, paused); break

            if ev.type == pygame.KEYDOWN:
                k = ev.key
                if gs.screen == "title":
                    if k in (pygame.K_RETURN,pygame.K_SPACE): gs.screen="char_select"
                    if k == pygame.K_ESCAPE: pygame.quit(); raise SystemExit
                elif gs.screen == "char_select":
                    if k==pygame.K_LEFT:  gs.sel_num=max(1,gs.sel_num-1); gs.num_players=gs.sel_num
                    if k==pygame.K_RIGHT: gs.sel_num=min(4,gs.sel_num+1); gs.num_players=gs.sel_num
                    if k in (pygame.K_RETURN,pygame.K_SPACE): gs.start()
                    if k==pygame.K_ESCAPE: gs.screen="title"
                elif gs.screen == "game":
                    if k==pygame.K_ESCAPE: gs.screen="title"
                    if k==pygame.K_r:      gs.restart()
                    if k==pygame.K_SPACE:  paused[0]=not paused[0]
                elif gs.screen == "memory":
                    if k in (pygame.K_RETURN,pygame.K_SPACE,pygame.K_ESCAPE): gs.screen="game"
                elif gs.screen == "game_over":
                    if k==pygame.K_r:      gs.restart()
                    if k==pygame.K_ESCAPE: gs.screen="title"
                elif gs.screen == "victory":
                    if k in (pygame.K_RETURN,pygame.K_SPACE): gs.next_level()
                    if k==pygame.K_ESCAPE: gs.screen="title"

        # ── 4. UPDATE ─────────────────────────────────────────────────────────
        if gs.screen == "game" and not paused[0]:
            for p in gs.players:
                p.update(mk if p.slot==0 else pygame.key.get_pressed(), gs.platforms, gs)

            for e in gs.enemies: e.update(gs.platforms, gs.players, gs)

            if gs.prison and not gs.prison.freed:
                if gs.prison.try_break(gs.players, gs): gs.free_kira()

            all_dead=all(e.dead for e in gs.enemies)
            any_near=any(not p.dead and p.x>gs.level_width-800 for p in gs.players)
            if not gs.boss_active and (all_dead or any_near):
                gs.boss_active=True; gs.boss_bar=True
                add_float(gs.boss.x+gs.boss.w//2,gs.boss.y-70,"⚠ BOSS!",RED)
                ps.ink_splat(gs.boss.x+gs.boss.w//2,gs.boss.y+gs.boss.h//2,RED)
            if gs.boss_active and not gs.boss.dead:
                gs.boss.update(gs.platforms,gs.players,gs)

            live=[]
            for proj in gs.projectiles:
                proj.update(gs.platforms,gs.players,gs.enemies,gs)
                if not proj.dead: live.append(proj)
            gs.projectiles=live

            for c in gs.collectibles: c.update(gs.players,gs)
            for s in gs.spikes: s.hurt(gs.players)
            ps.update()
            for ft in floats: ft.update()
            floats[:]=[ft for ft in floats if ft.life>0]

            alive=[p for p in gs.players if not p.dead]
            if alive:
                avg=sum(p.x for p in alive)/len(alive)
                gs.cam_x=lerp(gs.cam_x,max(0,min(gs.level_width-W,avg-W//3)),0.09)

            if all(p.dead for p in gs.players) and not gs.game_over:
                gs.game_over=True; gs.screen="game_over"

            if gs.level_cleared and not gs.game_over:
                gs.vic_t+=1
                if gs.vic_t>120: gs.screen="victory"; gs.level_cleared=False

            if gs.trigger_mem:
                gs.trigger_mem=False; gs.mem_text=gs.level_mem
                gs.mem_t=0; gs.screen="memory"

        await asyncio.sleep(0)

asyncio.run(main())
