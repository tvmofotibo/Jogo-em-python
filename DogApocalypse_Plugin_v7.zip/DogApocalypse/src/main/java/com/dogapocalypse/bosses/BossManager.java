package com.dogapocalypse.bosses;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Central manager for all boss encounters.
 *
 * Responsibilities:
 * - Spawning bosses by ID
 * - Ticking active bosses every 20 server ticks (1s)
 * - Handling boss death callbacks
 * - Mapping entity UUIDs to boss instances
 */
public class BossManager {

    private final DogApocalypsePlugin plugin;

    /** BossId -> Active boss instance (only one of each type at a time) */
    private final Map<String, AbstractBoss> activeBosses = new HashMap<>();

    /** Entity UUID -> Boss (for quick death lookup) */
    private final Map<UUID, AbstractBoss> entityBossMap = new HashMap<>();

    private int tickTaskId = -1;

    public BossManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        startTickTask();
    }

    // ----------------------------------------------------------------
    // Tick
    // ----------------------------------------------------------------

    private void startTickTask() {
        tickTaskId = new BukkitRunnable() {
            @Override
            public void run() {
                for (AbstractBoss boss : activeBosses.values()) {
                    if (boss.isActive()) boss.tick();
                }
            }
        }.runTaskTimer(plugin, 40L, 20L).getTaskId();
    }

    // ----------------------------------------------------------------
    // Spawn
    // ----------------------------------------------------------------

    /**
     * Spawns a boss by its config ID at the given location.
     *
     * @param bossId   e.g. "mutant_dragon", "radioactive_gorilla"
     * @param location Where to spawn the boss.
     * @return The spawned AbstractBoss, or null if unknown.
     */
    public AbstractBoss spawnBoss(String bossId, Location location) {
        if (activeBosses.containsKey(bossId)) {
            plugin.getLogger().warning("Boss " + bossId + " is already active!");
            return activeBosses.get(bossId);
        }

        AbstractBoss boss = createBoss(bossId);
        if (boss == null) {
            plugin.getLogger().warning("Unknown boss ID: " + bossId);
            return null;
        }

        var entity = boss.spawn(location);
        if (entity == null) return null;

        activeBosses.put(bossId, boss);
        entityBossMap.put(entity.getUniqueId(), boss);

        plugin.getLogger().info("Boss spawned: " + bossId + " at " + location.toVector());
        return boss;
    }

    private AbstractBoss createBoss(String bossId) {
        return switch (bossId.toLowerCase()) {
            case "mutant_dragon"      -> new MutantDragon(plugin);
            case "radioactive_gorilla" -> new RadioactiveGorilla(plugin);
            case "war_machine"        -> new WarMachineRobot(plugin);
            case "lab_monster"        -> new LaboratoryMonster(plugin);
            default -> null;
        };
    }

    // ----------------------------------------------------------------
    // Death handling (called from BossListener)
    // ----------------------------------------------------------------

    public void handleBossDeath(UUID entityUUID, List<Player> participants) {
        AbstractBoss boss = entityBossMap.remove(entityUUID);
        if (boss == null) return;

        activeBosses.remove(boss.getBossId());
        boss.onDeath(participants);

        plugin.getLogger().info("Boss defeated: " + boss.getBossId());
    }

    // ----------------------------------------------------------------
    // Queries
    // ----------------------------------------------------------------

    public AbstractBoss getBoss(UUID entityUUID) {
        return entityBossMap.get(entityUUID);
    }

    public boolean isBossEntity(UUID entityUUID) {
        return entityBossMap.containsKey(entityUUID);
    }

    public AbstractBoss getActiveBoss(String bossId) {
        return activeBosses.get(bossId.toLowerCase());
    }

    public boolean isAnyBossActive() {
        return !activeBosses.isEmpty();
    }

    public Collection<AbstractBoss> getAllActiveBosses() {
        return Collections.unmodifiableCollection(activeBosses.values());
    }

    // ----------------------------------------------------------------
    // Cleanup
    // ----------------------------------------------------------------

    public void cleanupAll() {
        if (tickTaskId != -1) {
            plugin.getServer().getScheduler().cancelTask(tickTaskId);
        }
        for (AbstractBoss boss : activeBosses.values()) {
            if (boss.isAlive()) {
                boss.getEntity().remove();
            }
        }
        activeBosses.clear();
        entityBossMap.clear();
    }
}
