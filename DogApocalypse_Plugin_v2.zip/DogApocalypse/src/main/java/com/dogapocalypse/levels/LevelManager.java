package com.dogapocalypse.levels;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import com.dogapocalypse.worldgen.WorldGenerator;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class LevelManager {

    private final DogApocalypsePlugin plugin;
    private final Map<String, LevelData>    levels         = new LinkedHashMap<>();
    private final Map<UUID, LevelSession>   playerSessions = new HashMap<>();
    private final Map<String, LevelSession> activeSessions = new HashMap<>();

    public LevelManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        buildStaticLevels();
    }

    private void buildStaticLevels() {
        levels.put("level_1", new LevelData("level_1", "The Ruined City",     1, 3, "radioactive_gorilla", 2));
        levels.put("level_2", new LevelData("level_2", "The Infected Forest",  2, 4, "lab_monster",         3));
        levels.put("level_3", new LevelData("level_3", "The War Ruins",        3, 5, "war_machine",         3));
        levels.put("level_4", new LevelData("level_4", "The Dragon's Lair",    4, 6, "mutant_dragon",       3));
    }

    public void syncWithWorldGenerator(WorldGenerator gen) {
        for (LevelData data : levels.values()) {
            data.spawnLocation = gen.getLevelSpawn(data.levelIndex);
            plugin.getCheckpointManager().setCheckpoints(
                    data.levelId, gen.getLevelCheckpoints(data.levelIndex));
        }
        plugin.getLogger().info("[LevelManager] Synced spawn locations from WorldGenerator.");
    }

    public boolean startLevel(String levelId, List<Player> players) {
        LevelData levelData = levels.get(levelId);
        if (levelData == null) {
            plugin.getLogger().warning("Unknown level: " + levelId);
            return false;
        }
        Location spawn = levelData.getSpawnLocation();
        if (spawn == null || spawn.getWorld() == null) {
            players.forEach(p -> p.sendMessage(MessageUtil.color(
                    "&cLevel world is still generating. Please wait a moment.")));
            return false;
        }
        if (activeSessions.containsKey(levelId)) {
            players.forEach(p -> p.sendMessage(MessageUtil.color(
                    "&c" + levelData.displayName + " is already in progress!")));
            return false;
        }

        List<UUID> uuids = new ArrayList<>();
        for (Player p : players) uuids.add(p.getUniqueId());

        LevelSession session = new LevelSession(levelId, uuids);
        activeSessions.put(levelId, session);
        for (UUID uuid : uuids) playerSessions.put(uuid, session);

        for (Player p : players) {
            p.teleport(spawn);
            p.sendMessage(MessageUtil.color("&6&l[Level] &fEntering: &e" + levelData.displayName));
            p.sendTitle(MessageUtil.color("&e" + levelData.displayName),
                    MessageUtil.color("&7Prepare yourself..."), 10, 60, 20);
            EffectUtil.spawnParticleCircle(p.getLocation(), Particle.FIREWORKS_SPARK, 25, 2.0);
            plugin.getPlayerDataManager().get(p).setCurrentLevel(levelId);
        }

        final LevelData finalData = levelData;
        final Location finalSpawn = spawn;
        new BukkitRunnable() {
            @Override public void run() {
                if (!activeSessions.containsKey(levelId)) return;
                spawnNextWave(levelId, finalData, finalSpawn);
            }
        }.runTaskLater(plugin, 60L);
        return true;
    }

    private void spawnNextWave(String levelId, LevelData data, Location base) {
        LevelSession session = activeSessions.get(levelId);
        if (session == null || session.completed) return;

        session.currentWave++;
        int wave = session.currentWave;

        if (wave > data.enemyWaves) {
            if (!session.bossSpawned && !data.bossId.isEmpty()) spawnBoss(session, data);
            return;
        }

        broadcastToSession(session, "&c&l[Wave " + wave + "/" + data.enemyWaves + "] &fEnemies incoming!");

        String[] enemyPool = {"mutant_insect", "radioactive_monkey", "infected_wolf", "flame_blaze"};
        int count = 3 + wave;
        for (int i = 0; i < count; i++) {
            String enemyType = enemyPool[i % enemyPool.length];
            double angle = (2 * Math.PI / count) * i;
            double radius = 10 + (wave * 2);
            Location loc = base.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
            plugin.getEnemyManager().spawnEnemy(enemyType, loc);
        }

        final LevelData finalData = data;
        final Location finalBase = base;
        new BukkitRunnable() {
            @Override public void run() { spawnNextWave(levelId, finalData, finalBase); }
        }.runTaskLater(plugin, 300 + (wave * 20));
    }

    private void spawnBoss(LevelSession session, LevelData data) {
        session.bossSpawned = true;
        broadcastToSession(session, "&4&l☠ BOSS: " + data.bossId.toUpperCase().replace('_', ' ') + " ☠");

        Location bossLoc = plugin.getWorldGenerator().getBossArenaCenter(data.levelIndex);
        for (UUID uuid : session.participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) p.teleport(bossLoc.clone().add(0, 1, -8));
        }
        plugin.getBossManager().spawnBoss(data.bossId, bossLoc);
    }

    public void completeLevel(String levelId) {
        LevelSession session = activeSessions.remove(levelId);
        if (session == null || session.completed) return;
        session.completed = true;
        for (UUID uuid : session.participants) playerSessions.remove(uuid);

        long elapsed = (System.currentTimeMillis() - session.startTime) / 1000;
        long m = elapsed / 60, s = elapsed % 60;
        String time = (m > 0 ? m + "m " : "") + s + "s";

        int reward = levelId.equals("level_4") ? 6 : levelId.equals("level_3") ? 4
                   : levelId.equals("level_2") ? 3 : 2;

        for (UUID uuid : session.participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null || !p.isOnline()) continue;
            p.sendMessage(MessageUtil.color("&6&l★ LEVEL COMPLETE! &fTime: &e" + time));
            p.sendTitle(MessageUtil.color("&6LEVEL COMPLETE!"),
                    MessageUtil.color("&eCompleted in " + time), 10, 100, 20);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            p.getWorld().spawnParticle(Particle.FIREWORKS_SPARK,
                    p.getLocation().add(0, 2, 0), 60, 1.0, 1.0, 1.0, 0.3);
            plugin.getPlayerDataManager().get(p).addSkillPoints(reward);
            p.sendMessage(MessageUtil.color("&a+" + reward + " skill points awarded!"));
        }
    }

    private void broadcastToSession(LevelSession session, String msg) {
        for (UUID uuid : session.participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) p.sendMessage(MessageUtil.color(msg));
        }
    }

    public LevelData    getLevel(String levelId)             { return levels.get(levelId); }
    public Collection<String> getLevelIds()                  { return levels.keySet(); }
    public LevelSession getSessionByLevel(String levelId)    { return activeSessions.get(levelId); }
    public LevelSession getSessionByPlayer(UUID uuid)        { return playerSessions.get(uuid); }
}
