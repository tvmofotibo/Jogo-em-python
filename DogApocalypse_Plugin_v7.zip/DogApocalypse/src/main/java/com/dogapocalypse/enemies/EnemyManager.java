package com.dogapocalypse.enemies;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Manages spawning, tracking, and ticking of all custom enemies.
 *
 * Enemies are ticked every 10 server ticks (0.5s) via a repeating BukkitTask.
 * Entity UUIDs are mapped to CustomEnemy instances for fast lookup.
 */
public class EnemyManager {

    private final DogApocalypsePlugin plugin;

    /** UUID of the Bukkit entity -> CustomEnemy wrapper */
    private final Map<UUID, CustomEnemy> activeEnemies = new HashMap<>();

    private int tickTaskId = -1;

    public EnemyManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        startTickTask();
    }

    // ----------------------------------------------------------------
    // Tick loop
    // ----------------------------------------------------------------

    private void startTickTask() {
        tickTaskId = new BukkitRunnable() {
            @Override
            public void run() {
                tickAll();
            }
        }.runTaskTimer(plugin, 20L, 10L).getTaskId();
    }

    private void tickAll() {
        Iterator<Map.Entry<UUID, CustomEnemy>> it = activeEnemies.entrySet().iterator();
        while (it.hasNext()) {
            CustomEnemy enemy = it.next().getValue();
            if (!enemy.isAlive()) {
                it.remove();
                continue;
            }

            // Find nearest player target
            if (enemy.getTarget() == null || !enemy.getTarget().isOnline()
                    || enemy.getTarget().isDead()
                    || enemy.getTarget().getLocation().distance(enemy.getLocation()) > 30) {
                acquireTarget(enemy);
            }

            enemy.tick();
        }
    }

    private void acquireTarget(CustomEnemy enemy) {
        Location loc = enemy.getLocation();
        if (loc == null) return;

        Player nearest = null;
        double minDist = Double.MAX_VALUE;

        for (Player p : loc.getWorld().getPlayers()) {
            if (p.isDead() || !p.isOnline()) continue;
            double dist = p.getLocation().distanceSquared(loc);
            if (dist < minDist && dist < 900) { // 30 blocks
                minDist = dist;
                nearest = p;
            }
        }

        enemy.setTarget(nearest);
    }

    // ----------------------------------------------------------------
    // Spawning
    // ----------------------------------------------------------------

    /**
     * Spawns an enemy of the given typeId at the given location.
     *
     * @param typeId    Config key like "mutant_insect", "flame_blaze", etc.
     * @param location  Where to spawn the entity.
     * @return The spawned CustomEnemy, or null if typeId is unknown.
     */
    public CustomEnemy spawnEnemy(String typeId, Location location) {
        CustomEnemy enemy = EnemyTypes.create(typeId);
        if (enemy == null) {
            plugin.getLogger().warning("Unknown enemy type: " + typeId);
            return null;
        }

        // Override config stats if present
        loadConfigStats(enemy, typeId);

        // Determine entity type from typeId
        EntityType entityType = resolveEntityType(typeId);
        LivingEntity entity = (LivingEntity) location.getWorld().spawnEntity(location, entityType);

        // Setup custom enemy over the entity
        enemy.setup(entity);

        // Mark with metadata so we can identify it later
        entity.setMetadata("da_enemy_type",
                new org.bukkit.metadata.FixedMetadataValue(plugin, typeId));
        entity.setMetadata("da_enemy",
                new org.bukkit.metadata.FixedMetadataValue(plugin, true));

        // Remove default drops and XP to replace with our system
        entity.setRemoveWhenFarAway(false);

        activeEnemies.put(entity.getUniqueId(), enemy);

        // Spawn particles
        location.getWorld().spawnParticle(Particle.SMOKE_LARGE, location.add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.02);

        return enemy;
    }

    private void loadConfigStats(CustomEnemy enemy, String typeId) {
        String path = "enemies." + typeId + ".";
        if (!plugin.getConfig().contains(path + "base_health")) return;

        // We can't set private fields directly; this is done through the subclass constructor
        // The config loading is done in the EnemyTypes factory; this method is a hook for live overrides
    }

    private EntityType resolveEntityType(String typeId) {
        return switch (typeId.toLowerCase()) {
            case "mutant_insect"       -> EntityType.CAVE_SPIDER;
            case "radioactive_monkey"  -> EntityType.PILLAGER;
            case "infected_wolf"       -> EntityType.WOLF;
            case "flame_blaze"         -> EntityType.BLAZE;
            case "mutant_spider"       -> EntityType.SPIDER;
            case "sea_guardian"        -> EntityType.GUARDIAN;
            case "ghost_phantom"       -> EntityType.PHANTOM;
            case "iron_sentinel"       -> EntityType.IRON_GOLEM;
            default                    -> EntityType.ZOMBIE;
        };
    }

    // ----------------------------------------------------------------
    // Lookup
    // ----------------------------------------------------------------

    public CustomEnemy getEnemy(UUID entityUUID) {
        return activeEnemies.get(entityUUID);
    }

    public boolean isCustomEnemy(UUID entityUUID) {
        return activeEnemies.containsKey(entityUUID);
    }

    public Collection<CustomEnemy> getActiveEnemies() {
        return Collections.unmodifiableCollection(activeEnemies.values());
    }

    // ----------------------------------------------------------------
    // Death handling (called from EnemyListener)
    // ----------------------------------------------------------------

    /**
     * Should be called when a custom enemy entity is killed.
     */
    public void handleDeath(UUID entityUUID, Player killer) {
        CustomEnemy enemy = activeEnemies.remove(entityUUID);
        if (enemy == null) return;

        enemy.onDeath(killer);

        // Grant XP to killer
        if (killer != null) {
            plugin.getPlayerDataManager().get(killer).addExperience(enemy.getXpReward());
            plugin.getPlayerDataManager().get(killer).incrementKills();
            killer.giveExpLevels(0);
            killer.giveExp(enemy.getXpReward());

            killer.sendActionBar(MessageUtil.color("&e+" + enemy.getXpReward() + " XP"));

            // Power absorption for Dog class
            if (plugin.getPlayerClassManager().isDog(killer) && enemy.isAbsorbable()) {
                plugin.getDogPowerManager().absorbPower(killer, enemy.getAbsorbablePower());
            }
        }
    }

    // ----------------------------------------------------------------
    // Cleanup
    // ----------------------------------------------------------------

    public void cleanupAll() {
        if (tickTaskId != -1) {
            plugin.getServer().getScheduler().cancelTask(tickTaskId);
        }
        for (CustomEnemy enemy : activeEnemies.values()) {
            if (enemy.isAlive()) {
                enemy.getEntity().remove();
            }
        }
        activeEnemies.clear();
    }
}
