package com.dogapocalypse.menu;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.classes.PlayerClass;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Menu de árvore de habilidades do Cão.
 * Cada habilidade é um item clicável com descrição e custo.
 */
public class MenuHabilidades {

    public static final String TITULO = "§8§l✦ Árvore de Habilidades";

    // Ícones para cada skill
    private static final Material[] ICONES = {
        Material.FEATHER,          // dash_upgrade
        Material.RABBIT_FOOT,      // extra_jump
        Material.CLOCK,            // power_duration
        Material.BLAZE_POWDER,     // ability_strength
        Material.LEATHER_BOOTS     // fall_resilience
    };

    private static final String[] SKILL_IDS = {
        "dash_upgrade", "extra_jump", "power_duration", "ability_strength", "fall_resilience"
    };

    public static void abrir(Player player, DogApocalypsePlugin plugin) {
        Inventory inv = Bukkit.createInventory(null, 54, TITULO);

        // Bordas
        for (int i = 0; i < 9; i++) {
            inv.setItem(i,      MenuUtils.borda(Material.PURPLE_STAINED_GLASS_PANE));
            inv.setItem(45 + i, MenuUtils.borda(Material.GRAY_STAINED_GLASS_PANE));
        }
        for (int i = 1; i < 6; i++) {
            inv.setItem(i * 9,     MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
            inv.setItem(i * 9 + 8, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        }

        var data = plugin.getPlayerDataManager().get(player);
        boolean ehCao = plugin.getPlayerClassManager().getClass(player) == PlayerClass.DOG;
        int pontos = data.getSkillPoints();

        // Info de pontos
        inv.setItem(4, MenuUtils.itemBrilhante(Material.EXPERIENCE_BOTTLE,
            "&a&lSeus Pontos de Habilidade",
            "&7Disponíveis: &e" + pontos + " pontos",
            "&7Ganhe pontos completando fases.",
            "",
            ehCao ? "&aVocê pode melhorar habilidades!" : "&cApenas o Cão pode usar habilidades."
        ));

        // Linha de habilidades — slots 19, 21, 23, 25, 28 (dois por linha)
        int[] slots = {19, 21, 23, 25, 28};

        for (int i = 0; i < SKILL_IDS.length; i++) {
            String id = SKILL_IDS[i];
            int nivelAtual = data.getSkillLevel(id);
            int maxNivel   = plugin.getSkillTreeManager().getMaxLevel(id);
            int custo      = plugin.getSkillTreeManager().getCost(id);
            String nome    = plugin.getSkillTreeManager().getDisplayName(id);
            String desc    = plugin.getSkillTreeManager().getDescription(id);

            // Barra de progresso visual
            StringBuilder barra = new StringBuilder();
            for (int n = 0; n < maxNivel; n++)
                barra.append(n < nivelAtual ? "§a█" : "§8░");

            boolean maxado  = nivelAtual >= maxNivel;
            boolean podePagar = pontos >= custo;
            boolean podeUsar  = ehCao && !maxado;

            String status;
            if (!ehCao)     status = "&8Apenas a classe Cão";
            else if (maxado) status = "&a★ NÍVEL MÁXIMO";
            else if (podePagar) status = "&eClique para melhorar! (" + custo + " pts)";
            else             status = "&cSem pontos suficientes (" + custo + " necessários)";

            Material icone = maxado ? Material.GOLDEN_APPLE
                           : (podeUsar && podePagar ? Material.LIME_DYE : Material.GRAY_DYE);
            // Override com ícone real da skill se disponível
            if (i < ICONES.length && ehCao) icone = ICONES[i];

            var itemSkill = podeUsar && podePagar
                ? MenuUtils.itemBrilhante(icone, "&f&l" + nome,
                    "&7" + desc,
                    "&7Nível: " + barra,
                    "&7" + nivelAtual + "/" + maxNivel,
                    "", status)
                : MenuUtils.item(icone, (maxado ? "&a✦ " : "&7") + nome,
                    "&7" + desc,
                    "&7Nível: " + barra,
                    "&7" + nivelAtual + "/" + maxNivel,
                    "", status);

            inv.setItem(slots[i], itemSkill);
        }

        // Voltar
        inv.setItem(49, MenuUtils.item(Material.ARROW,
            "&e← Voltar ao Menu Principal",
            "&7Retorna ao menu anterior."
        ));

        player.openInventory(inv);
    }
}
