package com.dogapocalypse.coop;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.*;

/**
 * ReviveSystem v2 — fixed idempotent guard, death task cancel, world check.
 */
public class ReviveSystem {

    private final DogApocalypsePlugin plugin;
    private final Map<UUID, DownedState> downedPlayers  = new HashMap<>();
    private final Map<UUID, Double>      reviveProgress = new HashMap<>();

    private final int    downedDurationSeconds;
    private final int    reviveTimeSeconds;
    private final double reviveRange;

    public ReviveSystem(DogApocalypsePlugin plugin) {
        this.plugin                = plugin;
        this.downedDurationSeconds = plugin.getConfig().getInt("coop.downed_duration_seconds", 15);
        this.reviveTimeSeconds     = plugin.getConfig().getInt("coop.revive_time_seconds", 10);
        this.reviveRange           = plugin.getConfig().getDouble("coop.revive_range_blocks", 3.0);
    }

    public boolean enterDownedState(Player player) {
        if (isDown(player)) return false; // idempotent guard
        player.setHealth(1.0);
        player.setNoDamageTicks(Integer.MAX_VALUE);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW,     Integer.MAX_VALUE, 9, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, Integer.MAX_VALUE, 9, false, false));

        DownedState state = new DownedState(player.getUniqueId());
        downedPlayers.put(player.getUniqueId(), state);

        player.sendTitle(MessageUtil.color("&c&lDOWNED"),
                MessageUtil.color("&7Call for a teammate! (" + downedDurationSeconds + "s)"), 10, 60, 10);

        plugin.getCoopManager().getPartyMembers(player).forEach(m -> {
            if (m.getUniqueId().equals(player.getUniqueId())) return;
            m.sendMessage(MessageUtil.color("&c[!] &f" + player.getName() + " &cis DOWNED!"));
        });

        int taskId = new BukkitRunnable() {
            @Override public void run() {
                if (downedPlayers.containsKey(player.getUniqueId())) killDowned(player);
            }
        }.runTaskLater(plugin, downedDurationSeconds * 20L).getTaskId();
        state.deathTaskId = taskId;

        new BukkitRunnable() {
            @Override public void run() {
                if (!isDown(player) || !player.isOnline()) { cancel(); return; }
                player.getWorld().spawnParticle(Particle.HEART, player.getLocation().add(0, 2.2, 0), 3, 0.3, 0.2, 0.3, 0.01);
            }
        }.runTaskTimer(plugin, 0L, 15L);
        return true;
    }

    public void progressRevive(Player reviver, Player downed) {
        if (!isDown(downed)) return;
        if (!reviver.getWorld().equals(downed.getWorld())) return;
        if (reviver.getLocation().distance(downed.getLocation()) > reviveRange) return;

        UUID downedUUID = downed.getUniqueId();
        double progress  = reviveProgress.getOrDefault(downedUUID, 0.0);
        progress = Math.min(1.0, progress + (1.0 / (reviveTimeSeconds * 10.0)));
        reviveProgress.put(downedUUID, progress);

        int bars = (int)(progress * 20);
        String bar = "&a" + "\u2588".repeat(Math.max(0,bars)) + "&7" + "\u2591".repeat(Math.max(0,20-bars));
        downed.sendActionBar(MessageUtil.color("&f\u2B06 Being revived [" + bar + "&f] " + (int)(progress*100) + "%"));
        reviver.sendActionBar(MessageUtil.color("&6Reviving " + downed.getName() + " [" + bar + "&f]"));

        if (progress >= 1.0) completeRevive(reviver, downed);
    }

    private void completeRevive(Player reviver, Player downed) {
        DownedState state = downedPlayers.remove(downed.getUniqueId());
        if (state == null) return; // already revived guard
        reviveProgress.remove(downed.getUniqueId());
        plugin.getServer().getScheduler().cancelTask(state.deathTaskId);

        downed.removePotionEffect(PotionEffectType.SLOW);
        downed.removePotionEffect(PotionEffectType.WEAKNESS);
        downed.setNoDamageTicks(0);
        downed.setHealth(6.0);
        downed.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 120, 1, false, false));
        downed.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 60, 1, false, false));

        Particle particle;
        try { particle = Particle.valueOf(plugin.getConfig().getString("effects.revive_particle","HEART")); }
        catch (Exception e) { particle = Particle.HEART; }
        downed.getWorld().spawnParticle(particle, downed.getLocation().add(0,1.5,0), 20, 0.5,0.5,0.5, 0.05);
        downed.getWorld().playSound(downed.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);

        downed.sendTitle(MessageUtil.color("&a&lREVIVED!"), MessageUtil.color("&fBy " + reviver.getName()), 5, 40, 10);
        downed.sendMessage(MessageUtil.color("&a[Revived] &fBy &e" + reviver.getName() + "&f!"));
        reviver.sendMessage(MessageUtil.color("&a[Revive] &fRevived &e" + downed.getName() + "&f!"));
    }

    private void killDowned(Player player) {
        downedPlayers.remove(player.getUniqueId());
        reviveProgress.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.SLOW);
        player.removePotionEffect(PotionEffectType.WEAKNESS);
        player.setNoDamageTicks(0);

        var session = plugin.getLevelManager().getSessionByPlayer(player.getUniqueId());
        boolean sozinho = session == null || session.getParticipants().size() <= 1;
        if (!sozinho) {
            boolean todosAbatidos = session.getParticipants().stream()
                .filter(uuid -> !uuid.equals(player.getUniqueId()))
                .map(Bukkit::getPlayer)
                .allMatch(p -> p == null || !p.isOnline() || isDown(p));
            sozinho = todosAbatidos;
        }

        String levelId = plugin.getPlayerDataManager().get(player).getCurrentLevel();
        if (sozinho) {
            player.sendMessage(MessageUtil.color("&c&l[!] &cNinguém te reanimou..."));
            plugin.getGameOverScreen().mostrar(player, levelId != null ? levelId : "level_1");
        } else {
            player.setHealth(0.0);
            player.sendMessage(MessageUtil.color("&c[!] &fNinguém te reanimou. Respawnando no checkpoint..."));
        }
    }

    public void cleanupPlayer(UUID uuid) {
        DownedState state = downedPlayers.remove(uuid);
        if (state != null) plugin.getServer().getScheduler().cancelTask(state.deathTaskId);
        reviveProgress.remove(uuid);
    }

    public boolean isDown(Player player) {
        return player != null && downedPlayers.containsKey(player.getUniqueId());
    }

    public Player findNearbyDowned(Player reviver) {
        for (UUID uuid : downedPlayers.keySet()) {
            Player downed = plugin.getServer().getPlayer(uuid);
            if (downed == null || !downed.isOnline()) continue;
            if (!downed.getWorld().equals(reviver.getWorld())) continue;
            if (downed.getLocation().distance(reviver.getLocation()) <= reviveRange) return downed;
        }
        return null;
    }

    private static class DownedState {
        final UUID uuid;
        int deathTaskId = -1;
        DownedState(UUID uuid) { this.uuid = uuid; }
    }
}
