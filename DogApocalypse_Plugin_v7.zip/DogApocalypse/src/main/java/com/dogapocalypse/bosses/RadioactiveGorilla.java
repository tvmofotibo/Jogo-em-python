package com.dogapocalypse.bosses;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Radioactive Gorilla — 2-phase boss.
 *
 * Phase 1 (100% → 50%): Ground pound, charge, toxic spit.
 * Phase 2 (50% → 0%):   Berserker mode, rapid charge spam, toxic cloud.
 */
public class RadioactiveGorilla extends AbstractBoss {

    private BossBar bossBar;
    private final List<Player> arenaPlayers = new ArrayList<>();
    private int attackCooldown = 0;

    public RadioactiveGorilla(DogApocalypsePlugin plugin) {
        super(plugin, "radioactive_gorilla", "&2Radioactive Gorilla");
        this.maxHealth = plugin.getConfig().getDouble("bosses.radioactive_gorilla.health", 350.0);
        this.phaseThresholds = Collections.singletonList(0.5);
    }

    @Override
    public LivingEntity spawn(Location location) {
        // Use Iron Golem as the golem-like large humanoid creature
        IronGolem golem = (IronGolem) location.getWorld().spawnEntity(location, EntityType.IRON_GOLEM);
        golem.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        golem.setCustomNameVisible(true);

        var health = golem.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (health != null) { health.setBaseValue(maxHealth); golem.setHealth(maxHealth); }

        // Green tint — radiation
        golem.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));

        this.entity = golem;
        this.isActive = true;

        bossBar = plugin.getServer().createBossBar(
                MessageUtil.color(displayName),
                BarColor.GREEN, BarStyle.SOLID);
        bossBar.setVisible(true);

        for (Player p : location.getWorld().getPlayers()) {
            if (p.getLocation().distance(location) <= 40) {
                arenaPlayers.add(p);
                bossBar.addPlayer(p);
                p.sendMessage(MessageUtil.color("&2&l☢ RADIOACTIVE GORILLA EMERGES! ☢"));
                p.sendTitle(MessageUtil.color("&2&lRADIOACTIVE GORILLA"),
                        MessageUtil.color("&aThe irradiated beast attacks!"), 10, 60, 20);
            }
        }

        EffectUtil.spawnParticleCircle(location, Particle.VILLAGER_ANGRY, 30, 5.0);
        location.getWorld().playSound(location, Sound.ENTITY_IRON_GOLEM_HURT, 3f, 0.5f);

        return golem;
    }

    @Override
    public void tick() {
        if (!isAlive()) return;
        tickCounter++;
        checkPhaseTransition();
        updateBossBar();

        attackCooldown++;
        int interval = (currentPhase == 0) ? 50 : 25;
        if (attackCooldown >= interval) {
            executePhaseAttack();
            attackCooldown = 0;
        }

        // Passive: radiate poison cloud
        if (tickCounter % 40 == 0) {
            Location loc = getLocation();
            loc.getWorld().spawnParticle(Particle.SPELL_MOB, loc.add(0, 1, 0), 15, 1.5, 1.5, 1.5, 0,
                    Color.fromRGB(0, 200, 0));
            entity.getWorld().getNearbyEntities(loc, 4, 3, 4).forEach(e -> {
                if (e instanceof Player p) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0, false, true));
                }
            });
        }
    }

    @Override
    public void transitionToPhase(int newPhase) {
        for (Player p : arenaPlayers) {
            if (p.isOnline()) {
                p.sendMessage(MessageUtil.color("&2&l[BERSERKER MODE] &aThe Gorilla has gone berserk!"));
                p.sendTitle(MessageUtil.color("&2BERSERKER"), MessageUtil.color("&aRun!"), 5, 40, 10);
            }
        }
        entity.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 2));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));
        bossBar.setColor(BarColor.RED);

        // Visual rage burst
        Location loc = getLocation();
        loc.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, loc.add(0, 2, 0), 10, 1.0, 1.0, 1.0, 0);
        loc.getWorld().playSound(loc, Sound.ENTITY_RAVAGER_ROAR, 2f, 0.7f);
    }

    @Override
    public void executePhaseAttack() {
        if (!isAlive()) return;
        Location loc = getLocation();
        Player target = getNearestPlayer(loc, 25);
        if (target == null) return;

        if (currentPhase == 0) {
            // Alternate: charge / ground pound
            if (tickCounter % 2 == 0) {
                performCharge(loc, target);
            } else {
                performGroundPound(loc);
            }
        } else {
            // Berserker: rapid charge spam
            performCharge(loc, target);
            if (tickCounter % 3 == 0) performToxicSpit(loc, target);
        }
    }

    private void performCharge(Location from, Player target) {
        Vector dir = target.getLocation().subtract(from).toVector().normalize().multiply(3.0);
        entity.setVelocity(dir);
        from.getWorld().spawnParticle(Particle.CRIT, from.add(0,1,0), 20, 0.5, 0.5, 0.5, 0.2);
        from.getWorld().playSound(from, Sound.ENTITY_RAVAGER_STEP, 1f, 1f);
    }

    private void performGroundPound(Location loc) {
        loc.getWorld().spawnParticle(Particle.EXPLOSION_LARGE, loc, 5, 1.0, 0.1, 1.0, 0);
        loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.6f);

        loc.getWorld().getNearbyEntities(loc, 6, 3, 6).forEach(e -> {
            if (e instanceof Player p) {
                Vector kb = p.getLocation().subtract(loc).toVector().setY(0.8).normalize().multiply(2.0);
                p.setVelocity(kb);
                p.damage(7.0, entity);
            }
        });
    }

    private void performToxicSpit(Location from, Player target) {
        Vector dir = target.getLocation().add(0, 1, 0).subtract(from.clone().add(0, 2, 0))
                          .toVector().normalize().multiply(1.5);
        // Spawn a hurtful snowball as "toxic ball"
        Snowball ball = entity.getWorld().spawn(from.clone().add(0, 2, 0), Snowball.class);
        ball.setVelocity(dir);
        ball.setShooter(entity);
        from.getWorld().playSound(from, Sound.ENTITY_LLAMA_SPIT, 1f, 0.7f);
    }

    @Override
    public void onDeath(List<Player> participants) {
        Location loc = getLocation();
        if (loc != null) {
            loc.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, loc.add(0, 2, 0), 10, 1.0, 1.0, 1.0, 0);
            loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_DEATH, 2f, 0.7f);
        }

        if (bossBar != null) { bossBar.removeAll(); bossBar.setVisible(false); }

        for (Player p : participants) {
            if (!p.isOnline()) continue;
            p.sendMessage(MessageUtil.color("&2&l★ RADIOACTIVE GORILLA DEFEATED! ★"));
            p.sendTitle(MessageUtil.color("&2VICTORY"), MessageUtil.color("&aThe beast is slain!"), 10, 80, 20);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
            plugin.getPlayerDataManager().get(p).addExperience(300);
            plugin.getPlayerDataManager().get(p).addSkillPoints(3);
        }

        isActive = false;
    }

    private Player getNearestPlayer(Location from, double maxDist) {
        Player nearest = null;
        double minDist = maxDist;
        for (Player p : arenaPlayers) {
            if (!p.isOnline() || p.isDead()) continue;
            double d = p.getLocation().distance(from);
            if (d < minDist) { minDist = d; nearest = p; }
        }
        return nearest;
    }

    private void updateBossBar() {
        if (bossBar == null || !isAlive()) return;
        bossBar.setProgress(Math.max(0, Math.min(1, getHealthPercent())));
    }
}
