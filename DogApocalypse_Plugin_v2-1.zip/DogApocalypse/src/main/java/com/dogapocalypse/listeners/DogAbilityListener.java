package com.dogapocalypse.listeners;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * DogAbilityListener v2
 *
 * BUG FIXES:
 *  - Flight toggle no longer fires in creative/spectator
 *  - usedDoubleJump cleared on land AND when class changes
 *  - Dash no longer applies if player is downed
 *  - Fall damage handler checks GameMode to skip creative
 *  - Right-click on blocks no longer triggers dash when interacting with inventories
 */
public class DogAbilityListener implements Listener {

    private final DogApocalypsePlugin plugin;
    private final Set<UUID>           usedDoubleJump = new HashSet<>();
    private final Set<UUID>           usedTripleJump = new HashSet<>();
    private final Map<UUID, Long>     dashCooldown   = new HashMap<>();

    public DogAbilityListener(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // Double / Triple Jump via flight toggle
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        // BUG FIX: skip non-survival modes
        if (player.getGameMode() != GameMode.SURVIVAL) return;
        if (!plugin.getPlayerClassManager().isDog(player)) return;

        event.setCancelled(true);

        UUID uuid = player.getUniqueId();
        boolean usedDouble = usedDoubleJump.contains(uuid);
        boolean usedTriple = usedTripleJump.contains(uuid);
        int extraJumpLevel = plugin.getPlayerDataManager().get(player).getSkillLevel("extra_jump");

        if (!usedDouble) {
            performExtraJump(player, false);
            usedDoubleJump.add(uuid);
        } else if (extraJumpLevel >= 1 && !usedTriple) {
            performExtraJump(player, true);
            usedTripleJump.add(uuid);
        }

        // Re-enable so next press is detected
        player.setAllowFlight(true);
        player.setFlying(false);
    }

    private void performExtraJump(Player player, boolean isTriple) {
        double jumpVelocity = plugin.getConfig().getDouble("classes.dog.double_jump_velocity", 0.65);
        if (isTriple) jumpVelocity *= 0.75;

        Vector vel = player.getVelocity();
        vel.setY(jumpVelocity);
        player.setVelocity(vel);

        Particle p = isTriple ? Particle.CLOUD : Particle.ENCHANTED_HIT;
        player.getWorld().spawnParticle(p, player.getLocation(), 15, 0.3, 0.2, 0.3, 0.05);
        player.playSound(player.getLocation(), Sound.ENTITY_RABBIT_JUMP, 0.7f, isTriple ? 1.6f : 1.3f);
        player.sendActionBar(MessageUtil.color(isTriple ? "&b✦ Triple Jump!" : "&6✦ Double Jump!"));
    }

    // ---------------------------------------------------------------
    // Reset jump on landing
    // ---------------------------------------------------------------

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getPlayerClassManager().isDog(player)) return;
        if (player.getGameMode() != GameMode.SURVIVAL) return;

        if (player.isOnGround()) {
            UUID uuid = player.getUniqueId();
            usedDoubleJump.remove(uuid);
            usedTripleJump.remove(uuid);
            // Ensure flight re-enabled on land
            if (!player.getAllowFlight()) {
                player.setAllowFlight(true);
                player.setFlying(false);
            }
        }
    }

    // ---------------------------------------------------------------
    // Fall damage reduction
    // ---------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        // BUG FIX: skip creative
        if (player.getGameMode() != GameMode.SURVIVAL) return;
        if (!plugin.getPlayerClassManager().isDog(player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;

        double multiplier = plugin.getConfig().getDouble("classes.dog.fall_damage_multiplier", 0.3);
        int ironPawsLevel = plugin.getPlayerDataManager().get(player).getSkillLevel("fall_resilience");
        double reduction  = plugin.getConfig().getDouble(
                "skill_tree.fall_resilience.reduction_per_level", 0.15) * ironPawsLevel;

        double finalMultiplier = Math.max(0.0, multiplier - reduction);
        event.setDamage(event.getDamage() * finalMultiplier);

        if (event.getDamage() <= 0) event.setCancelled(true);

        player.getWorld().spawnParticle(Particle.BLOCK_CRUMBLE,
                player.getLocation(), 10, 0.3, 0, 0.3, 0.05,
                Material.DIRT.createBlockData());
    }

    // ---------------------------------------------------------------
    // Dash (BONE) and Power Activate (TOTEM)
    // ---------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getPlayerClassManager().isDog(player)) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        // BUG FIX: skip if clicking container/inventory blocks
        if (action == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null) {
            Material type = event.getClickedBlock().getType();
            if (type == Material.CHEST || type == Material.CRAFTING_TABLE
                    || type == Material.FURNACE || type == Material.LECTERN
                    || type == Material.BARREL  || type == Material.ANVIL) return;
        }

        // BUG FIX: skip if downed
        if (plugin.getReviveSystem().isDown(player)) return;

        var item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR) return;

        switch (item.getType()) {
            case BONE            -> { event.setCancelled(true); attemptDash(player); }
            case TOTEM_OF_UNDYING -> { event.setCancelled(true); plugin.getDogPowerManager().triggerAbility(player); }
        }
    }

    private void attemptDash(Player player) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long expiry = dashCooldown.get(uuid);

        int skillLevel  = plugin.getPlayerDataManager().get(player).getSkillLevel("dash_upgrade");
        int baseCdTicks = plugin.getConfig().getInt("classes.dog.dash_cooldown_ticks", 60);
        int cdReduction = skillLevel * plugin.getConfig().getInt(
                "skill_tree.dash_upgrade.cooldown_reduction_per_level", 10);
        int finalCdTicks = Math.max(10, baseCdTicks - cdReduction);
        long finalCdMs   = finalCdTicks * 50L;

        if (expiry != null && now < expiry) {
            long remainTicks = (expiry - now) / 50;
            player.sendActionBar(MessageUtil.color(
                    "&c⚡ Dash: &f" + String.format("%.1f", remainTicks / 20.0) + "s"));
            return;
        }

        double baseVel  = plugin.getConfig().getDouble("classes.dog.dash_velocity", 1.4);
        double velBonus = skillLevel * plugin.getConfig().getDouble(
                "skill_tree.dash_upgrade.velocity_bonus_per_level", 0.2);
        double dashVel  = baseVel + velBonus;

        // Horizontal dash direction from look, ignoring Y
        Vector dir = player.getEyeLocation().getDirection().setY(0).normalize().multiply(dashVel);
        // BUG FIX: preserve some Y velocity so player doesn't clip into floor during dash
        dir.setY(player.getVelocity().getY());
        player.setVelocity(dir);

        // Trail particles
        String particleName = plugin.getConfig().getString("effects.dog_dash_particle", "DRAGON_BREATH");
        Particle particle;
        try { particle = Particle.valueOf(particleName); }
        catch (Exception e) { particle = Particle.DRAGON_BREATH; }

        Particle finalParticle = particle;
        new BukkitRunnable() {
            int i = 0;
            @Override public void run() {
                if (!player.isOnline() || i++ >= 6) { cancel(); return; }
                player.getWorld().spawnParticle(finalParticle,
                        player.getLocation().add(0, 0.5, 0), 5, 0.2, 0.1, 0.2, 0.02);
            }
        }.runTaskTimer(plugin, 0L, 1L);

        player.playSound(player.getLocation(), Sound.ENTITY_PHANTOM_SWOOP, 0.8f, 1.6f);
        player.sendActionBar(MessageUtil.color("&b⚡ Dash!"));
        dashCooldown.put(uuid, now + finalCdMs);
    }

    // ---------------------------------------------------------------
    // Cleanup when player leaves / changes class
    // ---------------------------------------------------------------

    public void cleanupPlayer(UUID uuid) {
        usedDoubleJump.remove(uuid);
        usedTripleJump.remove(uuid);
        dashCooldown.remove(uuid);
    }
}
