package com.dogapocalypse.story;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * DialogueManager — handles NPC dialogue, story fragments, and narrative events.
 *
 * Story fragments are unlocked as players progress through levels and defeat bosses.
 * Dialogue is displayed as a typewriter-effect chat sequence.
 */
public class DialogueManager {

    private final DogApocalypsePlugin plugin;

    /** Pre-defined story fragments */
    private final List<StoryFragment> fragments = new ArrayList<>();

    /** Players currently in dialogue (to prevent spamming) */
    private final Set<UUID> inDialogue = new HashSet<>();

    public DialogueManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        loadStoryFragments();
    }

    // ----------------------------------------------------------------
    // Story Fragments
    // ----------------------------------------------------------------

    private void loadStoryFragments() {
        fragments.add(new StoryFragment(0,
                "&d[Fragment 1]",
                new String[]{
                    "&7A young girl lies unconscious in the ruins...",
                    "&7The world around her is unrecognizable.",
                    "&7Mutated creatures roam the streets.",
                    "&7She has lost all her memories.",
                    "&6A dog — equally mutated, equally lost — finds her."
                }));

        fragments.add(new StoryFragment(1,
                "&d[Fragment 2]",
                new String[]{
                    "&7The dog circles the girl, protective and wary.",
                    "&7Something in its mutated mind recognizes her.",
                    "&7A bond forms beyond reason.",
                    "&cWhatever made us this way... it will pay."
                }));

        fragments.add(new StoryFragment(2,
                "&d[Fragment 3]",
                new String[]{
                    "&7Flashes: a laboratory, screaming, white coats.",
                    "&7A machine that mutates living things.",
                    "&7An accident — or was it intentional?"
                }));

        fragments.add(new StoryFragment(3,
                "&d[Fragment 4]",
                new String[]{
                    "&7The girl begins to remember fragments of a name.",
                    "&7&oAva... my name is Ava.",
                    "&7The dog nudges her hand gently.",
                    "&6She names it Rex."
                }));

        fragments.add(new StoryFragment(4,
                "&d[Fragment 5]",
                new String[]{
                    "&7The city they called home is now a wasteland.",
                    "&7War machines patrol the ruins.",
                    "&7The gorillas from the lab roam free.",
                    "&cSomeone unleashed all of this."
                }));

        fragments.add(new StoryFragment(5,
                "&d[Fragment 6]",
                new String[]{
                    "&7A survivor tells Ava about Project APEX.",
                    "&7A government program. Mutation as a weapon.",
                    "&7Rex was their prototype.",
                    "&6And Ava... Ava was the scientist who created it."
                }));

        fragments.add(new StoryFragment(6,
                "&d[Fragment 7]",
                new String[]{
                    "&7The accident wasn't an accident.",
                    "&7Ava destroyed the lab herself.",
                    "&7To stop them from weaponizing Rex.",
                    "&7She paid the price with her memories."
                }));

        fragments.add(new StoryFragment(7,
                "&d[Fragment 8]",
                new String[]{
                    "&7Rex's mutations aren't random.",
                    "&7He absorbs the essence of other mutants.",
                    "&7Because Ava designed him that way.",
                    "&6He was always meant to be the cure."
                }));

        fragments.add(new StoryFragment(8,
                "&d[Fragment 9]",
                new String[]{
                    "&7Deep in the war ruins lies the last machine.",
                    "&7If it activates, mutation spreads worldwide.",
                    "&cSomeone is rebuilding Project APEX."
                }));

        fragments.add(new StoryFragment(9,
                "&d[Fragment 10]",
                new String[]{
                    "&7The Dragon... it was the general.",
                    "&7The man who funded the project.",
                    "&7Mutated himself to survive the apocalypse.",
                    "&6Rex. It's time."
                }));

        fragments.add(new StoryFragment(10,
                "&d[Fragment 11]",
                new String[]{
                    "&7Ava remembers everything now.",
                    "&7The formula. The cure. The way to end this.",
                    "&7But the machine must be destroyed first.",
                    "&cAnd the Dragon must fall."
                }));

        fragments.add(new StoryFragment(11,
                "&d[Fragment 12 — The End]",
                new String[]{
                    "&7With the Dragon defeated, the machine goes dark.",
                    "&7Rex absorbs the last of the mutation energy.",
                    "&7Slowly... the world begins to heal.",
                    "&6Ava looks at Rex, tears in her eyes.",
                    "&f&o\"You were never just a dog. You were hope.\"",
                    "&8                — FIN —"
                }));
    }

    // ----------------------------------------------------------------
    // Unlock Fragment
    // ----------------------------------------------------------------

    /**
     * Unlocks the next story fragment for a player if they haven't seen it.
     */
    public void unlockNextFragment(Player player) {
        var data = plugin.getPlayerDataManager().get(player);
        int current = data.getStoryFragments();

        if (current >= fragments.size()) return; // all seen

        StoryFragment fragment = fragments.get(current);
        data.addStoryFragment();

        String unlockMsg = plugin.getConfig().getString("story.unlock_message",
                "&d[Story] &fYou found a memory fragment...");
        player.sendMessage(MessageUtil.color(unlockMsg));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HARP, 0.7f, 1.8f);

        // Delay and show dialogue
        new BukkitRunnable() {
            @Override
            public void run() {
                playDialogue(player, fragment.title, fragment.lines);
            }
        }.runTaskLater(plugin, 20L);
    }

    /**
     * Shows a specific fragment by index to a player.
     */
    public void showFragment(Player player, int index) {
        if (index < 0 || index >= fragments.size()) {
            player.sendMessage(MessageUtil.color("&cFragment not found."));
            return;
        }
        StoryFragment f = fragments.get(index);
        playDialogue(player, f.title, f.lines);
    }

    // ----------------------------------------------------------------
    // Dialogue Display
    // ----------------------------------------------------------------

    /**
     * Displays lines as a typewriter-style chat sequence with delays.
     */
    public void playDialogue(Player player, String title, String[] lines) {
        UUID uuid = player.getUniqueId();
        inDialogue.add(uuid);

        player.sendMessage(MessageUtil.color(""));
        player.sendMessage(MessageUtil.color("&8&m==========&r " + title + " &8&m=========="));

        new BukkitRunnable() {
            int index = 0;
            @Override
            public void run() {
                if (index >= lines.length || !player.isOnline()) {
                    player.sendMessage(MessageUtil.color("&8&m====================================="));
                    inDialogue.remove(uuid);
                    cancel();
                    return;
                }
                player.sendMessage(MessageUtil.color(lines[index]));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.3f, 1.2f);
                index++;
            }
        }.runTaskTimer(plugin, 10L, 25L);
    }

    // ----------------------------------------------------------------
    // NPC Interaction
    // ----------------------------------------------------------------

    /**
     * Triggers an NPC conversation. NPCId is a simple string key for scripted events.
     */
    public void triggerNPCDialogue(Player player, String npcId) {
        String[] lines = switch (npcId.toLowerCase()) {
            case "survivor_1" -> new String[]{
                "&7&oStranger... you're not one of them.",
                "&7&oThe mutant dog... I've heard of it.",
                "&7&oThey say it was the key to stopping all this.",
                "&eTalk to the dog. Find the ruins. Go north."
            };
            case "scientist_ghost" -> new String[]{
                "&5&o[Memory Echo] \" ...the formula is inside Rex.\"",
                "&5&o\" We designed him to carry the cure.\"",
                "&5&o\" But first, the machine must burn.\""
            };
            case "final_gate" -> new String[]{
                "&cBEYOND THIS POINT: THE DRAGON'S LAIR",
                "&7You stand at the entrance to the end.",
                "&7Rex growls. Ava grips her weapon.",
                "&6Are you ready?"
            };
            default -> new String[]{ "&7..." };
        };

        playDialogue(player, "&7NPC", lines);
    }

    public boolean isInDialogue(Player player) {
        return inDialogue.contains(player.getUniqueId());
    }

    // ----------------------------------------------------------------
    // Inner classes
    // ----------------------------------------------------------------

    private static class StoryFragment {
        final int index;
        final String title;
        final String[] lines;

        StoryFragment(int index, String title, String[] lines) {
            this.index = index;
            this.title = title;
            this.lines = lines;
        }
    }
}
