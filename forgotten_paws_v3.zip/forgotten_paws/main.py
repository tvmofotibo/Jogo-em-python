"""
FORGOTTEN PAWS  —  Post-Apocalyptic 2D Platformer
Pygame + Pygbag (WebAssembly)

FIX LOG:
  • All drawing uses INTEGER coords  →  no sub-pixel ghost/shimmer artefacts
  • Camera snapped to int each frame →  background no longer shimmers
  • SRCALPHA overlay surfaces created ONCE, not per-frame
  • Particle system draws solid circles with colour fade, no per-pixel alpha Surface
  • Platform collision rewritten (axis-separated)  →  no tunnelling
  • Touch system: MOUSEBUTTONUP resets ALL buttons (reliable on mobile)
  • Player.update() receives pygame.key.get_pressed() directly for P2-P5

NEW FEATURES:
  • KIRA locked in a PRISON at start of Level 1; players must attack bars 3x to free her
  • When freed, KIRA joins as an extra playable character (slot auto-assigned)
  • MAGO (Wizard) added as 4th selectable character with Arcane Nova special
  • 5 characters total: REX · VALE · ZAP · MAGO  (+KIRA after rescue)
  • SKELETON enemy type added
"""

import asyncio, math, random, sys
import pygame

pygame.init()

W, H = 960, 540
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("FORGOTTEN PAWS")
clock  = pygame.time.Clock()
FPS    = 60
GRAVITY = 0.55

WHITE  = (255,255,255); BLACK  = (  0,  0,  0)
RED    = (210, 30, 30); GREEN  = ( 50,200, 50)
BLUE   = ( 50,100,220); YELLOW = (230,200, 40)
PURPLE = (160, 60,220); ORANGE = (220,120, 30)
CYAN   = ( 40,200,200); GREY   = (100,100,120)
GOLD   = (220,180, 30); PINK   = (220, 80,160)

def _fnt(nm,sz,bold=False):
    try:    return pygame.font.SysFont(nm,sz,bold=bold)
    except: return pygame.font.Font(None,sz)

F_BIG  = _fnt("monospace",48,True)
F_MED  = _fnt("monospace",22,True)
F_SM   = _fnt("monospace",14)
F_TINY = _fnt("monospace",11)

def draw_text(surf,txt,font,col,cx,cy,anchor="center"):
    s=font.render(str(txt),True,col); r=s.get_rect()
    setattr(r,anchor,(cx,cy)); surf.blit(s,r)

def lerp(a,b,t): return a+(b-a)*t

# ─────────────────────────────────────────────────────────────────────────────
# PARTICLE SYSTEM  (integer coords, colour-fade only – no SRCALPHA per frame)
# ─────────────────────────────────────────────────────────────────────────────
class Particle:
    __slots__=("x","y","vx","vy","r","g","b","life","ml","sz")
    def __init__(self,x,y,vx,vy,col,life,sz=3):
        self.x,self.y=float(x),float(y); self.vx,self.vy=float(vx),float(vy)
        self.r,self.g,self.b=col; self.life=life; self.ml=life; self.sz=sz
    def update(self):
        self.x+=self.vx; self.y+=self.vy; self.vy+=0.2; self.vx*=0.92; self.life-=1
    def draw(self,surf,cx):
        if self.life<=0: return
        a=self.life/self.ml; rad=max(1,int(self.sz*a))
        sx,sy=int(self.x-cx),int(self.y)
        if -rad<sx<W+rad and -rad<sy<H+rad:
            pygame.draw.circle(surf,(int(self.r*a),int(self.g*a),int(self.b*a)),(sx,sy),rad)

class PS:
    def __init__(self): self.p=[]
    def emit(self,x,y,vx,vy,col,life,sz=3): self.p.append(Particle(x,y,vx,vy,col,life,sz))
    def burst(self,x,y,col,n=10,spd=4,sz=3):
        for _ in range(n):
            a=random.uniform(0,math.tau); s=random.uniform(spd*.4,spd)
            self.emit(x,y,math.cos(a)*s,math.sin(a)*s,col,random.randint(20,40),sz)
    def blood(self,x,y):  self.burst(x,y,(180,20,20),12,5,3)
    def spark(self,x,y):  self.burst(x,y,YELLOW,8,6,2)
    def magic(self,x,y,col=PURPLE): self.burst(x,y,col,14,4,3)
    def absorb(self,x,y):
        for _ in range(20):
            a=random.uniform(0,math.tau); r=random.uniform(20,60)
            ox,oy=x+math.cos(a)*r,y+math.sin(a)*r
            self.emit(ox,oy,-math.cos(a)*2.5,-math.sin(a)*2.5,GREEN,40,4)
    def update(self):
        live=[]
        for p in self.p:
            p.update()
            if p.life>0: live.append(p)
        self.p=live
    def draw(self,surf,cx):
        for p in self.p: p.draw(surf,cx)

ps=PS()

# floating damage / info texts
class FT:
    def __init__(self,x,y,txt,col,life=55):
        self.x,self.y=float(x),float(y); self.txt,self.col=txt,col; self.life=self.ml=life
    def update(self): self.y-=0.9; self.life-=1
    def draw(self,surf,cx):
        a=max(0,self.life/self.ml)
        s=F_SM.render(self.txt,True,tuple(int(c*a) for c in self.col))
        surf.blit(s,(int(self.x-cx-s.get_width()//2),int(self.y)))

floats=[]
def add_float(x,y,txt,col=WHITE): floats.append(FT(x,y,txt,col))

# ─────────────────────────────────────────────────────────────────────────────
# MOBILE / TOUCH CONTROLS
# ─────────────────────────────────────────────────────────────────────────────
class TBtn:
    def __init__(self,lbl,cx,cy,r,col,act):
        self.lbl,self.cx,self.cy,self.r,self.col,self.act=lbl,cx,cy,r,col,act
        self.pressed=False
    def hit(self,x,y): return math.hypot(x-self.cx,y-self.cy)<=self.r*1.4
    def draw(self,surf):
        c=tuple(min(255,v+50) for v in self.col) if self.pressed else self.col
        pygame.draw.circle(surf,BLACK,(self.cx+3,self.cy+3),self.r)
        pygame.draw.circle(surf,c,(self.cx,self.cy),self.r)
        pygame.draw.circle(surf,WHITE,(self.cx,self.cy),self.r,2)
        s=F_TINY.render(self.lbl,True,WHITE)
        surf.blit(s,(self.cx-s.get_width()//2,self.cy-s.get_height()//2))

ACTS=("left","right","up","down","attack","ranged","special")

class Mobile:
    def __init__(self):
        self.state={a:False for a in ACTS}
        R=32; lx,ly=88,H-90; rx,ry=W-90,H-90
        self.btns=[
            TBtn("◀",lx-R-6,ly,    R,(70,70,90),  "left"),
            TBtn("▶",lx+R+6,ly,    R,(70,70,90),  "right"),
            TBtn("▼",lx,    ly+R+6,R,(70,70,70),  "down"),
            TBtn("▲",lx,    ly-R-6,R,(70,90,70),  "up"),
            TBtn("ATK",rx,        ry,     R,(160,40,40),"attack"),
            TBtn("TIR",rx-R*2-6, ry,     R,(40,40,160),"ranged"),
            TBtn("ESP",rx-R-3,   ry-R*2-6,R,(120,40,140),"special"),
            TBtn("⬆", rx-R*2-6, ry-R*2-6,R,(40,130,60),"up"),
        ]
    def handle(self,ev):
        if ev.type==pygame.MOUSEBUTTONDOWN:
            x,y=ev.pos
            for b in self.btns:
                if b.hit(x,y): b.pressed=True; self.state[b.act]=True
        elif ev.type==pygame.MOUSEBUTTONUP:
            for b in self.btns: b.pressed=False
            self.state={a:False for a in ACTS}
        elif ev.type==pygame.MOUSEMOTION and ev.buttons[0]:
            x,y=ev.pos
            for b in self.btns:
                b.pressed=b.hit(x,y); self.state[b.act]=b.pressed
    def draw(self,surf):
        for b in self.btns: b.draw(surf)

mobile=Mobile()

# Merged keyboard + mobile for P1 slot
class MK:
    MAP={pygame.K_a:"left",pygame.K_d:"right",pygame.K_w:"up",
         pygame.K_s:"down",pygame.K_z:"attack",pygame.K_x:"ranged",pygame.K_c:"special"}
    def __init__(self): self._kb=None
    def refresh(self):  self._kb=pygame.key.get_pressed()
    def __getitem__(self,k):
        kb=self._kb[k] if self._kb else False
        mob=mobile.state.get(self.MAP.get(k,""),False)
        return kb or mob

mk=MK()

# ─────────────────────────────────────────────────────────────────────────────
# TAP ZONES (menu buttons)
# ─────────────────────────────────────────────────────────────────────────────
tap_zones={}

def tap_btn(surf,name,lbl,cx,cy,bw,bh,col,font=None):
    if font is None: font=F_MED
    r=pygame.Rect(cx-bw//2,cy-bh//2,bw,bh)
    tap_zones[name]=r
    pygame.draw.rect(surf,tuple(max(0,c-50) for c in col),r.move(3,3))
    pygame.draw.rect(surf,col,r)
    pygame.draw.rect(surf,WHITE,r,2)
    s=font.render(lbl,True,WHITE)
    surf.blit(s,(cx-s.get_width()//2,cy-s.get_height()//2))

# ─────────────────────────────────────────────────────────────────────────────
# POWERS (Rex)
# ─────────────────────────────────────────────────────────────────────────────
POWERS={"none":{"name":"—","col":GREEN},"fire":{"name":"FOGO","col":(255,80,10)},
        "climb":{"name":"ESCALAR","col":(139,69,19)},"swim":{"name":"NADAR","col":BLUE},
        "electric":{"name":"ELÉTR","col":YELLOW}}
EPWR={"rat":"none","insect":"electric","monkey":"climb","robot":"electric",
      "dragon":"fire","skeleton":"none"}

# ─────────────────────────────────────────────────────────────────────────────
# CHARACTER DEFINITIONS  id,name,col,spd,jmp,hp,mp,ctrl_set
# ─────────────────────────────────────────────────────────────────────────────
CDEFS=[
    (0,"REX",  GREEN, 4.5,15.0, 90,120,1),
    (1,"VALE", ORANGE,3.8,14.0, 85,100,2),
    (2,"ZAP",  CYAN,  3.2,13.0,120, 60,3),
    (3,"MAGO", PURPLE,3.0,13.5, 80,150,4),
    (4,"KIRA", PINK,  4.2,13.5,100, 80,0),
]
CTRL=[
    [pygame.K_a,   pygame.K_d,   pygame.K_w,  pygame.K_s,  pygame.K_z,pygame.K_x,pygame.K_c],
    [pygame.K_LEFT,pygame.K_RIGHT,pygame.K_UP,pygame.K_DOWN,pygame.K_u,pygame.K_i,pygame.K_o],
    [pygame.K_j,   pygame.K_l,   pygame.K_i,  pygame.K_k,  pygame.K_n,pygame.K_m,pygame.K_COMMA],
    [pygame.K_KP4, pygame.K_KP6, pygame.K_KP8,pygame.K_KP5,pygame.K_KP7,pygame.K_KP9,pygame.K_KP1],
    [pygame.K_F1,  pygame.K_F3,  pygame.K_F2, pygame.K_F4, pygame.K_F5,pygame.K_F6,pygame.K_F7],
]

# ─────────────────────────────────────────────────────────────────────────────
# PLATFORM
# ─────────────────────────────────────────────────────────────────────────────
class Platform:
    def __init__(self,x,y,w,h,col1=(28,28,46),col2=(16,16,28)):
        self.x,self.y,self.w,self.h=x,y,w,h; self.col1,self.col2=col1,col2
    def rect(self): return pygame.Rect(self.x,self.y,self.w,self.h)
    def draw(self,surf,cx):
        sx=self.x-cx
        if sx+self.w<-4 or sx>W+4: return
        r=pygame.Rect(int(sx),self.y,self.w,self.h)
        pygame.draw.rect(surf,self.col1,r); pygame.draw.rect(surf,self.col2,r,1)
        pygame.draw.line(surf,(60,60,88),(int(sx),self.y),(int(sx)+self.w,self.y),2)
        for i in range(0,self.w,80):
            pygame.draw.line(surf,BLACK,(int(sx)+i,self.y),(int(sx)+i+18,self.y+10),1)

class Spike:
    def __init__(self,x,y,n=5): self.x,self.y,self.n=x,y,n; self.w=n*12
    def draw(self,surf,cx):
        sx=int(self.x-cx)
        if sx+self.w<-4 or sx>W+4: return
        for i in range(self.n):
            bx=sx+i*12
            pygame.draw.polygon(surf,(180,30,0),[(bx,self.y+20),(bx+6,self.y),(bx+12,self.y+20)])
    def hurt(self,players):
        for p in players:
            if p.dead or p.invincible>0: continue
            if p.x+p.w>self.x and p.x<self.x+self.w and p.y+p.h>self.y and p.y+p.h<self.y+22:
                p.take_damage(35)

# ─────────────────────────────────────────────────────────────────────────────
# COLLECTIBLE
# ─────────────────────────────────────────────────────────────────────────────
class Collectible:
    def __init__(self,x,y,ct):
        self.x,self.y=float(x),float(y); self.ct=ct; self.done=False
        self.bob=random.uniform(0,math.tau)
    def update(self,players,gs):
        if self.done: return
        for p in players:
            if p.dead: continue
            if abs(p.x-self.x)<28 and abs(p.y-self.y)<28:
                self.done=True; self._apply(p,gs)
    def _apply(self,p,gs):
        if   self.ct=="health":  p.hp=min(p.max_hp,p.hp+32); add_float(self.x,self.y-12,"+32 HP",GREEN); ps.burst(self.x,self.y,GREEN,8,3)
        elif self.ct=="memory":  gs.score+=500; gs.mem_count+=1; add_float(self.x,self.y-12,"✦ MEMÓRIA",PURPLE); ps.magic(self.x,self.y); gs.trigger_mem=(gs.mem_count==2)
        elif self.ct=="powerup": p.mp=p.max_mp; add_float(self.x,self.y-12,"PODER MAX!",YELLOW); ps.burst(self.x,self.y,YELLOW,10,4)
    def draw(self,surf,cx):
        if self.done: return
        sx=int(self.x-cx); bob=int(math.sin(pygame.time.get_ticks()*0.004+self.bob)*6); sy=int(self.y)+bob
        if sx<-30 or sx>W+30: return
        if   self.ct=="health":
            pygame.draw.circle(surf,RED,(sx,sy),10)
            pygame.draw.rect(surf,WHITE,(sx-2,sy-6,4,12)); pygame.draw.rect(surf,WHITE,(sx-6,sy-2,12,4))
        elif self.ct=="memory":
            for i in range(5):
                a=math.tau/5*i-math.pi/2
                pygame.draw.circle(surf,PURPLE,(sx+int(math.cos(a)*10),sy+int(math.sin(a)*10)),3)
            pygame.draw.circle(surf,(200,160,255),(sx,sy),5)
        elif self.ct=="powerup":
            pts=[(sx+int(math.cos(math.tau/10*i-math.pi/2)*(12 if i%2==0 else 6)),
                  sy+int(math.sin(math.tau/10*i-math.pi/2)*(12 if i%2==0 else 6))) for i in range(10)]
            pygame.draw.polygon(surf,YELLOW,pts)

# ─────────────────────────────────────────────────────────────────────────────
# PRISON  (Level 1 — Kira locked inside)
# ─────────────────────────────────────────────────────────────────────────────
class Prison:
    def __init__(self,x,y):
        self.x,self.y=x,y; self.w,self.h=80,120
        self.freed=False; self.hp=3; self.shake=0; self._last_hit=-9999
    def try_break(self,players,gs):
        if self.freed: return True
        if self.shake>0: self.shake-=1
        t=pygame.time.get_ticks()
        for p in players:
            if p.dead: continue
            dist=math.hypot(p.x-(self.x+self.w//2),p.y-(self.y+self.h//2))
            if dist<100 and p.state=="attack" and p.state_t>10 and t-self._last_hit>600:
                self.hp-=1; self.shake=14; self._last_hit=t; p.state_t=0
                ps.spark(self.x+self.w//2,self.y+self.h//2)
                add_float(self.x+self.w//2,self.y-14,f"GRADES {self.hp}/3!",YELLOW)
                if self.hp<=0:
                    self.freed=True
                    ps.burst(self.x+self.w//2,self.y+self.h//2,GOLD,30,8)
                    add_float(self.x+self.w//2,self.y-34,"✦ KIRA LIBERTADA! ✦",GOLD)
                    return True
        return False
    def draw(self,surf,cx):
        if self.freed: return
        off=random.randint(-2,2) if self.shake>0 else 0
        sx=int(self.x-cx)+off; sy=self.y
        pygame.draw.rect(surf,(30,20,10),(sx,sy,self.w,self.h))
        bc=(180,160,80) if self.hp==3 else ((140,100,40) if self.hp==2 else (100,60,20))
        for bx in range(sx+10,sx+self.w-5,18):
            pygame.draw.line(surf,bc,(bx,sy),(bx,sy+self.h),4)
        pygame.draw.line(surf,bc,(sx,sy),(sx+self.w,sy),4)
        pygame.draw.line(surf,bc,(sx,sy+self.h),(sx+self.w,sy+self.h),4)
        # Kira silhouette
        pygame.draw.ellipse(surf,(220,180,220),(sx+28,sy+18,24,20))
        pygame.draw.rect(surf,(220,180,220),(sx+30,sy+36,20,36))
        pygame.draw.line(surf,(80,80,80),(sx+38,sy+50),(sx+10,sy+80),3)
        pygame.draw.line(surf,(80,80,80),(sx+42,sy+50),(sx+70,sy+80),3)
        hint=F_TINY.render("Ataque as grades!",True,GOLD)
        surf.blit(hint,(sx+self.w//2-hint.get_width()//2,sy-17))

# ─────────────────────────────────────────────────────────────────────────────
# PROJECTILE
# ─────────────────────────────────────────────────────────────────────────────
class Proj:
    def __init__(self,x,y,vx,vy,col,dmg,life,ptype,owner=-1):
        self.x,self.y=float(x),float(y); self.vx,self.vy=float(vx),float(vy)
        self.col,self.dmg,self.life=col,dmg,life
        self.ptype,self.owner=ptype,owner; self.w,self.h=10,6; self.dead=False
    def update(self,platforms,players,enemies,gs):
        self.x+=self.vx; self.y+=self.vy; self.vy+=0.06; self.life-=1
        if self.life<=0: self.dead=True; return
        r=pygame.Rect(int(self.x),int(self.y),self.w,self.h)
        for p in platforms:
            if r.colliderect(p.rect()): ps.spark(self.x,self.y); self.dead=True; return
        if self.ptype=="player":
            for e in enemies:
                if e.dead: continue
                if r.colliderect(e.rect()):
                    att=next((p for p in players if p.slot==self.owner),None)
                    e.take_damage(self.dmg,att,gs); ps.spark(self.x,self.y); self.dead=True; return
            if gs.boss and not gs.boss.dead and r.colliderect(gs.boss.rect()):
                gs.boss.take_damage(self.dmg,gs); ps.spark(self.x,self.y); self.dead=True; return
        else:
            for p in players:
                if p.dead or p.invincible>0: continue
                if r.colliderect(p.rect()): p.take_damage(self.dmg); self.dead=True; return
    def draw(self,surf,cx):
        sx=int(self.x-cx)
        if -20<sx<W+20: pygame.draw.ellipse(surf,self.col,(sx,int(self.y),self.w,self.h))

# ─────────────────────────────────────────────────────────────────────────────
# ENEMY
# ─────────────────────────────────────────────────────────────────────────────
EDAT={"rat":(45,22,18,2.2,8,50),"insect":(38,20,16,1.8,12,75),"monkey":(65,26,32,3.0,15,100),
      "robot":(85,28,36,2.0,20,150),"dragon":(130,40,36,2.8,25,200),"skeleton":(55,24,36,2.0,14,120)}
ECOL={"rat":(130,80,40),"insect":(40,110,0),"monkey":(100,55,10),
      "robot":(60,90,120),"dragon":(160,10,10),"skeleton":(200,200,180)}

class Enemy:
    def __init__(self,et,x,y):
        self.et=et; hp,w,h,spd,dmg,sc=EDAT[et]
        self.hp=float(hp); self.mhp=float(hp); self.w,self.h=w,h
        self.spd=spd; self.dmg=dmg; self.sc=sc; self.col=ECOL[et]
        self.x,self.y=float(x),float(y-h); self.vx=self.vy=0.0
        self.on_gnd=False; self.facing=-1; self.dead=False; self.stun=0; self.acd=0
        self.pd=-1; self.pt=0; self.sx=float(x); self.at=self.af=0
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)
    def take_damage(self,dmg,att,gs):
        if self.dead: return
        self.hp-=dmg; self.stun=18; add_float(self.x+self.w//2,self.y-6,f"-{int(dmg)}",RED)
        if self.hp<=0: self._die(att,gs)
    def _die(self,att,gs):
        self.dead=True; ps.burst(self.x+self.w//2,self.y+self.h//2,self.col,12,5); ps.blood(self.x+self.w//2,self.y+self.h//2)
        gs.score+=self.sc
        rex=next((p for p in gs.players if p.is_rex and not p.dead),None)
        if rex and math.hypot(rex.x-self.x,rex.y-self.y)<240: rex.absorb(self.et)
    def update(self,platforms,players,gs):
        if self.dead: return
        if self.stun>0: self.stun-=1; return
        if self.acd>0: self.acd-=1
        self.at+=1
        if self.at>=10: self.at=0; self.af=(self.af+1)%4
        near=None; nd=9999.0
        for p in players:
            if p.dead: continue
            d=math.hypot(p.x-self.x,p.y-self.y)
            if d<nd: nd=d; near=p
        if near and nd<260:
            self.facing=1 if near.x>self.x else -1
            self.vx=self.facing*self.spd
            if self.on_gnd and near.y<self.y-50 and random.random()<0.02: self.vy=-11
            if nd<self.w+16 and self.acd==0: near.take_damage(self.dmg); self.acd=65
            if self.et in("insect","robot","skeleton") and self.acd==0 and 80<nd<280:
                dx=near.x-self.x; dy=near.y-self.y; dd=math.hypot(dx,dy) or 1
                sc=(100,255,80) if self.et=="insect" else (200,200,200)
                gs.projectiles.append(Proj(self.x+self.w//2,self.y+self.h//2,dx/dd*5,dy/dd*5,sc,self.dmg,65,"enemy"))
                self.acd=85
        else:
            self.pt+=1
            if self.pt>90: self.pd*=-1; self.pt=0
            if abs(self.x-self.sx)>140: self.pd=1 if self.sx>self.x else -1
            self.vx=self.pd*self.spd*0.45; self.facing=self.pd
        self.vy+=GRAVITY; self.vy=min(self.vy,15); self.x+=self.vx; self.y+=self.vy; self.vx*=0.85
        self.on_gnd=False; er=self.rect()
        for p in platforms:
            pr=p.rect()
            if er.colliderect(pr) and self.vy>=0 and er.bottom-pr.top<22 and er.top<pr.top:
                self.y=pr.top-self.h; self.vy=0; self.on_gnd=True
    def draw(self,surf,cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-60 or sx>W+60: return
        c=self.col
        if   self.et=="rat":
            pygame.draw.ellipse(surf,c,(sx,sy+2,self.w,self.h-4)); pygame.draw.ellipse(surf,c,(sx+10,sy-4,14,12)); pygame.draw.circle(surf,RED,(sx+18,sy-2),3)
        elif self.et=="insect":
            pygame.draw.ellipse(surf,c,(sx,sy+2,self.w,self.h-4)); pygame.draw.ellipse(surf,c,(sx+12,sy-2,12,10))
            pygame.draw.line(surf,(80,200,0),(sx+8,sy+4),(sx-8,sy+10),2); pygame.draw.line(surf,(80,200,0),(sx+8,sy+4),(sx-6,sy-2),2); pygame.draw.line(surf,(80,200,0),(sx+16,sy+4),(sx+26,sy+10),2)
        elif self.et=="monkey":
            pygame.draw.ellipse(surf,c,(sx+2,sy+8,22,24)); pygame.draw.ellipse(surf,c,(sx+6,sy-6,18,20))
            pygame.draw.ellipse(surf,(180,140,60),(sx+9,sy-3,12,10)); pygame.draw.circle(surf,RED,(sx+14,sy-2),3)
        elif self.et=="robot":
            pygame.draw.rect(surf,c,(sx+2,sy+6,24,30)); pygame.draw.rect(surf,c,(sx+4,sy-4,20,14))
            pygame.draw.circle(surf,CYAN,(sx+9,sy+1),4); pygame.draw.circle(surf,CYAN,(sx+19,sy+1),4)
        elif self.et=="dragon":
            pygame.draw.ellipse(surf,c,(sx,sy+4,40,28)); pygame.draw.ellipse(surf,c,(sx+20,sy-8,22,18))
            pygame.draw.polygon(surf,(100,0,0),[(sx+22,sy-8),(sx+26,sy-18),(sx+30,sy-8)])
            pygame.draw.circle(surf,(255,100,0),(sx+30,sy-2),4)
            pygame.draw.polygon(surf,(80,0,0),[(sx+10,sy+8),(sx-10,sy-10),(sx,sy+20)])
        elif self.et=="skeleton":
            pygame.draw.ellipse(surf,c,(sx+4,sy-6,18,16))
            pygame.draw.rect(surf,c,(sx+8,sy+8,10,18))
            pygame.draw.line(surf,c,(sx+2,sy+12),(sx+24,sy+12),3)
            pygame.draw.line(surf,c,(sx+8,sy+26),(sx+4,sy+38),3); pygame.draw.line(surf,c,(sx+16,sy+26),(sx+20,sy+38),3)
            pygame.draw.circle(surf,BLACK,(sx+10,sy-2),2); pygame.draw.circle(surf,BLACK,(sx+16,sy-2),2)
        bw=self.w; pct=max(0,self.hp/self.mhp)
        pygame.draw.rect(surf,(40,40,40),(sx,sy-8,bw,4))
        pygame.draw.rect(surf,GREEN if pct>0.5 else (YELLOW if pct>0.25 else RED),(sx,sy-8,int(bw*pct),4))

# ─────────────────────────────────────────────────────────────────────────────
# BOSS
# ─────────────────────────────────────────────────────────────────────────────
class Boss:
    def __init__(self,bt,x,y,name):
        self.bt,self.name=bt,name; self.x,self.y=float(x),float(y)
        self.w=90 if bt=="dragon_boss" else 76; self.h=120 if bt=="dragon_boss" else 106
        self.mhp=900 if bt=="dragon_boss" else 700; self.hp=float(self.mhp)
        self.vx=self.vy=0.0; self.on_gnd=False; self.facing=-1
        self.dead=False; self.rage=False; self.acd=0; self.ap=0; self.stun=0; self.af=self.at=0
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)
    def take_damage(self,dmg,gs):
        if self.dead: return
        self.hp-=dmg; add_float(self.x+self.w//2,self.y-14,f"-{int(dmg)}",RED)
        ps.spark(self.x+self.w//2+random.randint(-30,30),self.y+self.h//2)
        if not self.rage and self.hp<self.mhp*0.4:
            self.rage=True; add_float(self.x+self.w//2,self.y-42,"⚡ FASE 2!",RED); ps.burst(self.x+self.w//2,self.y+self.h//2,RED,30,10)
        if self.hp<=0: self._die(gs)
    def _die(self,gs):
        self.dead=True; gs.score+=5000
        for _ in range(6): ps.burst(self.x+self.w//2+random.randint(-50,50),self.y+random.randint(0,60),YELLOW,20,8)
        gs.boss_bar=False; gs.level_cleared=True
    def update(self,platforms,players,gs):
        if self.dead or self.stun>0: self.stun-=1; return
        self.at+=1
        if self.at>=8: self.at=0; self.af=(self.af+1)%4
        alive=[p for p in players if not p.dead]
        if not alive: return
        near=min(alive,key=lambda p:math.hypot(p.x-self.x,p.y-self.y))
        self.facing=1 if near.x>self.x else -1
        self.vx=self.facing*(3.8 if self.rage else 2.6)
        lw=gs.level_width
        if self.x<lw-700: self.vx=abs(self.vx)
        if self.x+self.w>lw-10: self.vx=-abs(self.vx)
        if self.on_gnd and near.y<self.y-70 and random.random()<0.025: self.vy=-15
        self.acd-=1; rate=45 if self.rage else 75
        if self.acd<=0:
            self.acd=rate; self.ap=(self.ap+1)%3; self._atk(near,players,gs)
        self.vy+=GRAVITY; self.vy=min(self.vy,16); self.x+=self.vx; self.y+=self.vy; self.vx*=0.88
        self.on_gnd=False; br=self.rect()
        for p in platforms:
            pr=p.rect()
            if br.colliderect(pr) and self.vy>=0 and br.bottom-pr.top<22 and br.top<pr.top:
                self.y=pr.top-self.h; self.vy=0; self.on_gnd=True
        for pl in players:
            if pl.dead or pl.invincible>0: continue
            if br.colliderect(pl.rect()): pl.take_damage(26 if self.rage else 18)
    def _atk(self,near,players,gs):
        cx=self.x+self.w//2; cy=self.y+self.h//3
        if self.ap==0:
            cnt=5 if self.rage else 3
            for i in range(cnt):
                dx=near.x-self.x; dy=near.y-self.y; dd=math.hypot(dx,dy) or 1
                gs.projectiles.append(Proj(cx,cy,dx/dd*7+(i-cnt//2)*0.35,dy/dd*7,RED,24,85,"enemy"))
        elif self.ap==1:
            if self.on_gnd:
                for pl in players:
                    if not pl.dead and abs(pl.x-self.x)<220: pl.vy=-11; pl.take_damage(16)
                ps.burst(cx,self.y+self.h,(120,70,0),20,6)
        else: self.vx=self.facing*14
    def draw(self,surf,cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-160 or sx>W+160: return
        bob=int(math.sin(self.af*math.pi/2)*4)
        rc=(255,0,0) if self.rage else (180,0,0); dk=tuple(max(0,c-60) for c in rc)
        if self.bt=="monkey_boss":
            pygame.draw.ellipse(surf,rc,(sx+10,sy+70+bob,24,36)); pygame.draw.ellipse(surf,rc,(sx+42,sy+70+bob,24,36))
            pygame.draw.ellipse(surf,rc,(sx+4,sy+28+bob,68,56)); pygame.draw.ellipse(surf,rc,(sx-18,sy+20+bob,26,60)); pygame.draw.ellipse(surf,rc,(sx+68,sy+20+bob,26,60))
            pygame.draw.ellipse(surf,rc,(sx+8,sy-10+bob,60,52)); pygame.draw.ellipse(surf,(180,120,40),(sx+16,sy-4+bob,44,30))
            ec=(255,0,0) if self.rage else (255,100,0)
            pygame.draw.circle(surf,ec,(sx+22,sy-2+bob),8); pygame.draw.circle(surf,ec,(sx+54,sy-2+bob),8)
            pygame.draw.circle(surf,BLACK,(sx+22,sy-2+bob),4); pygame.draw.circle(surf,BLACK,(sx+54,sy-2+bob),4)
            for i in range(5):
                a=math.tau/5*i-math.pi/2
                pygame.draw.line(surf,(0,200,50),(sx+38,sy+16+bob),(sx+38+int(math.cos(a)*34),sy+16+int(math.sin(a)*26)+bob),4)
        else:
            pygame.draw.polygon(surf,dk,[(sx+20,sy+30+bob),(sx-30,sy-20+bob),(sx+10,sy+70+bob)])
            pygame.draw.polygon(surf,dk,[(sx+70,sy+30+bob),(sx+120,sy-20+bob),(sx+80,sy+70+bob)])
            pygame.draw.ellipse(surf,rc,(sx+5,sy+30+bob,80,88)); pygame.draw.ellipse(surf,rc,(sx+20,sy-4+bob,44,46))
            pygame.draw.ellipse(surf,rc,(sx+15+self.facing*8,sy-28+bob,56,36))
            pygame.draw.polygon(surf,(40,40,40),[(sx+24,sy-28+bob),(sx+20,sy-50+bob),(sx+30,sy-28+bob)])
            pygame.draw.polygon(surf,(40,40,40),[(sx+36,sy-30+bob),(sx+34,sy-52+bob),(sx+44,sy-30+bob)])
            ec=(255,0,0) if self.rage else (255,120,0)
            pygame.draw.circle(surf,ec,(sx+30,sy-16+bob),9); pygame.draw.circle(surf,ec,(sx+50,sy-14+bob),9)
            pygame.draw.circle(surf,YELLOW,(sx+30,sy-16+bob),5); pygame.draw.circle(surf,YELLOW,(sx+50,sy-14+bob),5)

# ─────────────────────────────────────────────────────────────────────────────
# PLAYER
# ─────────────────────────────────────────────────────────────────────────────
class Player:
    PW,PH=28,38
    def __init__(self,cid,slot):
        d=next(x for x in CDEFS if x[0]==cid)
        _,nm,col,spd,jmp,hp,mp,cs=d
        self.cid=cid; self.name=nm; self.color=col
        self.speed=spd; self.jf=jmp; self.max_hp=hp; self.max_mp=mp
        self.ctrl=CTRL[cs]
        self.is_rex=(cid==0); self.is_mago=(cid==3); self.is_kira=(cid==4)
        self.slot=slot
        self.x=80.0+slot*36; self.y=360.0
        self.vx=self.vy=0.0; self.w,self.h=self.PW,self.PH
        self.on_gnd=False; self.jl=2; self.facing=1
        self.hp=float(hp); self.mp=float(mp)
        self.dead=False; self.inv=0; self.acd=0; self.scd=0
        self.at=self.af=0; self.state="idle"; self.st=0
        self.power="none"; self.ptimer=0; self.pbank=["none"]
        self._jh=self._ah=self._sh=self._slh=False
    def rect(self): return pygame.Rect(int(self.x),int(self.y),self.w,self.h)

    def update(self,keys,platforms,gs):
        if self.dead: return
        c=self.ctrl
        def K(i):
            if self.slot==0: return keys[c[i]]
            kb=pygame.key.get_pressed()
            return kb[c[i]]

        if self.acd>0: self.acd-=1
        if self.scd>0: self.scd-=1
        if self.inv>0: self.inv-=1
        if self.ptimer>0: self.ptimer-=1
        elif self.is_rex and self.power!="none": self.power="none"

        mv=False
        if K(0): self.vx=-self.speed; self.facing=-1; mv=True
        elif K(1): self.vx=self.speed; self.facing=1; mv=True
        else: self.vx*=0.75

        if K(2):
            if not self._jh and self.jl>0:
                self.vy=-self.jf; self.jl-=1; ps.burst(self.x+self.w//2,self.y+self.h,self.color,6,2); self._jh=True
        else: self._jh=False

        if K(3) and self.on_gnd and not self._slh:
            self.vx+=self.facing*9; ps.burst(self.x+self.w//2,self.y+self.h,(100,100,100),4,2); self._slh=True
        elif not K(3): self._slh=False

        if K(4) and self.acd==0 and not self._ah:
            self._attack(gs); self.acd=22; self._ah=True; self.state="attack"; self.st=16
        elif not K(4): self._ah=False

        if K(5) and self.acd==0 and not self._ah:
            self._ranged(gs); self.acd=28; self._ah=True

        if K(6) and self.scd==0 and self.mp>=30 and not self._sh:
            self._special(gs); self.scd=90; self.mp-=30; self._sh=True; self.state="special"; self.st=22
        elif not K(6): self._sh=False

        self.vy+=GRAVITY; self.vy=min(self.vy,16); self.x+=self.vx; self.y+=self.vy
        if self.x<0: self.x=0
        if self.x+self.w>gs.level_width: self.x=gs.level_width-self.w

        # axis-separated platform collision
        self.on_gnd=False
        r=self.rect()
        for p in platforms:
            pr=p.rect()
            if not r.colliderect(pr): continue
            ox=min(r.right-pr.left,pr.right-r.left)
            oy=min(r.bottom-pr.top,pr.bottom-r.top)
            if oy<=ox:
                if self.vy>=0 and r.centery<pr.centery: self.y=float(pr.top-self.h); self.vy=0; self.on_gnd=True; self.jl=2
                elif self.vy<0 and r.centery>pr.centery: self.y=float(pr.bottom); self.vy=0
            else:
                if r.centerx<pr.centerx: self.x=float(pr.left-self.w)
                else: self.x=float(pr.right)
                self.vx=0
            r=self.rect()

        if self.y>H+120: self.take_damage(9999)
        self.mp=min(self.max_mp,self.mp+0.04)
        self.at+=1
        if self.at>=8: self.at=0; self.af=(self.af+1)%4
        if self.st>0: self.st-=1
        else:
            self.state="jump" if not self.on_gnd else ("run" if mv else "idle")

    def _attack(self,gs):
        cx=self.x+self.w//2+self.facing*30; cy=self.y+self.h//2
        for e in gs.enemies:
            if e.dead: continue
            if abs(e.x+e.w//2-cx)<58 and abs(e.y+e.h//2-cy)<48:
                d=random.randint(18,28)
                if self.is_rex and self.power=="fire": d=int(d*1.5)
                if self.is_rex and self.power=="electric": d=int(d*1.3)
                if self.is_mago: d=int(d*0.8)
                e.take_damage(d,self,gs); ps.blood(e.x+e.w//2,e.y+e.h//2)
        if gs.boss and not gs.boss.dead:
            b=gs.boss
            if abs(b.x+b.w//2-cx)<68 and abs(b.y+b.h//2-cy)<68:
                gs.boss.take_damage(random.randint(14,22),gs); ps.blood(b.x+b.w//2,b.y+b.h//2)

    def _ranged(self,gs):
        col=self.color; spd=9; dmg=12
        if self.is_rex:
            if self.power=="fire": col=(255,80,10); dmg=20
            if self.power=="electric": col=YELLOW; dmg=16
        if self.is_mago: col=PURPLE; dmg=22; spd=10
        gs.projectiles.append(Proj(self.x+self.w//2,self.y+self.h//2-5,self.facing*spd,0,col,dmg,80,"player",self.slot))

    def _special(self,gs):
        cx=self.x+self.w//2; cy=self.y+self.h//2
        if self.is_rex:
            if self.power=="fire":
                for dy in (-1,0,1): gs.projectiles.append(Proj(cx,cy,self.facing*8,dy*1.5,(255,80,10),30,60,"player",self.slot))
                ps.burst(cx,cy,(255,80,10),18,7)
            elif self.power=="electric":
                for e in gs.enemies:
                    if not e.dead and math.hypot(e.x-self.x,e.y-self.y)<160: e.take_damage(35,self,gs); ps.spark(e.x+e.w//2,e.y+e.h//2)
                if gs.boss: gs.boss.take_damage(25,gs)
                ps.burst(cx,cy,YELLOW,20,8)
            else:
                for i in range(8):
                    a=math.tau/8*i
                    gs.projectiles.append(Proj(cx,cy,math.cos(a)*6,math.sin(a)*6,GREEN,22,45,"player",self.slot))
                ps.magic(cx,cy)
        elif self.is_mago:
            # Arcane Nova — screen-wide damage burst
            ps.burst(cx,cy,PURPLE,30,8); ps.burst(cx,cy,(200,100,255),20,12)
            for e in gs.enemies:
                if not e.dead:
                    d=math.hypot(e.x-self.x,e.y-self.y)
                    if d<300: e.take_damage(int(60*(1-d/300)+15),self,gs); ps.magic(e.x+e.w//2,e.y+e.h//2)
            if gs.boss: gs.boss.take_damage(40,gs)
            self.vy=-8
        elif self.is_kira:
            self.vx=self.facing*18; self.inv=22
            for e in gs.enemies:
                if not e.dead and abs(e.x-self.x)<180 and abs(e.y-self.y)<50: e.take_damage(42,self,gs); ps.blood(e.x+e.w//2,e.y+e.h//2)
            ps.burst(cx,cy,PINK,15,5)
        elif self.name=="VALE":
            for i in range(6): gs.projectiles.append(Proj(cx+self.facing*i*18,cy-30,self.facing*4,-6+i*0.5,ORANGE,18,80,"player",self.slot))
            ps.burst(cx,cy,ORANGE,10,4)
        elif self.name=="ZAP":
            for e in gs.enemies:
                if not e.dead and math.hypot(e.x-self.x,e.y-self.y)<130: e.take_damage(45,self,gs); e.stun=60; ps.spark(e.x+e.w//2,e.y+e.h//2)
            if gs.boss and math.hypot(gs.boss.x-self.x,gs.boss.y-self.y)<130: gs.boss.take_damage(30,gs)
            ps.burst(cx,cy,CYAN,20,6)

    def absorb(self,et):
        if not self.is_rex: return
        pwr=EPWR.get(et,"none")
        if pwr!="none" and pwr not in self.pbank: self.pbank.append(pwr)
        self.power=pwr; self.ptimer=600; ps.absorb(self.x+self.w//2,self.y+self.h//2)
        if pwr!="none": add_float(self.x,self.y-24,f"PODER: {POWERS[pwr]['name']}!",POWERS[pwr]['col'])

    def take_damage(self,dmg):
        if self.inv>0 or self.dead: return
        self.hp-=dmg; self.inv=48; self.state="hurt"; self.st=16; ps.blood(self.x+self.w//2,self.y+self.h//2)
        if self.hp<=0: self.hp=0; self.dead=True; ps.burst(self.x+self.w//2,self.y+self.h//2,self.color,22,8)

    def draw(self,surf,cx):
        if self.dead: return
        sx=int(self.x-cx); sy=int(self.y)
        if sx<-60 or sx>W+60: return
        if self.inv>0 and (self.inv//4)%2==1: return
        if   self.is_rex:  self._draw_rex(surf,sx,sy)
        elif self.is_mago: self._draw_mago(surf,sx,sy)
        else:              self._draw_human(surf,sx,sy)
        ns=F_TINY.render(self.name,True,self.color); surf.blit(ns,(sx+self.w//2-ns.get_width()//2,sy-14))
        if self.is_rex and self.power!="none":
            pc=POWERS[self.power]; ic=F_TINY.render(f"[{pc['name']}]",True,pc['col']); surf.blit(ic,(sx-2,sy-26))

    def _draw_human(self,surf,sx,sy):
        c=self.color; dc=tuple(max(0,v-80) for v in c)
        bob=int(math.sin(self.af*math.pi/2)*2) if self.state=="run" else 0
        ls=int(math.sin(self.af*math.pi/2)*6) if self.state=="run" else 0
        pygame.draw.rect(surf,dc,(sx+2,sy+22+bob,10,14+ls)); pygame.draw.rect(surf,dc,(sx+14,sy+22+bob,10,14-ls))
        pygame.draw.rect(surf,dc,(sx,sy+8+bob,self.w,18)); pygame.draw.rect(surf,c,(sx+1,sy+9+bob,self.w-2,16))
        pygame.draw.rect(surf,(230,190,150),(sx+4,sy-6+bob,18,14)); pygame.draw.rect(surf,dc,(sx+4,sy-7+bob,18,6))
        ex=sx+14+(4 if self.facing>0 else -4)
        pygame.draw.circle(surf,WHITE,(ex,sy-2+bob),3); pygame.draw.circle(surf,BLACK,(ex+self.facing,sy-2+bob),2)
        if self.state=="attack" and self.st>4:
            pygame.draw.rect(surf,WHITE,(sx+self.w//2+self.facing*8,sy+6+bob,self.facing*26,4))

    def _draw_rex(self,surf,sx,sy):
        pwr=self.power; gc=POWERS[pwr]['col'] if pwr!="none" else GREEN
        pygame.draw.ellipse(surf,(90,58,26),(sx+2,sy+10,26,22))
        if pwr!="none": pygame.draw.ellipse(surf,gc,(sx+4,sy+12,22,18),2)
        pygame.draw.ellipse(surf,(100,66,30),(sx+12,sy-4,20,18))
        pygame.draw.polygon(surf,(80,48,20),[(sx+14,sy-4),(sx+12,sy-14),(sx+18,sy-4)])
        pygame.draw.polygon(surf,(80,48,20),[(sx+22,sy-4),(sx+26,sy-12),(sx+28,sy-4)])
        ex=sx+18+(2 if self.facing>0 else -2)
        pygame.draw.circle(surf,WHITE,(ex,sy+2),4); pygame.draw.circle(surf,gc,(ex+self.facing,sy+2),2)
        pygame.draw.ellipse(surf,(230,160,90),(sx+22,sy+4,10,8))
        tw=int(math.sin(pygame.time.get_ticks()*0.008)*10)
        pygame.draw.arc(surf,(90,58,26),(sx-14+tw,sy+4,14,18),math.pi*0.2,math.pi*1.2,4)
        if pwr=="fire": pygame.draw.circle(surf,(255,100,20),(sx+14,sy+5),18,2)
        elif pwr=="electric": pygame.draw.circle(surf,YELLOW,(sx+14,sy+5),18,2)

    def _draw_mago(self,surf,sx,sy):
        bob=int(math.sin(self.af*math.pi/2)*2) if self.state=="run" else 0
        pygame.draw.polygon(surf,(80,20,120),[(sx,sy+36+bob),(sx+self.w,sy+36+bob),(sx+self.w-4,sy+8+bob),(sx+4,sy+8+bob)])
        pygame.draw.polygon(surf,PURPLE,[(sx+2,sy+34+bob),(sx+self.w-2,sy+34+bob),(sx+self.w-6,sy+10+bob),(sx+6,sy+10+bob)])
        pygame.draw.ellipse(surf,(230,190,150),(sx+4,sy-6+bob,20,16))
        pygame.draw.polygon(surf,(60,0,100),[(sx+2,sy-6+bob),(sx+22,sy-6+bob),(sx+22,sy-10+bob),(sx+14,sy-26+bob),(sx+10,sy-26+bob),(sx+2,sy-10+bob)])
        pygame.draw.rect(surf,(80,0,140),(sx-2,sy-10+bob,28,4))
        pygame.draw.circle(surf,CYAN,(sx+10,sy-1+bob),3); pygame.draw.circle(surf,CYAN,(sx+18,sy-1+bob),3)
        pygame.draw.line(surf,(120,80,20),(sx+self.w+2,sy-10+bob),(sx+self.w+2,sy+30+bob),3)
        pygame.draw.circle(surf,PURPLE,(sx+self.w+2,sy-10+bob),7); pygame.draw.circle(surf,(200,150,255),(sx+self.w+2,sy-10+bob),4)
        if self.af in(0,2):
            pygame.draw.circle(surf,(200,150,255),(sx+8,sy+20+bob),2); pygame.draw.circle(surf,(200,150,255),(sx+18,sy+15+bob),2)
        if self.state=="attack" and self.st>4:
            pygame.draw.arc(surf,(200,100,255),(sx+self.facing*4,sy-5+bob,30,20),0,math.pi,3)

# ─────────────────────────────────────────────────────────────────────────────
# LEVELS
# ─────────────────────────────────────────────────────────────────────────────
def _p(*a,**k): return Platform(*a,**k)
def _s(x,y,n=5): return Spike(x,y,n)
def _e(t,x,y): return Enemy(t,x,y)
def _c(x,y,t): return Collectible(x,y,t)

def make_lv1():
    plats=[
        _p(0,460,380,60),_p(430,460,320,60),_p(810,460,480,60),_p(1350,460,400,60),
        _p(1800,460,320,60),_p(2180,460,560,60),_p(2800,460,420,60),_p(3270,460,330,60),
        _p(180,360,140,18),_p(480,320,120,18),_p(680,275,100,18),_p(890,340,170,18),
        _p(1120,290,120,18),_p(1380,318,140,18),_p(1580,258,100,18),_p(1840,328,130,18),
        _p(2050,276,150,18),_p(2280,316,120,18),_p(2490,264,100,18),_p(2690,336,180,18),
        _p(2940,274,150,18),_p(3090,224,120,18),_p(3290,308,170,18),
    ]
    return dict(
        name="CIDADE DESTRUÍDA — ATO I", width=3650,
        platforms=plats,
        spikes=[_s(390,440,3),_s(1300,440,3),_s(1760,440,4)],
        enemies=[_e("rat",580,420),_e("rat",840,420),_e("insect",990,300),
                 _e("rat",1180,420),_e("insect",1450,278),_e("robot",1680,420),
                 _e("skeleton",1930,238),_e("robot",2210,420),_e("insect",2400,224),
                 _e("robot",2590,296),_e("robot",2880,420),_e("skeleton",3070,184),
                 _e("rat",3180,420),_e("dragon",3250,420)],
        collectibles=[_c(290,322,"memory"),_c(880,302,"health"),_c(1570,220,"memory"),
                      _c(2480,226,"health"),_c(3080,186,"powerup")],
        boss=Boss("dragon_boss",3450,330,"DRAGÃO ALFA"),
        prison=Prison(580,390),
        bg_top=(10,10,22),bg_bot=(16,14,30),accent=(28,28,56),
        memory="...fogo por toda parte...\nRex... esse nome...\nalgo quente ao meu lado no incêndio.",
    )

def make_lv2():
    gc=(12,28,12); gc2=(8,18,8)
    def gp(*a): return Platform(*a,col1=gc,col2=gc2)
    plats=[
        gp(0,460,340,60),gp(390,460,380,60),gp(830,460,340,60),gp(1230,460,430,60),
        gp(1730,460,380,60),gp(2180,460,480,60),gp(2730,460,390,60),gp(3190,460,380,60),gp(3640,460,80,60),
        gp(170,358,140,18),gp(440,308,120,18),gp(640,258,100,18),gp(890,318,160,18),
        gp(1090,268,120,18),gp(1340,298,150,18),gp(1590,238,120,18),gp(1840,308,140,18),
        gp(2040,258,130,18),gp(2340,288,120,18),gp(2590,228,110,18),gp(2840,308,180,18),
        gp(3040,258,140,18),gp(3290,218,130,18),gp(3540,278,160,18),
    ]
    return dict(
        name="FLORESTA MUTANTE — ATO II", width=3800,
        platforms=plats,
        spikes=[_s(345,440,3),_s(790,440,3),_s(1680,440,4),_s(2690,440,3)],
        enemies=[_e("monkey",490,420),_e("rat",740,420),_e("monkey",940,278),
                 _e("insect",1140,228),_e("monkey",1390,258),_e("skeleton",1640,198),
                 _e("monkey",1890,420),_e("insect",2090,218),_e("monkey",2390,248),
                 _e("insect",2640,188),_e("robot",2890,268),_e("monkey",3090,218),
                 _e("skeleton",3340,178),_e("monkey",3590,238)],
        collectibles=[_c(240,320,"memory"),_c(790,220,"health"),_c(1580,200,"memory"),
                      _c(2580,190,"powerup"),_c(3280,178,"health")],
        boss=Boss("monkey_boss",3600,340,"MACACO ALFA RADIOATIVO"),
        prison=None,
        bg_top=(5,12,5),bg_bot=(8,20,8),accent=(14,36,14),
        memory="...Rex... eu me lembro...\num filhote que me lambeu o rosto\nno laboratório em chamas.",
    )

LEVELS=[make_lv1,make_lv2]

# ─────────────────────────────────────────────────────────────────────────────
# GAME STATE
# ─────────────────────────────────────────────────────────────────────────────
class GS:
    def __init__(self):
        self.screen="title"; self.score=0; self.num_players=1; self.cur=0
        self.players=[]; self.platforms=[]; self.spikes=[]
        self.enemies=[]; self.collectibles=[]; self.projectiles=[]
        self.boss=None; self.boss_active=False; self.boss_bar=False
        self.level_cleared=False; self.game_over=False
        self.cam_x=0.0; self.level_width=3650
        self.mem_count=0; self.trigger_mem=False; self.mem_text=""
        self.level_name=""; self.level_mem=""
        self.frame=0; self.hovered=0; self.sel_num=1
        self.vic_t=0; self.mem_t=0
        self.prison=None; self.kira_freed=False
        self.bg_top=(10,10,22); self.bg_bot=(16,14,30); self.accent=(28,28,56)

    def load(self,idx):
        global floats; floats=[]; ps.p=[]
        d=LEVELS[idx]()
        self.platforms=d["platforms"]; self.spikes=d["spikes"]
        self.enemies=d["enemies"]; self.collectibles=d["collectibles"]
        self.boss=d["boss"]; self.projectiles=[]; self.boss_active=False; self.boss_bar=False
        self.level_cleared=False; self.game_over=False; self.cam_x=0.0
        self.level_width=d["width"]; self.level_name=d["name"]; self.level_mem=d["memory"]
        self.vic_t=0; self.score=0; self.mem_count=0; self.trigger_mem=False
        self.prison=d.get("prison"); self.kira_freed=False
        self.bg_top=d["bg_top"]; self.bg_bot=d["bg_bot"]; self.accent=d["accent"]

    def _make_players(self,include_kira=False):
        avail=[0,1,2,3]   # REX VALE ZAP MAGO
        chars=avail[:self.num_players]
        if include_kira: chars.append(4)
        self.players=[Player(cid,i) for i,cid in enumerate(chars)]

    def start(self):
        self.cur=0; self.mem_count=0; self.load(0); self._make_players(False); self.screen="game"

    def restart(self):
        self.load(self.cur); kf=self.kira_freed; self._make_players(kf); self.screen="game"

    def next_level(self):
        self.cur=(self.cur+1)%len(LEVELS); kf=self.kira_freed
        self.load(self.cur); self._make_players(kf); self.screen="game"

    def free_kira(self):
        if self.kira_freed: return
        self.kira_freed=True
        slot=len(self.players); k=Player(4,slot)
        if self.prison: k.x=self.prison.x+20; k.y=self.prison.y-50
        self.players.append(k)

gs=GS()

# ─────────────────────────────────────────────────────────────────────────────
# BACKGROUND  (integer draw, no alpha surfaces)
# ─────────────────────────────────────────────────────────────────────────────
def draw_bg(surf,cx):
    bt,bb,ac=gs.bg_top,gs.bg_bot,gs.accent
    for y in range(0,H,3):
        t=y/H
        pygame.draw.line(surf,(int(lerp(bt[0],bb[0],t)),int(lerp(bt[1],bb[1],t)),int(lerp(bt[2],bb[2],t))),(0,y),(W,y))
    rng=random.Random(42)
    for _ in range(80):
        px=(rng.randint(0,W*4)-int(cx*0.08))%W; py=rng.randint(0,int(H*0.65))
        surf.set_at((px,py),(180,180,200))
    rng2=random.Random(7); off=int(cx*0.28)
    for i in range(14):
        bx=(rng2.randint(0,W*2)-off%(W*2)+W*4)%(W*2)-60
        bh=rng2.randint(70,160); bw=rng2.randint(22,44)
        pygame.draw.rect(surf,(ac[0]+6,ac[1]+6,ac[2]+12),(bx,H-bh-50,bw,bh))
    rng3=random.Random(13); off2=int(cx*0.52)
    for i in range(20):
        bx=(rng3.randint(0,W*3)-off2%(W*3)+W*6)%(W*3)-40
        bh=rng3.randint(40,100); bw=rng3.randint(14,30)
        pygame.draw.rect(surf,(ac[0]+14,ac[1]+14,ac[2]+22),(bx,H-bh-46,bw,bh))

# ─────────────────────────────────────────────────────────────────────────────
# HUD
# ─────────────────────────────────────────────────────────────────────────────
# Reusable alpha overlay surfaces (created once)
_OV_BLACK = pygame.Surface((W,H)); _OV_BLACK.set_alpha(200); _OV_BLACK.fill(BLACK)
_OV_MEM   = pygame.Surface((W,H)); _OV_MEM.set_alpha(180);  _OV_MEM.fill((28,0,55))

def draw_hud(surf):
    pygame.draw.rect(surf,BLACK,(0,0,W,52))
    pygame.draw.line(surf,(40,40,60),(0,52),(W,52),1)
    sw=186
    for i,p in enumerate(gs.players):
        ox=3+i*sw; c=p.color
        ns=F_TINY.render(("💀" if p.dead else "")+p.name,True,c); surf.blit(ns,(ox,3))
        bw=148; bh=8
        pygame.draw.rect(surf,(40,10,10),(ox,16,bw,bh))
        pygame.draw.rect(surf,GREEN if p.hp/p.max_hp>0.5 else (YELLOW if p.hp/p.max_hp>0.25 else RED),(ox,16,int(bw*max(0,p.hp/p.max_hp)),bh))
        pygame.draw.rect(surf,(80,80,80),(ox,16,bw,bh),1)
        surf.blit(F_TINY.render(f"HP{int(p.hp)}",True,GREY),(ox+bw+2,15))
        pygame.draw.rect(surf,(10,10,40),(ox,28,bw,bh))
        pygame.draw.rect(surf,BLUE,(ox,28,int(bw*max(0,p.mp/p.max_mp)),bh))
        pygame.draw.rect(surf,(80,80,80),(ox,28,bw,bh),1)
        if p.is_rex and p.power!="none":
            pc=POWERS[p.power]; surf.blit(F_TINY.render(f"[{pc['name']} {p.ptimer//60}s]",True,pc['col']),(ox,39))
    ln=F_SM.render(gs.level_name,True,YELLOW); surf.blit(ln,(W//2-ln.get_width()//2,3))
    sc=F_SM.render(f"PONTOS: {gs.score:,}",True,GREY); surf.blit(sc,(W//2-sc.get_width()//2,19))
    if gs.prison and not gs.prison.freed and not gs.kira_freed:
        ht=F_TINY.render("KIRA está presa — ataque as grades para libertá-la!",True,GOLD)
        surf.blit(ht,(W//2-ht.get_width()//2,38))
    elif gs.kira_freed:
        ht=F_TINY.render("✦ KIRA LIBERTADA — ela juntou-se ao grupo! ✦",True,GOLD)
        surf.blit(ht,(W//2-ht.get_width()//2,38))
    if gs.boss_bar and gs.boss and not gs.boss.dead:
        bx=W//2-220; by=H-38; bw=440; bh=14
        pygame.draw.rect(surf,(30,0,0),(bx,by,bw,bh))
        pygame.draw.rect(surf,RED,(bx,by,int(bw*max(0,gs.boss.hp/gs.boss.mhp)),bh))
        pygame.draw.rect(surf,(160,0,0),(bx,by,bw,bh),2)
        bn=F_SM.render(gs.boss.name,True,(255,80,80)); surf.blit(bn,(W//2-bn.get_width()//2,H-54))
    hint=F_TINY.render("P1:WASD+ZXC  P2:←→↑+UIO  P3:JLI+NM,  P4:Numpad  Mobile:botões na tela",True,(50,50,70))
    surf.blit(hint,(W//2-hint.get_width()//2,H-13))

# ─────────────────────────────────────────────────────────────────────────────
# MENU SCREENS
# ─────────────────────────────────────────────────────────────────────────────
def draw_title(surf):
    surf.fill((8,6,18))
    rng=random.Random(99)
    for _ in range(60): surf.set_at((rng.randint(0,W),rng.randint(0,H)),(70,55,110))
    fl=1.0 if math.sin(pygame.time.get_ticks()/142.0)>-0.92 else 0.6
    fc=tuple(int(c*fl) for c in YELLOW)
    s1=F_BIG.render("FORGOTTEN",True,fc); s2=F_BIG.render("PAWS",True,fc)
    surf.blit(s1,(W//2-s1.get_width()//2,70)); surf.blit(s2,(W//2-s2.get_width()//2,122))
    sub=F_SM.render("Resgate KIRA. Derrote o apocalipse.",True,PURPLE)
    surf.blit(sub,(W//2-sub.get_width()//2,185))
    tap_btn(surf,"tap_play","▶  JOGAR",W//2,268,280,54,(20,80,20))
    tap_btn(surf,"tap_exit","SAIR",    W//2,338,200,46,(80,20,20))
    h=F_TINY.render("Toque/clique nos botões  •  teclado também funciona",True,(55,55,75))
    surf.blit(h,(W//2-h.get_width()//2,H-16))

def draw_char_select(surf):
    surf.fill((6,10,6))
    s=F_MED.render("ESCOLHA OS GUERREIROS",True,GREEN); surf.blit(s,(W//2-s.get_width()//2,12))
    h2=F_SM.render("(KIRA está presa — resgate-a no Ato I!)",True,GOLD); surf.blit(h2,(W//2-h2.get_width()//2,40))
    tap_btn(surf,"tap_pl_less","◀",W//2-80,74,44,36,(30,60,30),F_MED)
    cs=F_MED.render(f"{gs.sel_num} jogador{'es' if gs.sel_num>1 else ''}",True,WHITE); surf.blit(cs,(W//2-cs.get_width()//2,61))
    tap_btn(surf,"tap_pl_more","▶",W//2+80,74,44,36,(30,60,30),F_MED)
    CDSC=[(0,"REX",GREEN,"Absorve poderes","P2:←→↑+UIO"),
          (1,"VALE",ORANGE,"Arco longo","P3:JLI+NM,"),
          (2,"ZAP",CYAN,"Campo elétrico","P4:Numpad"),
          (3,"MAGO",PURPLE,"Arcane Nova","P1:WASD+ZXC"),
          (4,"KIRA",PINK,"🔒 PRESA","Resgate!")]
    cw,ch=160,164; gap=8; total=len(CDSC)*(cw+gap)-gap; sx0=W//2-total//2
    for i,(cid,nm,col,atk,ctrl) in enumerate(CDSC):
        cx2=sx0+i*(cw+gap); cy2=92; locked=(cid==4)
        active=(i<gs.sel_num) and not locked
        bc=col if active else (GOLD if locked else (40,40,40))
        pygame.draw.rect(surf,(18,22,18) if active else (10,10,12),(cx2,cy2,cw,ch))
        pygame.draw.rect(surf,bc,(cx2,cy2,cw,ch),2)
        pygame.draw.circle(surf,bc,(cx2+cw//2,cy2+30),22); pygame.draw.circle(surf,(14,14,14),(cx2+cw//2,cy2+30),20)
        ns2=F_SM.render("🔒" if locked else str(i+1),True,bc); surf.blit(ns2,(cx2+cw//2-ns2.get_width()//2,cy2+20))
        nm2=F_SM.render(nm,True,col if active else (80,80,80) if not locked else GOLD); surf.blit(nm2,(cx2+cw//2-nm2.get_width()//2,cy2+56))
        for j,line in enumerate([atk,ctrl]):
            ls=F_TINY.render(line,True,(140,140,110) if active else (55,55,55)); surf.blit(ls,(cx2+5,cy2+82+j*22))
        if active:
            p2=F_TINY.render(f"P{i+1}",True,col); surf.blit(p2,(cx2+4,cy2+4))
    tap_btn(surf,"tap_start","▶ INICIAR AVENTURA",W//2,290,320,52,(10,80,10))
    tap_btn(surf,"tap_back","◀ VOLTAR",           W//2,355,200,42,(60,30,10))

def draw_game_over(surf):
    surf.blit(_OV_BLACK,(0,0))
    ox=int(math.sin(pygame.time.get_ticks()*0.01)*4)
    go=F_BIG.render("VOCÊ CAIU",True,RED); surf.blit(go,(W//2-go.get_width()//2+ox,155))
    sb=F_SM.render("O apocalipse não perdoa...",True,(150,50,50)); surf.blit(sb,(W//2-sb.get_width()//2,220))
    tap_btn(surf,"tap_restart","↺ TENTAR NOVAMENTE",W//2,308,300,50,(60,10,10))
    tap_btn(surf,"tap_menu","MENU",                 W//2,374,200,44,(40,30,10))

def draw_victory(surf):
    surf.blit(_OV_BLACK,(0,0))
    t=pygame.time.get_ticks()/1000.0
    fc=tuple(int(c*(0.8+0.2*math.sin(t*3))) for c in YELLOW)
    vt=F_BIG.render("✦ VITÓRIA ✦",True,fc); surf.blit(vt,(W//2-vt.get_width()//2,125))
    sc=F_MED.render(f"PONTUAÇÃO: {gs.score:,}",True,WHITE); surf.blit(sc,(W//2-sc.get_width()//2,205))
    mem=F_SM.render("Uma memória retornou...",True,PURPLE); surf.blit(mem,(W//2-mem.get_width()//2,250))
    tap_btn(surf,"tap_next","▶ PRÓXIMA FASE",W//2,332,260,50,(10,60,10))
    tap_btn(surf,"tap_menu","MENU",          W//2,396,200,44,(40,30,10))

def draw_memory(surf):
    surf.blit(_OV_MEM,(0,0))
    ts=F_MED.render("✦ FRAGMENTO DE MEMÓRIA ✦",True,(200,160,255)); surf.blit(ts,(W//2-ts.get_width()//2,155))
    for i,line in enumerate(gs.mem_text.split("\n")):
        ls=F_SM.render(line.strip(),True,(220,200,255)); surf.blit(ls,(W//2-ls.get_width()//2,224+i*30))
    tap_btn(surf,"tap_continue","CONTINUAR",W//2,H-55,220,42,(40,20,80))

# ─────────────────────────────────────────────────────────────────────────────
# TAP HANDLER
# ─────────────────────────────────────────────────────────────────────────────
def handle_tap(name,paused):
    if   name=="tap_play":      gs.screen="char_select"
    elif name=="tap_exit":      pygame.quit(); sys.exit()
    elif name=="tap_pl_less":   gs.sel_num=max(1,gs.sel_num-1); gs.num_players=gs.sel_num
    elif name=="tap_pl_more":   gs.sel_num=min(4,gs.sel_num+1); gs.num_players=gs.sel_num
    elif name=="tap_start":     gs.start()
    elif name=="tap_back":      gs.screen="title"
    elif name=="tap_restart":   gs.restart()
    elif name=="tap_menu":      gs.screen="title"
    elif name=="tap_next":      gs.next_level()
    elif name=="tap_continue":  gs.screen="game"
    elif name=="tap_pause":     paused[0]=not paused[0]

# ─────────────────────────────────────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────────────────────────────────────
async def main():
    paused=[False]

    while True:
        clock.tick(FPS)
        mk.refresh()
        gs.frame+=1
        tap_zones.clear()

        for ev in pygame.event.get():
            if ev.type==pygame.QUIT: pygame.quit(); sys.exit()

            if gs.screen=="game": mobile.handle(ev)

            if ev.type==pygame.MOUSEBUTTONDOWN:
                mx,my=ev.pos
                for name,r in tap_zones.items():
                    if r.collidepoint(mx,my): handle_tap(name,paused); break

            if ev.type==pygame.KEYDOWN:
                k=ev.key
                if gs.screen=="title":
                    if k in(pygame.K_UP,pygame.K_w):   gs.hovered=(gs.hovered-1)%2
                    if k in(pygame.K_DOWN,pygame.K_s): gs.hovered=(gs.hovered+1)%2
                    if k in(pygame.K_RETURN,pygame.K_SPACE):
                        if gs.hovered==0: gs.screen="char_select"
                        else: pygame.quit(); sys.exit()
                    if k==pygame.K_ESCAPE: pygame.quit(); sys.exit()
                elif gs.screen=="char_select":
                    if k==pygame.K_LEFT:  gs.sel_num=max(1,gs.sel_num-1); gs.num_players=gs.sel_num
                    if k==pygame.K_RIGHT: gs.sel_num=min(4,gs.sel_num+1); gs.num_players=gs.sel_num
                    if k in(pygame.K_RETURN,pygame.K_SPACE): gs.start()
                    if k==pygame.K_ESCAPE: gs.screen="title"
                elif gs.screen=="game":
                    if k==pygame.K_ESCAPE: gs.screen="title"
                    if k==pygame.K_r:      gs.restart()
                    if k==pygame.K_SPACE:  paused[0]=not paused[0]
                elif gs.screen=="memory":
                    if k in(pygame.K_RETURN,pygame.K_SPACE,pygame.K_ESCAPE): gs.screen="game"
                elif gs.screen=="game_over":
                    if k==pygame.K_r:      gs.restart()
                    if k==pygame.K_ESCAPE: gs.screen="title"
                elif gs.screen=="victory":
                    if k in(pygame.K_RETURN,pygame.K_SPACE): gs.next_level()
                    if k==pygame.K_ESCAPE: gs.screen="title"

        # ── update ──────────────────────────────────────────────────────────
        if gs.screen=="game" and not paused[0]:
            for p in gs.players:
                p.update(mk if p.slot==0 else pygame.key.get_pressed(), gs.platforms, gs)

            for e in gs.enemies: e.update(gs.platforms,gs.players,gs)

            if gs.prison and not gs.prison.freed:
                if gs.prison.try_break(gs.players,gs): gs.free_kira()

            all_dead=all(e.dead for e in gs.enemies)
            any_near=any(not p.dead and p.x>gs.level_width-750 for p in gs.players)
            if not gs.boss_active and (all_dead or any_near):
                gs.boss_active=True; gs.boss_bar=True
                add_float(gs.boss.x+gs.boss.w//2,gs.boss.y-60,"⚠ BOSS!",RED)
                ps.burst(gs.boss.x+gs.boss.w//2,gs.boss.y+gs.boss.h//2,RED,30,10)
            if gs.boss_active and not gs.boss.dead:
                gs.boss.update(gs.platforms,gs.players,gs)

            live=[]
            for proj in gs.projectiles:
                proj.update(gs.platforms,gs.players,gs.enemies,gs)
                if not proj.dead: live.append(proj)
            gs.projectiles=live

            for c in gs.collectibles: c.update(gs.players,gs)
            for s in gs.spikes: s.hurt(gs.players)
            ps.update()
            for ft in floats: ft.update()
            floats[:]=[ft for ft in floats if ft.life>0]

            alive=[p for p in gs.players if not p.dead]
            if alive:
                avg=sum(p.x for p in alive)/len(alive)
                gs.cam_x=lerp(gs.cam_x,max(0,min(gs.level_width-W,avg-W//3)),0.09)

            if all(p.dead for p in gs.players) and not gs.game_over:
                gs.game_over=True; gs.screen="game_over"

            if gs.level_cleared and not gs.game_over:
                gs.vic_t+=1
                if gs.vic_t>120: gs.screen="victory"; gs.level_cleared=False

            if gs.trigger_mem:
                gs.trigger_mem=False; gs.mem_text=gs.level_mem; gs.mem_t=0; gs.screen="memory"

        # ── draw ────────────────────────────────────────────────────────────
        cx=int(gs.cam_x)   # INTEGER camera — eliminates sub-pixel shimmer

        if   gs.screen=="title":       draw_title(screen)
        elif gs.screen=="char_select": draw_char_select(screen)
        elif gs.screen in("game","memory","game_over","victory"):
            draw_bg(screen,cx)
            for p in gs.platforms:    p.draw(screen,cx)
            for s in gs.spikes:       s.draw(screen,cx)
            for c in gs.collectibles: c.draw(screen,cx)
            for proj in gs.projectiles: proj.draw(screen,cx)
            for e in gs.enemies:      e.draw(screen,cx)
            if gs.prison and not gs.prison.freed: gs.prison.draw(screen,cx)
            if gs.boss_active and gs.boss and not gs.boss.dead: gs.boss.draw(screen,cx)
            for p in gs.players: p.draw(screen,cx)
            ps.draw(screen,cx)
            for ft in floats: ft.draw(screen,cx)
            draw_hud(screen)

            if gs.screen=="game":
                mobile.draw(screen)
                tap_btn(screen,"tap_pause","II" if not paused[0] else "▶",W//2,36,50,24,(50,50,70),F_SM)
                if paused[0]:
                    ps2=F_BIG.render("PAUSADO",True,YELLOW)
                    screen.blit(ps2,(W//2-ps2.get_width()//2,H//2-28))
                    tap_btn(screen,"tap_menu","MENU",W//2,H//2+52,160,44,(60,40,20))
            elif gs.screen=="memory":  gs.mem_t+=1; draw_memory(screen)
            elif gs.screen=="game_over": draw_game_over(screen)
            elif gs.screen=="victory":   draw_victory(screen)

        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
