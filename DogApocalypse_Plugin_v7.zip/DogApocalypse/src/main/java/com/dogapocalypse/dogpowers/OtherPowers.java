package com.dogapocalypse.dogpowers;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

// =============================================================
// SPIDER POWER
// =============================================================

/**
 * Spider Power — Wall climbing ability.
 * Passive: While power is active, player can "climb" by walking into walls.
 * Implemented via periodic velocity nudge when the player is against a solid surface.
 */
class SpiderPower implements DogPower {

    private final DogApocalypsePlugin plugin;
    private final int cooldownTicks;
    private final int durationTicks;

    /** Active climbing task IDs */
    private final Map<UUID, Integer> climbTasks = new HashMap<>();

    SpiderPower(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        this.cooldownTicks = plugin.getConfig().getInt("dog_powers.spider.cooldown_ticks", 40);
        this.durationTicks = plugin.getConfig().getInt("dog_powers.spider.duration_ticks", 300);
    }

    @Override public String getId()          { return "spider"; }
    @Override public String getDisplayName() { return "&2Spider Power"; }
    @Override public String getDescription() { return "Climb walls like a mutant spider!"; }

    @Override
    public void activate(Player player) {
        player.sendMessage(MessageUtil.color("&2[Spider] &fWall climbing unlocked! Jump while touching walls."));

        // Periodic task that sets the player as "climbing" when near a wall
        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) { cancel(); return; }
                tryClimb(player);
            }
        }.runTaskTimer(plugin, 0L, 2L).getTaskId();

        climbTasks.put(player.getUniqueId(), taskId);

        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, durationTicks, 0, false, false));
        player.getWorld().spawnParticle(Particle.CRIT_MAGIC, player.getLocation(), 20, 0.3, 0.3, 0.3, 0.05);
    }

    private void tryClimb(Player player) {
        // If the player is sneaking near a wall, push them up
        if (!player.isSneaking()) return;
        Location loc = player.getLocation();
        // Check for wall in facing direction
        Vector facing = loc.getDirection().setY(0).normalize();
        Location wallCheck = loc.clone().add(facing.multiply(0.6));
        if (wallCheck.getBlock().getType().isSolid()) {
            double speed = plugin.getConfig().getDouble("dog_powers.spider.climb_speed", 0.15);
            Vector vel = player.getVelocity();
            vel.setY(speed);
            player.setVelocity(vel);
            player.getWorld().spawnParticle(Particle.CRIT, player.getLocation(), 3, 0.1, 0.1, 0.1, 0);
        }
    }

    @Override
    public boolean useAbility(Player player) {
        // Spider ability: "Web Shot" — slow nearby enemies
        List<Entity> nearby = player.getNearbyEntities(6, 6, 6);
        for (Entity e : nearby) {
            if (e instanceof LivingEntity target && target != player) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 2, false, true));
                player.getWorld().spawnParticle(Particle.SNOWBALL, target.getLocation(), 10, 0.3, 0.5, 0.3, 0.05);
            }
        }
        player.playSound(player.getLocation(), Sound.ENTITY_SPIDER_AMBIENT, 1f, 0.6f);
        player.sendMessage(MessageUtil.color("&2[Web Shot] &fEnemies ensnared in webs!"));
        return true;
    }

    @Override
    public void deactivate(Player player) {
        Integer taskId = climbTasks.remove(player.getUniqueId());
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    @Override public int getCooldownTicks() { return cooldownTicks; }
    @Override public int getDurationTicks() { return durationTicks; }
}

// =============================================================
// GUARDIAN POWER
// =============================================================

/**
 * Guardian Power — Underwater dash at high speed.
 * Passive: Water breathing while active.
 * Ability: Launch forward underwater at high velocity.
 */
class GuardianPower implements DogPower {

    private final DogApocalypsePlugin plugin;
    private final int cooldownTicks;
    private final int durationTicks;
    private final double dashVelocity;

    GuardianPower(DogApocalypsePlugin plugin) {
        this.plugin       = plugin;
        this.cooldownTicks = plugin.getConfig().getInt("dog_powers.guardian.cooldown_ticks", 60);
        this.durationTicks = plugin.getConfig().getInt("dog_powers.guardian.duration_ticks", 240);
        this.dashVelocity  = plugin.getConfig().getDouble("dog_powers.guardian.underwater_dash_velocity", 2.2);
    }

    @Override public String getId()          { return "guardian"; }
    @Override public String getDisplayName() { return "&bGuardian Power"; }
    @Override public String getDescription() { return "Dash at speed underwater!"; }

    @Override
    public void activate(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, durationTicks, 0, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, durationTicks, 1, false, false));
        player.sendMessage(MessageUtil.color("&b[Guardian] &fAquatic power unlocked! Dash underwater at will."));
        player.playSound(player.getLocation(), Sound.ENTITY_GUARDIAN_AMBIENT, 1f, 1.2f);
    }

    @Override
    public boolean useAbility(Player player) {
        // Check in water
        if (!player.isInWater()) {
            player.sendMessage(MessageUtil.color("&7[Guardian] &cMust be underwater to dash!"));
            return false;
        }

        Vector dir = player.getEyeLocation().getDirection().normalize().multiply(dashVelocity);
        player.setVelocity(dir);
        player.getWorld().spawnParticle(Particle.WATER_SPLASH, player.getLocation(), 25, 0.3, 0.3, 0.3, 0.1);
        player.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, player.getLocation(), 20, 0.2, 0.2, 0.2, 0.1);
        player.playSound(player.getLocation(), Sound.ENTITY_DOLPHIN_JUMP, 1f, 1f);
        player.sendMessage(MessageUtil.color("&b[Aqua Dash] &fPropelling through the water!"));
        return true;
    }

    @Override
    public void deactivate(Player player) {
        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
    }

    @Override public int getCooldownTicks() { return cooldownTicks; }
    @Override public int getDurationTicks() { return durationTicks; }
}

// =============================================================
// PHANTOM POWER
// =============================================================

/**
 * Phantom Power — Silent gliding ability.
 * Passive: Player falls extremely slowly and makes no footstep sounds.
 * Ability: Launches player into the air, then activates slow-fall gliding.
 */
class PhantomPower implements DogPower {

    private final DogApocalypsePlugin plugin;
    private final int cooldownTicks;
    private final int durationTicks;
    private final double fallSpeed;

    /** Tracks players currently gliding (slow_falling effect key) */
    private final Map<UUID, Integer> glideTaskIds = new HashMap<>();

    PhantomPower(DogApocalypsePlugin plugin) {
        this.plugin       = plugin;
        this.cooldownTicks = plugin.getConfig().getInt("dog_powers.phantom.cooldown_ticks", 50);
        this.durationTicks = plugin.getConfig().getInt("dog_powers.phantom.duration_ticks", 400);
        this.fallSpeed     = plugin.getConfig().getDouble("dog_powers.phantom.glide_fall_speed", -0.08);
    }

    @Override public String getId()          { return "phantom"; }
    @Override public String getDisplayName() { return "&5Phantom Power"; }
    @Override public String getDescription() { return "Glide silently through the air!"; }

    @Override
    public void activate(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, durationTicks, 0, false, false));
        player.sendMessage(MessageUtil.color("&5[Phantom] &fYou feel weightless. Glide on your next jump!"));
        player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, player.getLocation(), 30, 0.5, 0.5, 0.5, 0.05);
    }

    @Override
    public boolean useAbility(Player player) {
        // Launch upward and enter extended glide
        player.setVelocity(player.getVelocity().setY(1.2));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 200, 1, false, false));
        player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation(), 30, 0.5, 1.0, 0.5, 0.05);
        player.playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1f, 1.4f);
        player.sendMessage(MessageUtil.color("&5[Phantom Glide] &fSoaring on spectral wings!"));
        return true;
    }

    @Override
    public void deactivate(Player player) {
        player.removePotionEffect(PotionEffectType.SLOW_FALLING);
        Integer taskId = glideTaskIds.remove(player.getUniqueId());
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    @Override public int getCooldownTicks() { return cooldownTicks; }
    @Override public int getDurationTicks() { return durationTicks; }
}

// =============================================================
// IRON GOLEM POWER
// =============================================================

/**
 * Iron Golem Power — Ground smash attack.
 * Ability: Player leaps up and smashes down, launching all nearby enemies.
 */
class IronGolemPower implements DogPower {

    private final DogApocalypsePlugin plugin;
    private final int cooldownTicks;
    private final int durationTicks;
    private final double smashRadius;
    private final double smashDamage;
    private final double knockupForce;

    IronGolemPower(DogApocalypsePlugin plugin) {
        this.plugin       = plugin;
        this.cooldownTicks = plugin.getConfig().getInt("dog_powers.iron_golem.cooldown_ticks", 100);
        this.durationTicks = plugin.getConfig().getInt("dog_powers.iron_golem.duration_ticks", 180);
        this.smashRadius   = plugin.getConfig().getDouble("dog_powers.iron_golem.smash_radius", 5.0);
        this.smashDamage   = plugin.getConfig().getDouble("dog_powers.iron_golem.smash_damage", 8.0);
        this.knockupForce  = plugin.getConfig().getDouble("dog_powers.iron_golem.smash_knockup", 1.8);
    }

    @Override public String getId()          { return "iron_golem"; }
    @Override public String getDisplayName() { return "&7Iron Golem Power"; }
    @Override public String getDescription() { return "Ground smash that launches enemies!"; }

    @Override
    public void activate(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, durationTicks, 1, false, false));
        player.sendMessage(MessageUtil.color("&7[Iron Golem] &fYour fists become like iron! Use ability to ground smash."));
        player.getWorld().spawnParticle(Particle.CRIT, player.getLocation(), 30, 0.5, 0.5, 0.5, 0.1);
    }

    @Override
    public boolean useAbility(Player player) {
        // Launch player up slightly then schedule a smash
        player.setVelocity(player.getVelocity().setY(0.8));
        player.sendMessage(MessageUtil.color("&7[Ground Smash] &fLeaping to smash!"));

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                // Wait until player starts falling
                if (ticks > 30 || (ticks > 3 && player.getVelocity().getY() < -0.2)) {
                    performSmash(player);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }

    private void performSmash(Player player) {
        World world = player.getWorld();
        Location loc = player.getLocation();

        // Visuals
        world.spawnParticle(Particle.EXPLOSION_LARGE, loc, 5, 0.5, 0.1, 0.5, 0);
        world.spawnParticle(Particle.BLOCK_CRACK, loc, 50, 1.0, 0.1, 1.0, 0.3,
                org.bukkit.Material.DIRT.createBlockData());
        world.playSound(loc, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.5f, 0.8f);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);

        // Calculate skill bonuses
        int strengthLevel = plugin.getPlayerDataManager().get(player).getSkillLevel("ability_strength");
        double bonus = 1.0 + (strengthLevel * plugin.getConfig()
                .getDouble("skill_tree.ability_strength.strength_bonus_per_level", 0.25));

        // Damage and knockup nearby entities
        List<Entity> nearby = (List<Entity>) world.getNearbyEntities(loc, smashRadius, smashRadius / 2, smashRadius);
        for (Entity entity : nearby) {
            if (!(entity instanceof LivingEntity target) || target == player) continue;

            Vector knockback = target.getLocation().subtract(loc).toVector().normalize()
                    .setY(knockupForce).multiply(1.3);
            target.setVelocity(knockback);
            ((LivingEntity) target).damage(smashDamage * bonus, player);
        }

        player.sendMessage(MessageUtil.color("&7[Smash] &fKnocked back &e"
                + nearby.stream().filter(e -> e instanceof LivingEntity && e != player).count() + " &ftargets!"));
    }

    @Override
    public void deactivate(Player player) {
        player.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
    }

    @Override public int getCooldownTicks() { return cooldownTicks; }
    @Override public int getDurationTicks() { return durationTicks; }
}
