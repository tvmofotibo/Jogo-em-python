package com.dogapocalypse.commands;

import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.levels.LevelManager;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;

// =======================================================================
// ClassCommand  —  /class choose <dog|fighter|archer>
// =======================================================================

class ClassCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    public ClassCommand(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command is player-only.");
            return true;
        }

        if (args.length < 2 || !args[0].equalsIgnoreCase("choose")) {
            player.sendMessage(MessageUtil.color("&7Usage: &e/class choose <dog|fighter|archer>"));
            showCurrentClass(player);
            return true;
        }

        PlayerClass chosen = PlayerClass.fromString(args[1]);
        if (chosen == null) {
            player.sendMessage(MessageUtil.color("&cUnknown class. Choose: &edob&c, &efighter&c, or &earcher&c."));
            return true;
        }

        plugin.getPlayerClassManager().setClass(player, chosen);
        return true;
    }

    private void showCurrentClass(Player player) {
        PlayerClass current = plugin.getPlayerClassManager().getClass(player);
        player.sendMessage(MessageUtil.color("&7Current class: " + current.getDisplayName()));
    }
}

// =======================================================================
// DogPowerCommand  —  /dogpower [info|activate]
// =======================================================================

class DogPowerCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    DogPowerCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Player only."); return true;
        }
        if (!plugin.getPlayerClassManager().isDog(player)) {
            player.sendMessage(MessageUtil.color("&cOnly the &6Dog class &ccan use this command."));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            var power = plugin.getDogPowerManager().getActivePower(player);
            if (power == null) {
                player.sendMessage(MessageUtil.color("&7You have no absorbed power."));
            } else {
                player.sendMessage(MessageUtil.color("&5[Power] &fActive: " + power.getDisplayName()));
                player.sendMessage(MessageUtil.color("&7" + power.getDescription()));
                player.sendMessage(MessageUtil.color("&7Cooldown: &e" + (power.getCooldownTicks() / 20) + "s"));
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("activate")) {
            plugin.getDogPowerManager().triggerAbility(player);
            return true;
        }

        player.sendMessage(MessageUtil.color("&7Usage: &e/dogpower [info|activate]"));
        return true;
    }
}

// =======================================================================
// DogSkillCommand  —  /dogskill [list|upgrade <skill>]
// =======================================================================

class DogSkillCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    DogSkillCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Player only."); return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            plugin.getSkillTreeManager().showSkillTree(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("upgrade") && args.length >= 2) {
            plugin.getSkillTreeManager().upgradeSkill(player, args[1].toLowerCase());
            return true;
        }

        player.sendMessage(MessageUtil.color("&7Usage: &e/dogskill [list|upgrade <skill_id>]"));
        return true;
    }
}

// =======================================================================
// LevelCommand  —  /level <start|stop|tp> <levelId>
// =======================================================================

class LevelCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    LevelCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.level")) {
            sender.sendMessage(MessageUtil.color("&cNo permission."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(MessageUtil.color("&7Usage: &e/level <start|tp> <levelId>"));
            return true;
        }

        String action  = args[0].toLowerCase();
        String levelId = args[1].toLowerCase();

        switch (action) {
            case "start" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Must be a player to start a level.");
                    return true;
                }
                var party = plugin.getCoopManager().getPartyMembers(player);
                boolean ok = plugin.getLevelManager().startLevel(levelId, party);
                if (!ok) sender.sendMessage(MessageUtil.color("&cFailed to start level: " + levelId));
            }
            case "tp" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Player only."); return true; }
                var level = plugin.getLevelManager().getLevel(levelId);
                if (level == null) { player.sendMessage(MessageUtil.color("&cUnknown level.")); return true; }
                var loc = level.getSpawnLocation();
                if (loc == null) { player.sendMessage(MessageUtil.color("&cWorld not found.")); return true; }
                player.teleport(loc);
                player.sendMessage(MessageUtil.color("&aTeleported to &e" + levelId));
            }
            default -> sender.sendMessage(MessageUtil.color("&cUnknown action."));
        }
        return true;
    }
}

// =======================================================================
// BossCommand  —  /boss <spawn|kill> <bossType>
// =======================================================================

class BossCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    BossCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.boss")) {
            sender.sendMessage(MessageUtil.color("&cNo permission.")); return true;
        }
        if (args.length < 2) {
            sender.sendMessage(MessageUtil.color("&7Usage: &e/boss <spawn|kill> <bossType>"));
            return true;
        }

        String action = args[0].toLowerCase();
        String bossId = args[1].toLowerCase();

        if (action.equals("spawn")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Player only."); return true; }
            var boss = plugin.getBossManager().spawnBoss(bossId, player.getLocation());
            if (boss == null) sender.sendMessage(MessageUtil.color("&cUnknown boss: " + bossId));
            else sender.sendMessage(MessageUtil.color("&aSpawned boss: " + bossId));
        } else if (action.equals("kill")) {
            var boss = plugin.getBossManager().getActiveBoss(bossId);
            if (boss == null) { sender.sendMessage(MessageUtil.color("&cNo active boss: " + bossId)); return true; }
            if (boss.isAlive()) boss.getEntity().setHealth(0);
            sender.sendMessage(MessageUtil.color("&aKilled boss: " + bossId));
        }
        return true;
    }
}

// =======================================================================
// StoryCommand  —  /story <progress|reset>
// =======================================================================

class StoryCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    StoryCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("dogapocalypse.admin.story")) {
            sender.sendMessage(MessageUtil.color("&cNo permission.")); return true;
        }
        if (args.length == 0) {
            sender.sendMessage(MessageUtil.color("&7Usage: &e/story <progress|reset> [player]"));
            return true;
        }

        Player target = (args.length >= 2) ? Bukkit.getPlayer(args[1]) : (sender instanceof Player p ? p : null);
        if (target == null) { sender.sendMessage(MessageUtil.color("&cPlayer not found.")); return true; }

        if (args[0].equalsIgnoreCase("progress")) {
            plugin.getDialogueManager().unlockNextFragment(target);
            sender.sendMessage(MessageUtil.color("&aUnlocked next fragment for " + target.getName()));
        } else if (args[0].equalsIgnoreCase("reset")) {
            plugin.getPlayerDataManager().get(target).setStoryFragments(0);
            sender.sendMessage(MessageUtil.color("&aReset story for " + target.getName()));
        } else {
            sender.sendMessage(MessageUtil.color("&cUnknown action."));
        }
        return true;
    }
}

// =======================================================================
// CoopCommand  —  /coop <invite|accept|leave|status>
// =======================================================================

class CoopCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    CoopCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only."); return true; }
        if (args.length == 0) {
            player.sendMessage(MessageUtil.color("&7Usage: &e/coop <invite|accept|leave|status>"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "invite" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.color("&7/coop invite <player>")); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) { player.sendMessage(MessageUtil.color("&cPlayer not found.")); return true; }
                plugin.getCoopManager().invitePlayer(player, target);
            }
            case "accept" -> plugin.getCoopManager().acceptInvite(player);
            case "leave"  -> plugin.getCoopManager().leaveParty(player);
            case "status" -> {
                List<Player> members = plugin.getCoopManager().getPartyMembers(player);
                player.sendMessage(MessageUtil.color("&6Party members (" + members.size() + "):"));
                members.forEach(m -> player.sendMessage(MessageUtil.color("  &7- &f" + m.getName()
                        + " &8[" + plugin.getPlayerClassManager().getClass(m).getDisplayName() + "&8]")));
            }
            default -> player.sendMessage(MessageUtil.color("&cUnknown sub-command."));
        }
        return true;
    }
}

// =======================================================================
// ReviveCommand  —  /revive <player>
// =======================================================================

class ReviveCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    ReviveCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player reviver)) { sender.sendMessage("Player only."); return true; }

        if (args.length < 1) {
            Player nearby = plugin.getReviveSystem().findNearbyDowned(reviver);
            if (nearby == null) {
                reviver.sendMessage(MessageUtil.color("&7No downed player nearby."));
            } else {
                plugin.getReviveSystem().progressRevive(reviver, nearby);
            }
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !plugin.getReviveSystem().isDown(target)) {
            reviver.sendMessage(MessageUtil.color("&cThat player is not downed."));
            return true;
        }
        if (reviver.getLocation().distance(target.getLocation()) > plugin.getConfig()
                .getDouble("coop.revive_range_blocks", 3.0)) {
            reviver.sendMessage(MessageUtil.color("&cYou are too far away to revive."));
            return true;
        }

        // Force-complete revive for admin speed (stand and wait normally)
        plugin.getReviveSystem().progressRevive(reviver, target);
        return true;
    }
}
