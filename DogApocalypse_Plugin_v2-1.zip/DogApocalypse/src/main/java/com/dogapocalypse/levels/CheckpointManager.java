package com.dogapocalypse.levels;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * CheckpointManager — saves and restores player respawn points.
 *
 * BUG FIX v2:
 *  - setCheckpoints() replaces initCheckpoints() to work with WorldGenerator
 *  - getRespawnLocation() now safely falls back to world spawn
 *  - checkPlayerCheckpoints() uses squared distance to avoid sqrt calls
 */
public class CheckpointManager {

    private final DogApocalypsePlugin plugin;
    private final Map<String, List<Location>> levelCheckpoints = new HashMap<>();
    private final Map<UUID, Location> playerCheckpoints = new HashMap<>();

    public CheckpointManager(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    // ----------------------------------------------------------------
    // Set checkpoints (called from LevelManager.syncWithWorldGenerator)
    // ----------------------------------------------------------------

    public void setCheckpoints(String levelId, List<Location> checkpoints) {
        levelCheckpoints.put(levelId, new ArrayList<>(checkpoints));
    }

    /** Legacy init (still usable for manual setup) */
    public void initCheckpoints(String levelId, Location spawn, int count) {
        List<Location> cps = new ArrayList<>();
        for (int i = 1; i <= count; i++)
            cps.add(spawn.clone().add(0, 0, i * 40));
        levelCheckpoints.put(levelId, cps);
    }

    // ----------------------------------------------------------------
    // Player checkpoint detection (called from LevelListener)
    // ----------------------------------------------------------------

    public void checkPlayerCheckpoints(Player player, String levelId) {
        List<Location> checkpoints = levelCheckpoints.get(levelId);
        if (checkpoints == null || checkpoints.isEmpty()) return;

        Location playerLoc = player.getLocation();
        for (Location cp : checkpoints) {
            // BUG FIX: check same world before calling distance
            if (cp.getWorld() == null || !cp.getWorld().equals(playerLoc.getWorld())) continue;
            if (playerLoc.distanceSquared(cp) <= 6.25) { // 2.5 blocks squared
                Location last = playerCheckpoints.get(player.getUniqueId());
                if (last == null || last.distanceSquared(cp) > 0.01) {
                    activateCheckpoint(player, cp);
                }
                break;
            }
        }
    }

    private void activateCheckpoint(Player player, Location location) {
        playerCheckpoints.put(player.getUniqueId(), location.clone());

        String particleName = plugin.getConfig().getString("effects.checkpoint_particle", "VILLAGER_HAPPY");
        Particle particle;
        try { particle = Particle.valueOf(particleName); }
        catch (Exception e) { particle = Particle.HAPPY_VILLAGER; }

        player.getWorld().spawnParticle(particle, location.clone().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.05);
        player.getWorld().playSound(location, Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 2f);
        player.sendMessage(MessageUtil.color("&a✔ &fCheckpoint saved!"));
        player.sendActionBar(MessageUtil.color("&a✔ Checkpoint"));
    }

    // ----------------------------------------------------------------
    // Respawn
    // ----------------------------------------------------------------

    public Location getRespawnLocation(Player player, String levelId) {
        Location cp = playerCheckpoints.get(player.getUniqueId());
        if (cp != null && cp.getWorld() != null) return cp.clone();

        // BUG FIX: safe fallback — use level spawn if available, else world spawn
        var levelData = plugin.getLevelManager().getLevel(levelId);
        if (levelData != null && levelData.getSpawnLocation() != null) {
            return levelData.getSpawnLocation().clone();
        }
        return player.getWorld().getSpawnLocation();
    }

    public void clearPlayer(UUID uuid)     { playerCheckpoints.remove(uuid); }
    public void clearLevel(String levelId) { levelCheckpoints.remove(levelId); }
}
