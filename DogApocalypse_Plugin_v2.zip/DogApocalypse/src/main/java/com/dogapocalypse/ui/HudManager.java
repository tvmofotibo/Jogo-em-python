package com.dogapocalypse.ui;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * HudManager — sends a persistent action bar HUD to all online players every second.
 *
 * Format:
 *   [Class] ❤ HP  |  ⚡ Power: BlazePower  |  SP: 5
 */
public class HudManager {

    private final DogApocalypsePlugin plugin;
    private int taskId = -1;

    public HudManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        startHudTask();
    }

    private void startHudTask() {
        taskId = new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    sendHud(p);
                }
            }
        }.runTaskTimer(plugin, 20L, 20L).getTaskId();
    }

    private void sendHud(Player player) {
        if (!player.isOnline()) return;

        var data = plugin.getPlayerDataManager().get(player);
        PlayerClass cls = data.getPlayerClass();

        // Class label
        String classLabel = cls.getDisplayName();

        // Health bar
        double hp = player.getHealth();
        double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue();
        int hpBars = (int)((hp / maxHp) * 10);
        String hpBar = "&c" + "❤".repeat(Math.max(0, hpBars))
                     + "&8" + "❤".repeat(Math.max(0, 10 - hpBars));

        // Power (Dog only)
        String powerInfo = "";
        if (cls == PlayerClass.DOG) {
            var power = plugin.getDogPowerManager().getActivePower(player);
            powerInfo = power != null
                    ? " &8| &5⚡ " + power.getDisplayName()
                    : " &8| &8⚡ No Power";
        }

        // Skill points
        String spInfo = " &8| &eSP: " + data.getSkillPoints();

        // Downed indicator
        String downedInfo = plugin.getReviveSystem().isDown(player) ? " &c&l[DOWNED]" : "";

        String hud = classLabel + " " + hpBar + powerInfo + spInfo + downedInfo;
        player.sendActionBar(MessageUtil.color(hud));
    }

    public void stop() {
        if (taskId != -1) {
            plugin.getServer().getScheduler().cancelTask(taskId);
            taskId = -1;
        }
    }
}
