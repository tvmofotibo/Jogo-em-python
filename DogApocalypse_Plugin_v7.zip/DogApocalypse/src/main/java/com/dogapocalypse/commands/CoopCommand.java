package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.List;

public class CoopCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public CoopCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
        if (args.length == 0) { player.sendMessage(MessageUtil.color("&7Usage: &e/coop <invite|accept|leave|status>")); return true; }

        switch (args[0].toLowerCase()) {
            case "invite" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.color("&7/coop invite <player>")); return true; }
                Player t = Bukkit.getPlayer(args[1]);
                if (t == null) { player.sendMessage(MessageUtil.color("&cJogador não encontrado.")); return true; }
                plugin.getCoopManager().invitePlayer(player, t);
            }
            case "accept" -> plugin.getCoopManager().acceptInvite(player);
            case "leave"  -> plugin.getCoopManager().leaveParty(player);
            case "status" -> {
                List<Player> members = plugin.getCoopManager().getPartyMembers(player);
                player.sendMessage(MessageUtil.color("&6Party (" + members.size() + "):"));
                for (Player m : members)
                    player.sendMessage(MessageUtil.color("  &7- &f" + m.getName()
                        + " &8[" + plugin.getPlayerClassManager().getClass(m).getDisplayName() + "&8]"));
            }
            default -> player.sendMessage(MessageUtil.color("&cUnknown sub-command."));
        }
        return true;
    }
}
