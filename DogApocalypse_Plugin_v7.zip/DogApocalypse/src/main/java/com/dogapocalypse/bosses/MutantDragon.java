package com.dogapocalypse.bosses;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Mutant Dragon — 3-phase final boss.
 *
 * Phase 1 (100% → 66%): Ground combat, tail sweep, fire breath.
 * Phase 2 (66% → 33%):  Becomes enraged, spawns mutant insect minions, flame dive.
 * Phase 3 (33% → 0%):   Goes airborne, massive fire storm, wing buffet.
 */
public class MutantDragon extends AbstractBoss {

    private BossBar bossBar;
    private final List<Player> arenaPlayers = new ArrayList<>();

    // Attack cooldowns per phase
    private int attackCooldown = 0;
    private static final int PHASE1_ATTACK_INTERVAL = 60;  // 3s
    private static final int PHASE2_ATTACK_INTERVAL = 40;  // 2s
    private static final int PHASE3_ATTACK_INTERVAL = 30;  // 1.5s

    public MutantDragon(DogApocalypsePlugin plugin) {
        super(plugin, "mutant_dragon", "&4Mutant Dragon");
        this.maxHealth = plugin.getConfig().getDouble("bosses.mutant_dragon.health", 500.0);
        this.phaseThresholds = Arrays.asList(0.66, 0.33);
    }

    @Override
    public LivingEntity spawn(Location location) {
        EnderDragon dragon = (EnderDragon) location.getWorld().spawnEntity(location, EntityType.ENDER_DRAGON);

        // Configure
        dragon.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        dragon.setCustomNameVisible(true);

        var health = dragon.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (health != null) {
            health.setBaseValue(maxHealth);
            dragon.setHealth(maxHealth);
        }

        this.entity = dragon;
        this.isActive = true;

        // Boss bar
        bossBar = plugin.getServer().createBossBar(
                MessageUtil.color(displayName),
                BarColor.RED, BarStyle.SEGMENTED_10);
        bossBar.setVisible(true);

        // Find nearby players for arena
        for (Player p : location.getWorld().getPlayers()) {
            if (p.getLocation().distance(location) <= 50) {
                arenaPlayers.add(p);
                bossBar.addPlayer(p);
                p.sendMessage(MessageUtil.color("&4&l⚔ THE MUTANT DRAGON HAS AWAKENED! ⚔"));
                p.sendTitle(
                        MessageUtil.color("&4&lMUTANT DRAGON"),
                        MessageUtil.color("&cPrepare for annihilation..."),
                        10, 60, 20);
            }
        }

        // Spawn animation
        EffectUtil.spawnParticleCircle(location, Particle.EXPLOSION_LARGE, 20, 8.0);
        location.getWorld().playSound(location, Sound.ENTITY_ENDER_DRAGON_GROWL, 3f, 0.6f);

        return dragon;
    }

    @Override
    public void tick() {
        if (!isAlive()) return;

        tickCounter++;
        checkPhaseTransition();
        updateBossBar();

        attackCooldown++;
        int interval = switch (currentPhase) {
            case 1 -> PHASE2_ATTACK_INTERVAL;
            case 2 -> PHASE3_ATTACK_INTERVAL;
            default -> PHASE1_ATTACK_INTERVAL;
        };

        if (attackCooldown >= interval) {
            executePhaseAttack();
            attackCooldown = 0;
        }
    }

    @Override
    public void transitionToPhase(int newPhase) {
        Location loc = getLocation();
        if (loc == null) return;

        // Announce
        String msg = switch (newPhase) {
            case 1 -> "&4&l[PHASE 2] &cThe Dragon is enraged! Minions incoming!";
            case 2 -> "&4&l[PHASE 3] &cThe Dragon takes flight! FINAL PHASE!";
            default -> "&4Phase transition.";
        };

        for (Player p : arenaPlayers) {
            if (p.isOnline()) {
                p.sendMessage(MessageUtil.color(msg));
                p.sendTitle(
                        MessageUtil.color("&4PHASE " + (newPhase + 1)),
                        MessageUtil.color("&c" + (newPhase == 1 ? "ENRAGED" : "FINAL STAND")),
                        5, 40, 10);
            }
        }

        // Effect
        EffectUtil.spawnParticleCircle(loc, Particle.EXPLOSION_NORMAL, 60, 6.0);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_GROWL, 2f, 0.5f + (newPhase * 0.3f));

        // Phase 2: spawn minions
        if (newPhase == 1) {
            spawnMinions(loc, 5);
            entity.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 1));
        }

        // Phase 3: give speed
        if (newPhase == 2) {
            entity.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 2));
            bossBar.setColor(BarColor.PURPLE);
        }
    }

    @Override
    public void executePhaseAttack() {
        if (!isAlive()) return;
        Location loc = getLocation();
        if (loc == null) return;

        switch (currentPhase) {
            case 0 -> phase1Attack(loc);
            case 1 -> phase2Attack(loc);
            case 2 -> phase3Attack(loc);
        }
    }

    // Phase 1: Fire breath + tail sweep
    private void phase1Attack(Location loc) {
        // Tail sweep: knock back all nearby players
        if (tickCounter % 2 == 0) {
            for (Player p : arenaPlayers) {
                if (!p.isOnline() || p.isDead()) continue;
                if (p.getLocation().distance(loc) < 10) {
                    Vector kb = p.getLocation().subtract(loc).toVector().setY(0.5).normalize().multiply(1.8);
                    p.setVelocity(kb);
                    p.damage(5.0, entity);
                    loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, p.getLocation(), 3, 0.2, 0.2, 0.2, 0);
                }
            }
        } else {
            // Fire breath at nearest player
            Player nearest = getNearestPlayer(loc, 20);
            if (nearest != null) fireBreathAt(loc, nearest);
        }
    }

    // Phase 2: Flame dive + minion reinforcements
    private void phase2Attack(Location loc) {
        if (tickCounter % 3 == 0) {
            spawnMinions(loc, 2);
        }
        Player target = getNearestPlayer(loc, 30);
        if (target != null) {
            // Dive at player
            Vector dive = target.getLocation().subtract(loc).toVector().normalize().multiply(2.5);
            entity.setVelocity(dive);
            loc.getWorld().spawnParticle(Particle.FLAME, loc, 30, 1.0, 1.0, 1.0, 0.1);
            loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_FLAP, 2f, 0.8f);
        }
    }

    // Phase 3: Fire storm
    private void phase3Attack(Location loc) {
        // Fire storm: rain fire down around arena
        for (Player p : arenaPlayers) {
            if (!p.isOnline() || p.isDead()) continue;
            Location pLoc = p.getLocation();
            for (int i = 0; i < 5; i++) {
                double ox = (Math.random() - 0.5) * 8;
                double oz = (Math.random() - 0.5) * 8;
                Location fireLoc = pLoc.clone().add(ox, 15, oz);
                Fireball fireball = (Fireball) loc.getWorld().spawnEntity(fireLoc, EntityType.FIREBALL);
                fireball.setDirection(new Vector(0, -1, 0).normalize());
                fireball.setShooter(entity);
            }
        }
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_SHOOT, 2f, 0.7f);
    }

    @Override
    public void onDeath(List<Player> participants) {
        Location loc = getLocation();

        // Grand explosion sequence
        if (loc != null) {
            new BukkitRunnable() {
                int i = 0;
                @Override
                public void run() {
                    if (i++ >= 10) { cancel(); return; }
                    Location offsetLoc = loc.clone().add(
                            (Math.random() - 0.5) * 8, Math.random() * 4, (Math.random() - 0.5) * 8);
                    loc.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, offsetLoc, 1, 0, 0, 0, 0);
                    loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.6f);
                }
            }.runTaskTimer(plugin, 0L, 8L);
        }

        // Remove boss bar
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar.setVisible(false);
        }

        // Reward all participants
        for (Player p : participants) {
            if (!p.isOnline()) continue;
            p.sendMessage(MessageUtil.color("&6&l★ MUTANT DRAGON DEFEATED! ★"));
            p.sendTitle(MessageUtil.color("&6VICTORY"), MessageUtil.color("&eThe Mutant Dragon is slain!"), 10, 80, 20);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            plugin.getPlayerDataManager().get(p).addExperience(500);
            plugin.getPlayerDataManager().get(p).addSkillPoints(5);
        }

        isActive = false;
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private void fireBreathAt(Location from, Player target) {
        Vector dir = target.getLocation().subtract(from).toVector().normalize();
        for (double d = 0; d <= 12; d += 0.5) {
            Location fireLoc = from.clone().add(dir.clone().multiply(d));
            fireLoc.getWorld().spawnParticle(Particle.FLAME, fireLoc, 3, 0.2, 0.2, 0.2, 0.02);
        }
        if (target.getLocation().distance(from) < 12) {
            target.setFireTicks(100);
            target.damage(6.0, entity);
        }
        from.getWorld().playSound(from, Sound.ENTITY_ENDER_DRAGON_SHOOT, 1f, 1.2f);
    }

    private void spawnMinions(Location loc, int count) {
        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            double ox = Math.cos(angle) * 5;
            double oz = Math.sin(angle) * 5;
            Location spawnLoc = loc.clone().add(ox, 0, oz);
            plugin.getEnemyManager().spawnEnemy("flame_blaze", spawnLoc);
        }
    }

    private Player getNearestPlayer(Location from, double maxDist) {
        Player nearest = null;
        double minDist = maxDist;
        for (Player p : arenaPlayers) {
            if (!p.isOnline() || p.isDead()) continue;
            double d = p.getLocation().distance(from);
            if (d < minDist) { minDist = d; nearest = p; }
        }
        return nearest;
    }

    private void updateBossBar() {
        if (bossBar == null || !isAlive()) return;
        bossBar.setProgress(Math.max(0, Math.min(1, getHealthPercent())));
    }

    public List<Player> getArenaPlayers() { return arenaPlayers; }
}
