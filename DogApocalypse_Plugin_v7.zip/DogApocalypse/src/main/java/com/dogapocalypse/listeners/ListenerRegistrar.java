package com.dogapocalypse.listeners;

import com.dogapocalypse.core.DogApocalypsePlugin;

/**
 * Public entry point for registering all listeners.
 * All listener classes in this package are package-private (multi-class file),
 * so this registrar acts as the public bridge.
 */
public class ListenerRegistrar {

    public static void registerAll(DogApocalypsePlugin plugin) {
        var pm = plugin.getServer().getPluginManager();
        pm.registerEvents(new PlayerJoinQuitListener(plugin), plugin);
        pm.registerEvents(new DogAbilityListener(plugin), plugin);
        pm.registerEvents(new CombatListener(plugin), plugin);
        pm.registerEvents(new CoopListener(plugin), plugin);
        pm.registerEvents(new LevelListener(plugin), plugin);
        pm.registerEvents(new BossListener(plugin), plugin);
        pm.registerEvents(new EnemyListener(plugin), plugin);
        pm.registerEvents(new StoryListener(plugin), plugin);
        pm.registerEvents(new PlayerMovementListener(plugin), plugin);
    }
}
