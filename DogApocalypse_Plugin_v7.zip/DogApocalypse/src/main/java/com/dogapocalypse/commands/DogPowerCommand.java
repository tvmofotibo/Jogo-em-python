package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DogPowerCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public DogPowerCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
        if (!plugin.getPlayerClassManager().isDog(player)) {
            player.sendMessage(MessageUtil.color("&cApenas a classe Cão pode usar isso.")); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            var power = plugin.getDogPowerManager().getActivePower(player);
            if (power == null) player.sendMessage(MessageUtil.color("&7Sem poder absorvido."));
            else {
                player.sendMessage(MessageUtil.color("&5[Power] &f" + power.getDisplayName()));
                player.sendMessage(MessageUtil.color("&7" + power.getDescription()));
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("activate")) { plugin.getDogPowerManager().triggerAbility(player); return true; }
        player.sendMessage(MessageUtil.color("&7Usage: &e/dogpower [info|activate]"));
        return true;
    }
}
