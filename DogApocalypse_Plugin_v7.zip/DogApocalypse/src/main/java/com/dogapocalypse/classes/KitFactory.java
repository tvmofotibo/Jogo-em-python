package com.dogapocalypse.classes;

import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

/**
 * Factory that builds and gives starter item kits to each class.
 */
public final class KitFactory {

    private KitFactory() {}

    // ----------------------------------------------------------------
    // Dog Kit
    // ----------------------------------------------------------------

    public static void giveDogKit(Player player) {
        // Slot 0: Fangs (Iron Sword styled as fangs)
        ItemStack fangs = buildItem(Material.IRON_SWORD, "&6Mutant Fangs",
                Arrays.asList("&7The fangs of a post-apocalyptic predator.",
                              "&8Deal &c+2 &8bonus damage."),
                Enchantment.DAMAGE_ALL, 2);

        // Slot 1: Power Absorber (Totem - activates absorbed power)
        ItemStack absorber = buildItem(Material.TOTEM_OF_UNDYING, "&5Power Absorber",
                Arrays.asList("&7Absorb the essence of fallen foes.",
                              "&8Right-click to activate absorbed power."),
                null, 0);

        // Slot 2: Dash Bone (Bone - triggers dash)
        ItemStack dashBone = buildItem(Material.BONE, "&bDash Bone",
                Arrays.asList("&7The mutated bones hum with kinetic energy.",
                              "&8Right-click to dash forward."),
                null, 0);

        player.getInventory().setItem(0, fangs);
        player.getInventory().setItem(1, absorber);
        player.getInventory().setItem(2, dashBone);
    }

    // ----------------------------------------------------------------
    // Fighter Kit
    // ----------------------------------------------------------------

    public static void giveFighterKit(Player player) {
        // Slot 0: War Blade
        ItemStack warBlade = buildItem(Material.DIAMOND_SWORD, "&cWar Blade",
                Arrays.asList("&7Forged from the ruins of civilization.",
                              "&8Deal &c+4 &8bonus melee damage."),
                Enchantment.DAMAGE_ALL, 3);

        // Slot 1: Mutant Shield
        ItemStack shield = buildItem(Material.SHIELD, "&7Mutant Shield",
                Arrays.asList("&7A reinforced scrap-metal shield.",
                              "&8Block attacks to reduce damage by 35%."),
                Enchantment.PROTECTION_ENVIRONMENTAL, 2);

        player.getInventory().setItem(0, warBlade);
        player.getInventory().setItem(1, shield);
        player.getInventory().setHeldItemSlot(0);
    }

    // ----------------------------------------------------------------
    // Archer Kit
    // ----------------------------------------------------------------

    public static void giveArcherKit(Player player) {
        // Slot 0: Mutant Bow
        ItemStack bow = buildItem(Material.BOW, "&aMutant Bow",
                Arrays.asList("&7Crafted from irradiated wood and sinew.",
                              "&8Rapid fire with &a+3 &8bonus arrow damage."),
                Enchantment.ARROW_DAMAGE, 3);

        // Slot 1: Arrow bundle
        ItemStack arrows = new ItemStack(Material.ARROW, 64);
        ItemMeta arrowMeta = arrows.getItemMeta();
        if (arrowMeta != null) {
            arrowMeta.setDisplayName(MessageUtil.color("&7Irradiated Arrows"));
            arrows.setItemMeta(arrowMeta);
        }

        player.getInventory().setItem(0, bow);
        player.getInventory().setItem(1, arrows);
        player.getInventory().setHeldItemSlot(0);
    }

    // ----------------------------------------------------------------
    // Utility
    // ----------------------------------------------------------------

    private static ItemStack buildItem(Material material, String name, List<String> lore,
                                       Enchantment enchantment, int enchLevel) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(MessageUtil.color(name));
            List<String> coloredLore = lore.stream()
                    .map(MessageUtil::color)
                    .toList();
            meta.setLore(coloredLore);
            if (enchantment != null && enchLevel > 0) {
                meta.addEnchant(enchantment, enchLevel, true);
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
