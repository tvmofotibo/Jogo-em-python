package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.menu.MenuPrincipal;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/** /menu — abre o menu principal do jogo. */
public class MenuCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    public MenuCommand(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Apenas jogadores podem usar este comando.");
            return true;
        }
        MenuPrincipal.abrir(player, plugin);
        return true;
    }
}
