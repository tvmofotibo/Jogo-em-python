package com.dogapocalypse.coop;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * CoopManager — handles party creation, invitations, and membership.
 * Maximum party size is configured in config.yml (max_party_size).
 */
public class CoopManager {

    private final DogApocalypsePlugin plugin;

    /** Party leader UUID -> Set of member UUIDs (includes leader) */
    private final Map<UUID, Set<UUID>> parties = new HashMap<>();

    /** Member UUID -> leader UUID (reverse lookup) */
    private final Map<UUID, UUID> memberToLeader = new HashMap<>();

    /** Pending invites: invitee UUID -> inviter UUID */
    private final Map<UUID, UUID> pendingInvites = new HashMap<>();

    private final int maxPartySize;

    public CoopManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        this.maxPartySize = plugin.getConfig().getInt("general.max_party_size", 4);
    }

    // ----------------------------------------------------------------
    // Party management
    // ----------------------------------------------------------------

    public boolean createParty(Player leader) {
        if (isInParty(leader)) {
            leader.sendMessage(MessageUtil.color("&cYou are already in a party."));
            return false;
        }
        Set<UUID> members = new LinkedHashSet<>();
        members.add(leader.getUniqueId());
        parties.put(leader.getUniqueId(), members);
        memberToLeader.put(leader.getUniqueId(), leader.getUniqueId());
        leader.sendMessage(MessageUtil.color("&aParty created! Invite up to " + (maxPartySize - 1) + " players."));
        return true;
    }

    public void invitePlayer(Player leader, Player invitee) {
        if (!isPartyLeader(leader)) {
            if (!isInParty(leader)) createParty(leader);
        }
        UUID leaderUUID = leader.getUniqueId();
        Set<UUID> party = parties.get(leaderUUID);
        if (party == null) { createParty(leader); party = parties.get(leaderUUID); }

        if (party.size() >= maxPartySize) {
            leader.sendMessage(MessageUtil.color("&cParty is full (" + maxPartySize + " players max)."));
            return;
        }
        if (isInParty(invitee)) {
            leader.sendMessage(MessageUtil.color("&c" + invitee.getName() + " is already in a party."));
            return;
        }

        pendingInvites.put(invitee.getUniqueId(), leaderUUID);
        invitee.sendMessage(MessageUtil.color("&6[Coop] &f" + leader.getName()
                + " invited you to their party! Type &e/coop accept &fto join."));
        leader.sendMessage(MessageUtil.color("&aInvite sent to " + invitee.getName() + "."));

        // Auto-expire invite after 30s
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (pendingInvites.get(invitee.getUniqueId()) != null &&
                    pendingInvites.get(invitee.getUniqueId()).equals(leaderUUID)) {
                pendingInvites.remove(invitee.getUniqueId());
            }
        }, 600L);
    }

    public boolean acceptInvite(Player invitee) {
        UUID leaderUUID = pendingInvites.remove(invitee.getUniqueId());
        if (leaderUUID == null) {
            invitee.sendMessage(MessageUtil.color("&cNo pending invite."));
            return false;
        }
        Set<UUID> party = parties.get(leaderUUID);
        if (party == null || party.size() >= maxPartySize) {
            invitee.sendMessage(MessageUtil.color("&cParty no longer available."));
            return false;
        }

        party.add(invitee.getUniqueId());
        memberToLeader.put(invitee.getUniqueId(), leaderUUID);

        Player leader = Bukkit.getPlayer(leaderUUID);
        String leaderName = leader != null ? leader.getName() : "Unknown";
        invitee.sendMessage(MessageUtil.color("&aYou joined " + leaderName + "'s party!"));
        broadcastToParty(leaderUUID, "&a" + invitee.getName() + " joined the party!");
        return true;
    }

    public void leaveParty(Player player) {
        UUID uuid = player.getUniqueId();
        UUID leaderUUID = memberToLeader.remove(uuid);
        if (leaderUUID == null) {
            player.sendMessage(MessageUtil.color("&cYou are not in a party."));
            return;
        }

        Set<UUID> party = parties.get(leaderUUID);
        if (party != null) {
            party.remove(uuid);
            if (party.isEmpty() || uuid.equals(leaderUUID)) {
                // Dissolve party
                party.forEach(m -> memberToLeader.remove(m));
                parties.remove(leaderUUID);
                broadcastToParty(leaderUUID, "&cParty dissolved (leader left).");
            } else {
                broadcastToParty(leaderUUID, "&e" + player.getName() + " left the party.");
            }
        }

        player.sendMessage(MessageUtil.color("&eYou left the party."));
    }

    // ----------------------------------------------------------------
    // Queries
    // ----------------------------------------------------------------

    public boolean isInParty(Player p) { return memberToLeader.containsKey(p.getUniqueId()); }
    public boolean isPartyLeader(Player p) { return parties.containsKey(p.getUniqueId()); }

    public List<Player> getPartyMembers(Player p) {
        UUID leaderUUID = memberToLeader.get(p.getUniqueId());
        if (leaderUUID == null) return Collections.singletonList(p);
        Set<UUID> party = parties.get(leaderUUID);
        if (party == null) return Collections.singletonList(p);
        List<Player> members = new ArrayList<>();
        for (UUID uuid : party) {
            Player member = Bukkit.getPlayer(uuid);
            if (member != null && member.isOnline()) members.add(member);
        }
        return members;
    }

    public void broadcastToParty(UUID leaderUUID, String msg) {
        Set<UUID> party = parties.get(leaderUUID);
        if (party == null) return;
        for (UUID uuid : party) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) p.sendMessage(MessageUtil.color(msg));
        }
    }

    public void cleanupPlayer(UUID uuid) {
        pendingInvites.remove(uuid);
        UUID leaderUUID = memberToLeader.remove(uuid);
        if (leaderUUID != null) {
            Set<UUID> party = parties.get(leaderUUID);
            if (party != null) {
                party.remove(uuid);
                if (party.isEmpty() || uuid.equals(leaderUUID)) {
                    party.forEach(m -> memberToLeader.remove(m));
                    parties.remove(leaderUUID);
                }
            }
        }
    }
}
