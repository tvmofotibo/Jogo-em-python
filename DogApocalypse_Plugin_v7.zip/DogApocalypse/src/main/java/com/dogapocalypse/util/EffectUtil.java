package com.dogapocalypse.util;

import org.bukkit.*;

/**
 * Utility methods for spawning visual effects.
 */
public final class EffectUtil {

    private EffectUtil() {}

    /**
     * Spawns a ring of particles in a horizontal circle around a location.
     */
    public static void spawnParticleCircle(Location center, Particle particle, int count, double radius) {
        World world = center.getWorld();
        if (world == null) return;

        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            double x = center.getX() + Math.cos(angle) * radius;
            double z = center.getZ() + Math.sin(angle) * radius;
            Location loc = new Location(world, x, center.getY() + 0.5, z);
            world.spawnParticle(particle, loc, 1, 0, 0, 0, 0);
        }
    }

    /**
     * Spawns a burst of particles at a location in a sphere pattern.
     */
    public static void spawnParticleSphere(Location center, Particle particle, int count, double radius) {
        World world = center.getWorld();
        if (world == null) return;

        for (int i = 0; i < count; i++) {
            double phi   = Math.acos(2 * Math.random() - 1);
            double theta = 2 * Math.PI * Math.random();
            double x = center.getX() + radius * Math.sin(phi) * Math.cos(theta);
            double y = center.getY() + radius * Math.cos(phi);
            double z = center.getZ() + radius * Math.sin(phi) * Math.sin(theta);
            world.spawnParticle(particle, x, y, z, 1, 0, 0, 0, 0);
        }
    }
}
