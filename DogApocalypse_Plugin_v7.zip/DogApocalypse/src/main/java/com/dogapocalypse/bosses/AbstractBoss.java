package com.dogapocalypse.bosses;

import com.dogapocalypse.core.DogApocalypsePlugin;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Abstract base class for all DogApocalypse bosses.
 *
 * Bosses have:
 * - Multiple phases, triggered by health thresholds
 * - Per-phase special attacks
 * - Minion spawning
 * - Cinematic transitions
 */
public abstract class AbstractBoss {

    protected final DogApocalypsePlugin plugin;
    protected final String bossId;
    protected final String displayName;

    protected LivingEntity entity;
    protected double maxHealth;
    protected int currentPhase = 0;
    protected List<Double> phaseThresholds; // fraction of max health (e.g. 0.66, 0.33)

    protected int tickCounter = 0;
    protected boolean isActive = false;
    protected boolean transitioningPhase = false;

    protected AbstractBoss(DogApocalypsePlugin plugin, String bossId, String displayName) {
        this.plugin      = plugin;
        this.bossId      = bossId;
        this.displayName = displayName;
    }

    // ----------------------------------------------------------------
    // Lifecycle
    // ----------------------------------------------------------------

    /**
     * Spawn this boss at the given location.
     */
    public abstract LivingEntity spawn(Location location);

    /**
     * Called every 20 ticks by BossManager.
     */
    public abstract void tick();

    /**
     * Transition to the next phase. Called automatically when health crosses threshold.
     */
    public abstract void transitionToPhase(int newPhase);

    /**
     * Execute a special attack for the current phase.
     */
    public abstract void executePhaseAttack();

    /**
     * Called when the boss dies.
     */
    public abstract void onDeath(List<Player> participants);

    // ----------------------------------------------------------------
    // Phase management
    // ----------------------------------------------------------------

    /**
     * Check if phase transition should occur and trigger it.
     */
    protected void checkPhaseTransition() {
        if (entity == null || transitioningPhase) return;

        double healthFraction = entity.getHealth() / maxHealth;
        int nextPhase = currentPhase + 1;

        if (nextPhase < phaseThresholds.size()
                && healthFraction <= phaseThresholds.get(currentPhase)) {
            transitioningPhase = true;
            transitionToPhase(nextPhase);
            currentPhase = nextPhase;
            transitioningPhase = false;
        }
    }

    // ----------------------------------------------------------------
    // Getters
    // ----------------------------------------------------------------

    public String getBossId()       { return bossId; }
    public String getDisplayName()  { return displayName; }
    public LivingEntity getEntity() { return entity; }
    public int getCurrentPhase()    { return currentPhase; }
    public boolean isActive()       { return isActive; }

    public boolean isAlive() {
        return entity != null && !entity.isDead() && entity.isValid();
    }

    public Location getLocation() {
        return entity != null ? entity.getLocation() : null;
    }

    public double getHealthPercent() {
        if (entity == null || maxHealth <= 0) return 0;
        return entity.getHealth() / maxHealth;
    }
}
