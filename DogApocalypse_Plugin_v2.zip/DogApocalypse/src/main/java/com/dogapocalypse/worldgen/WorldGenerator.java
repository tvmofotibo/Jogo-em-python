package com.dogapocalypse.worldgen;

import com.dogapocalypse.core.DogApocalypsePlugin;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.function.Consumer;

/**
 * WorldGenerator — Procedurally generates all 4 level arenas.
 *
 * Each level is generated asynchronously in chunks to avoid server lag.
 * Generation happens in a dedicated world named "dogapocalypse_levels".
 *
 * Layout per level (all generated on Y=64 baseline):
 *   [SPAWN PLATFORM] → [PLATFORMS + ENEMIES] × waves → [CHECKPOINT] → [BOSS ARENA]
 *
 * Level offsets on X-axis:  L1=0, L2=1200, L3=2400, L4=3600
 */
public class WorldGenerator {

    private final DogApocalypsePlugin plugin;
    private World levelWorld;

    // Spacing between levels along X axis
    private static final int LEVEL_SPACING = 1200;
    private static final int BASE_Y = 64;

    // Level world name
    public static final String WORLD_NAME = "dogapocalypse_levels";

    public WorldGenerator(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // World bootstrap
    // ---------------------------------------------------------------

    /**
     * Creates or loads the level world, then generates all levels.
     */
    public void initWorld(Runnable onComplete) {
        // Check if world already exists
        levelWorld = Bukkit.getWorld(WORLD_NAME);
        if (levelWorld != null) {
            plugin.getLogger().info("[WorldGen] Level world already exists — skipping generation.");
            if (onComplete != null) onComplete.run();
            return;
        }

        plugin.getLogger().info("[WorldGen] Creating level world: " + WORLD_NAME);

        WorldCreator creator = new WorldCreator(WORLD_NAME);
        creator.type(WorldType.FLAT);
        creator.generatorSettings("{\"layers\":[{\"block\":\"air\",\"height\":1}],\"biome\":\"plains\"}");
        creator.generateStructures(false);

        levelWorld = creator.createWorld();
        if (levelWorld == null) {
            plugin.getLogger().severe("[WorldGen] Failed to create level world!");
            return;
        }

        // World settings
        levelWorld.setSpawnFlags(false, false);
        levelWorld.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        levelWorld.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        levelWorld.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        levelWorld.setGameRule(GameRule.MOB_GRIEFING, false);
        levelWorld.setGameRule(GameRule.KEEP_INVENTORY, true);
        levelWorld.setTime(18000); // eternal night — post-apocalyptic atmosphere
        levelWorld.setStorm(false);

        plugin.getLogger().info("[WorldGen] Starting level generation...");
        generateAllLevels(onComplete);
    }

    // ---------------------------------------------------------------
    // Level generation dispatcher
    // ---------------------------------------------------------------

    private void generateAllLevels(Runnable onComplete) {
        new BukkitRunnable() {
            int step = 0;
            @Override
            public void run() {
                switch (step++) {
                    case 0 -> { plugin.getLogger().info("[WorldGen] Generating Level 1: The Ruined City..."); generateLevel1(); }
                    case 1 -> { plugin.getLogger().info("[WorldGen] Generating Level 2: The Infected Forest..."); generateLevel2(); }
                    case 2 -> { plugin.getLogger().info("[WorldGen] Generating Level 3: The War Ruins..."); generateLevel3(); }
                    case 3 -> { plugin.getLogger().info("[WorldGen] Generating Level 4: The Dragon's Lair..."); generateLevel4(); }
                    default -> {
                        plugin.getLogger().info("[WorldGen] All levels generated successfully!");
                        if (onComplete != null) onComplete.run();
                        cancel();
                    }
                }
            }
        }.runTaskTimer(plugin, 10L, 80L); // 4s between levels to avoid lag spikes
    }

    // ---------------------------------------------------------------
    // LEVEL 1 — The Ruined City (offset X=0)
    // ---------------------------------------------------------------

    private void generateLevel1() {
        int ox = 0;
        int oz = 0;

        // Ground floor
        fillFloor(ox, BASE_Y - 1, oz, 200, 20, Material.CRACKED_STONE_BRICKS);

        // Spawn platform
        fillBox(ox, BASE_Y, oz, 12, 1, 12, Material.STONE_BRICKS);
        placeBlock(ox + 6, BASE_Y + 1, oz + 6, Material.RESPAWN_ANCHOR); // spawn marker

        // Ruined buildings - wave 1 zone (Z+30 to Z+80)
        buildRuinedBuilding(ox + 5,  BASE_Y, oz + 35, 8, 6);
        buildRuinedBuilding(ox + 20, BASE_Y, oz + 45, 6, 5);
        buildRuinedBuilding(ox + 2,  BASE_Y, oz + 60, 10, 7);
        buildPlatformPath(ox, BASE_Y, oz + 30, oz + 85, Material.COBBLESTONE);

        // Checkpoint 1 (Z+90)
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 90, "CHECKPOINT 1");

        // Wave 2 zone (Z+100 to Z+150)
        buildRuinedBuilding(ox + 3,  BASE_Y, oz + 110, 9, 5);
        buildRuinedBuilding(ox + 18, BASE_Y, oz + 120, 7, 8);
        buildSuspensionBridge(ox, BASE_Y + 8, oz + 105, oz + 145);
        buildPlatformPath(ox, BASE_Y, oz + 100, oz + 155, Material.STONE_BRICKS);

        // Checkpoint 2 (Z+160)
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 160, "CHECKPOINT 2");

        // Wave 3 zone (Z+170 to Z+220)
        buildCraterField(ox, BASE_Y, oz + 175, 3);
        buildRuinedBuilding(ox + 8, BASE_Y, oz + 195, 12, 6);
        buildPlatformPath(ox, BASE_Y, oz + 170, oz + 225, Material.DEEPSLATE_BRICKS);

        // Boss arena (Z+240)
        buildBossArena(ox + 6, BASE_Y, oz + 240, 22, Material.BLACKSTONE, Material.CRACKED_POLISHED_BLACKSTONE_BRICKS);

        // Atmospheric details
        scatterDebris(ox, BASE_Y, oz, 200, 80, Material.GRAVEL, Material.COBBLESTONE, Material.STONE_BRICKS);
        addLighting(ox, BASE_Y, oz, 200, 265);

        plugin.getLogger().info("[WorldGen] Level 1 complete.");
    }

    // ---------------------------------------------------------------
    // LEVEL 2 — The Infected Forest (offset X=0, Z=1200)
    // ---------------------------------------------------------------

    private void generateLevel2() {
        int ox = 0;
        int oz = 1200;

        // Mossy floor
        fillFloor(ox, BASE_Y - 1, oz, 200, 22, Material.MOSSY_COBBLESTONE);
        fillFloor(ox, BASE_Y - 1, oz, 200, 22, Material.MOSS_BLOCK);

        // Spawn
        fillBox(ox, BASE_Y, oz, 12, 1, 12, Material.MOSSY_STONE_BRICKS);
        placeBlock(ox + 6, BASE_Y + 1, oz + 6, Material.RESPAWN_ANCHOR);

        // Mutant trees
        buildMutantTree(ox + 4,  BASE_Y, oz + 35, 8);
        buildMutantTree(ox + 18, BASE_Y, oz + 50, 12);
        buildMutantTree(ox + 2,  BASE_Y, oz + 70, 10);
        buildMutantTree(ox + 12, BASE_Y, oz + 85, 7);

        // Canopy platforms connecting trees
        buildCanopyBridge(ox, BASE_Y + 10, oz + 35, oz + 95);

        // Swamp zone - W2
        buildSwampSection(ox, BASE_Y, oz + 100, oz + 155);
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 160, "CHECKPOINT 1");

        // Dense forest - W3
        for (int i = 0; i < 6; i++) {
            buildMutantTree(ox + (i * 3), BASE_Y, oz + 170 + (i * 8), 6 + i);
        }
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 230, "CHECKPOINT 2");

        // Dense canopy boss zone
        buildMutantTree(ox + 3,  BASE_Y, oz + 250, 14);
        buildMutantTree(ox + 14, BASE_Y, oz + 255, 16);
        buildBossArena(ox + 6, BASE_Y, oz + 270, 24,
                Material.MOSSY_STONE_BRICKS, Material.MOSS_BLOCK);

        scatterDebris(ox, BASE_Y, oz, 200, 300, Material.OAK_LOG, Material.BROWN_MUSHROOM, Material.RED_MUSHROOM);
        addLighting(ox, BASE_Y, oz, 200, 310);
        plugin.getLogger().info("[WorldGen] Level 2 complete.");
    }

    // ---------------------------------------------------------------
    // LEVEL 3 — The War Ruins (offset Z=2400)
    // ---------------------------------------------------------------

    private void generateLevel3() {
        int ox = 0;
        int oz = 2400;

        // Metal/industrial floor
        fillFloor(ox, BASE_Y - 1, oz, 200, 22, Material.SMOOTH_STONE);
        fillFloor(ox, BASE_Y - 2, oz, 200, 22, Material.IRON_BLOCK);

        // Spawn
        fillBox(ox, BASE_Y, oz, 12, 1, 12, Material.IRON_BLOCK);
        placeBlock(ox + 6, BASE_Y + 1, oz + 6, Material.RESPAWN_ANCHOR);

        // Bunkers and trenches
        buildBunker(ox + 2,  BASE_Y, oz + 35, 10, 5);
        buildBunker(ox + 16, BASE_Y, oz + 55, 8, 4);
        buildTrench(ox, BASE_Y - 3, oz + 45, 20, 3);
        buildPlatformPath(ox, BASE_Y, oz + 30, oz + 80, Material.IRON_BARS);

        buildCheckpointStructure(ox + 6, BASE_Y, oz + 90, "CHECKPOINT 1");

        // War machine wreckage
        buildWreckage(ox + 5,  BASE_Y, oz + 105, 14);
        buildWreckage(ox + 18, BASE_Y, oz + 125, 10);
        buildCraterField(ox, BASE_Y, oz + 115, 4);

        buildCheckpointStructure(ox + 6, BASE_Y, oz + 160, "CHECKPOINT 2");

        // Elevated factory section
        buildElevatedFactory(ox, BASE_Y, oz + 175, oz + 225);

        buildCheckpointStructure(ox + 6, BASE_Y, oz + 235, "CHECKPOINT 3");

        // Boss arena: War Machine Robot — large flat metal arena
        buildBossArena(ox + 6, BASE_Y, oz + 255, 26,
                Material.IRON_BLOCK, Material.CHISELED_STONE_BRICKS);

        scatterDebris(ox, BASE_Y, oz, 200, 300, Material.IRON_BARS, Material.CHAIN, Material.LANTERN);
        addLighting(ox, BASE_Y, oz, 200, 310);
        plugin.getLogger().info("[WorldGen] Level 3 complete.");
    }

    // ---------------------------------------------------------------
    // LEVEL 4 — The Dragon's Lair (offset Z=3600)
    // ---------------------------------------------------------------

    private void generateLevel4() {
        int ox = 0;
        int oz = 3600;

        // Volcanic floor
        fillFloor(ox, BASE_Y - 1, oz, 200, 24, Material.BLACKSTONE);
        fillFloor(ox, BASE_Y - 2, oz, 200, 24, Material.NETHERRACK);

        // Spawn
        fillBox(ox, BASE_Y, oz, 12, 1, 12, Material.POLISHED_BLACKSTONE_BRICKS);
        placeBlock(ox + 6, BASE_Y + 1, oz + 6, Material.RESPAWN_ANCHOR);

        // Volcanic cave tunnels
        buildLavaTunnel(ox, BASE_Y, oz + 30, oz + 90);
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 100, "CHECKPOINT 1");

        // Obsidian pillars
        for (int i = 0; i < 5; i++) {
            buildObsidianPillar(ox + (i * 4), BASE_Y, oz + 120 + (i * 12), 8 + i);
        }
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 185, "CHECKPOINT 2");

        // Dragon's inner sanctum
        buildDragonSanctum(ox, BASE_Y, oz + 200, oz + 250);
        buildCheckpointStructure(ox + 6, BASE_Y, oz + 255, "CHECKPOINT 3");

        // Final boss arena — large dramatic circle
        buildFinalDragonArena(ox + 6, BASE_Y, oz + 280);

        // Lava accents
        placeLavaAccents(ox, BASE_Y, oz, 200, 330);
        addLighting(ox, BASE_Y, oz, 200, 335);
        plugin.getLogger().info("[WorldGen] Level 4 complete.");
    }

    // ===============================================================
    // STRUCTURE BUILDERS
    // ===============================================================

    /** Solid floor rectangle */
    private void fillFloor(int ox, int y, int oz, int width, int depth, Material mat) {
        for (int x = ox; x < ox + width; x++)
            for (int z = oz; z < oz + depth; z++)
                placeBlock(x, y, z, mat);
    }

    /** Solid filled box */
    private void fillBox(int ox, int oy, int oz, int w, int h, int d, Material mat) {
        for (int x = ox; x < ox + w; x++)
            for (int y = oy; y < oy + h; y++)
                for (int z = oz; z < oz + d; z++)
                    placeBlock(x, y, z, mat);
    }

    /** Hollow box (walls + floor + ceiling) */
    private void hollowBox(int ox, int oy, int oz, int w, int h, int d, Material wall, Material floor) {
        for (int x = ox; x < ox + w; x++) {
            for (int y = oy; y < oy + h; y++) {
                for (int z = oz; z < oz + d; z++) {
                    boolean edge = x == ox || x == ox+w-1 || z == oz || z == oz+d-1 || y == oy || y == oy+h-1;
                    if (edge) placeBlock(x, y, z, y == oy ? floor : wall);
                }
            }
        }
    }

    /** Ruined building with crumbling walls */
    private void buildRuinedBuilding(int ox, int oy, int oz, int size, int height) {
        Random rng = new Random(ox * 31L + oz);
        Material wall = rng.nextBoolean() ? Material.STONE_BRICKS : Material.CRACKED_STONE_BRICKS;
        Material floor = Material.COBBLESTONE;

        hollowBox(ox, oy, oz, size, height, size, wall, floor);

        // Damage walls — remove random blocks to make it look ruined
        for (int pass = 0; pass < size * height; pass++) {
            int rx = ox + rng.nextInt(size);
            int ry = oy + 1 + rng.nextInt(height - 1);
            int rz = oz + rng.nextInt(size);
            Block b = levelWorld.getBlockAt(rx, ry, rz);
            if (b.getType() == wall && rng.nextFloat() < 0.35f)
                b.setType(Material.AIR);
        }

        // Roof rubble
        for (int x = ox; x < ox + size; x++)
            for (int z2 = oz; z2 < oz + size; z2++)
                if (rng.nextFloat() < 0.4f)
                    placeBlock(x, oy + height, z2, Material.GRAVEL);
    }

    /** Platform path along Z axis with gaps */
    private void buildPlatformPath(int ox, int oy, int ozStart, int ozEnd, Material mat) {
        Random rng = new Random(ozStart);
        int x = ox + 5;
        for (int z = ozStart; z < ozEnd; z += 4) {
            int w = 3 + rng.nextInt(4);
            int yOff = rng.nextInt(3) - 1;
            for (int dx = 0; dx < w; dx++)
                placeBlock(x + dx, oy + yOff, z, mat);
        }
    }

    /** Checkpoint beacon structure */
    private void buildCheckpointStructure(int ox, int oy, int oz, String label) {
        // Base
        fillBox(ox - 1, oy, oz - 1, 6, 1, 6, Material.GOLD_BLOCK);
        // Pillar
        for (int y = oy + 1; y <= oy + 4; y++)
            placeBlock(ox + 2, y, oz + 2, Material.BEACON);
        // Top
        placeBlock(ox + 2, oy + 5, oz + 2, Material.GOLD_BLOCK);
        // Lectern for NPC hint
        placeBlock(ox + 4, oy + 1, oz + 3, Material.LECTERN);
    }

    /** Suspension bridge along Z axis */
    private void buildSuspensionBridge(int ox, int oy, int ozStart, int ozEnd, Material... mats) {
        Material planks = Material.OAK_PLANKS;
        // Deck
        for (int z = ozStart; z <= ozEnd; z++)
            for (int dx = 0; dx < 4; dx++)
                placeBlock(ox + dx + 4, oy, z, planks);
        // Cables (iron bars along sides going up to pillars)
        placeBlock(ox + 4, oy + 5, ozStart, Material.IRON_BLOCK);
        placeBlock(ox + 8, oy + 5, ozStart, Material.IRON_BLOCK);
        placeBlock(ox + 4, oy + 5, ozEnd, Material.IRON_BLOCK);
        placeBlock(ox + 8, oy + 5, ozEnd, Material.IRON_BLOCK);
        for (int z = ozStart; z <= ozEnd; z++) {
            placeBlock(ox + 4, oy + 3, z, Material.IRON_BARS);
            placeBlock(ox + 8, oy + 3, z, Material.IRON_BARS);
        }
    }

    /** Crater field — depressions in ground */
    private void buildCraterField(int ox, int oy, int oz, int count) {
        Random rng = new Random(oz);
        for (int c = 0; c < count; c++) {
            int cx = ox + rng.nextInt(16);
            int cz = oz + rng.nextInt(30);
            int r = 3 + rng.nextInt(4);
            for (int x = cx - r; x <= cx + r; x++) {
                for (int z = cz - r; z <= cz + r; z++) {
                    double dist = Math.sqrt(Math.pow(x - cx, 2) + Math.pow(z - cz, 2));
                    if (dist <= r) {
                        placeBlock(x, oy, z, Material.AIR);
                        placeBlock(x, oy - 1, z, Material.GRAVEL);
                        placeBlock(x, oy - 2, z, Material.COARSE_DIRT);
                    }
                }
            }
        }
    }

    /** Boss arena — circular platform with walls */
    private void buildBossArena(int ox, int oy, int oz, int radius, Material floor, Material wall) {
        for (int x = ox - radius; x <= ox + radius; x++) {
            for (int z = oz - radius; z <= oz + radius; z++) {
                double dist = Math.sqrt(Math.pow(x - ox, 2) + Math.pow(z - oz, 2));
                if (dist <= radius) {
                    placeBlock(x, oy, z, floor);
                    placeBlock(x, oy - 1, z, wall);
                }
                if (dist > radius - 1.5 && dist <= radius) {
                    for (int y = oy + 1; y <= oy + 4; y++)
                        placeBlock(x, y, z, wall);
                }
            }
        }
        // Entrance gap
        for (int dz = oz - 2; dz <= oz + 2; dz++)
            for (int y = oy + 1; y <= oy + 4; y++)
                placeBlock(ox - radius, y, dz, Material.AIR);
        // Lectern for boss NPC
        placeBlock(ox, oy + 1, oz - radius + 2, Material.LECTERN);
    }

    /** Mutant tree for forest level */
    private void buildMutantTree(int ox, int oy, int oz, int height) {
        Material trunk = Material.DARK_OAK_LOG;
        Material leaves = Material.AZALEA_LEAVES;
        // Trunk
        for (int y = oy; y < oy + height; y++)
            placeBlock(ox, y, oz, trunk);
        // Twisted branches
        Random rng = new Random(ox * 13L + oz);
        for (int b = 0; b < 3; b++) {
            int by = oy + height / 2 + rng.nextInt(height / 2);
            int bx = ox + rng.nextInt(5) - 2;
            int bz = oz + rng.nextInt(5) - 2;
            for (int s = 0; s < 4; s++) {
                placeBlock(ox + (bx - ox) * s / 4, by, oz + (bz - oz) * s / 4, trunk);
            }
            // Leaf cluster at branch end
            for (int lx = -2; lx <= 2; lx++)
                for (int ly = -1; ly <= 1; ly++)
                    for (int lz = -2; lz <= 2; lz++)
                        if (rng.nextFloat() > 0.3f)
                            placeBlock(bx + lx, by + ly, bz + lz, leaves);
        }
        // Top canopy
        int ty = oy + height;
        for (int lx = -3; lx <= 3; lx++)
            for (int ly = -1; ly <= 2; ly++)
                for (int lz = -3; lz <= 3; lz++)
                    if (Math.abs(lx) + Math.abs(lz) + Math.abs(ly) <= 4)
                        placeBlock(ox + lx, ty + ly, oz + lz, leaves);
        // Walkable platform in canopy
        for (int lx = -2; lx <= 2; lx++)
            for (int lz = -2; lz <= 2; lz++)
                placeBlock(ox + lx, ty + 1, oz + lz, Material.JUNGLE_PLANKS);
    }

    /** Canopy bridge */
    private void buildCanopyBridge(int ox, int oy, int ozStart, int ozEnd) {
        for (int z = ozStart; z <= ozEnd; z += 2)
            for (int dx = -1; dx <= 1; dx++)
                placeBlock(ox + 8 + dx, oy, z, Material.JUNGLE_PLANKS);
    }

    /** Swamp water section */
    private void buildSwampSection(int ox, int oy, int ozStart, int ozEnd) {
        Random rng = new Random(ozStart);
        for (int x = ox; x < ox + 20; x++)
            for (int z = ozStart; z < ozEnd; z++) {
                if (rng.nextFloat() < 0.35f) {
                    placeBlock(x, oy - 1, z, Material.WATER);
                    placeBlock(x, oy, z, Material.AIR);
                } else {
                    placeBlock(x, oy, z, Material.GRASS_BLOCK);
                }
            }
        // Lily pads as stepping stones
        for (int z = ozStart; z < ozEnd; z += 3)
            placeBlock(ox + 8, oy, z, Material.LILY_PAD);
    }

    /** Military bunker */
    private void buildBunker(int ox, int oy, int oz, int w, int h) {
        hollowBox(ox, oy, oz, w, h, 8, Material.SMOOTH_STONE, Material.IRON_BLOCK);
        // Embrasures (holes in front wall)
        placeBlock(ox + 2, oy + 2, oz, Material.AIR);
        placeBlock(ox + w - 3, oy + 2, oz, Material.AIR);
        // Interior
        placeBlock(ox + 1, oy + 1, oz + 3, Material.CHEST);
        placeBlock(ox + w - 2, oy + 1, oz + 3, Material.BARREL);
    }

    /** Trench dug into ground */
    private void buildTrench(int ox, int oy, int oz, int length, int depth) {
        for (int z = oz; z < oz + length; z++)
            for (int y = oy; y <= oy + depth; y++)
                for (int dx = 0; dx < 3; dx++)
                    placeBlock(ox + 4 + dx, y, z, Material.AIR);
    }

    /** Wreckage of a war machine */
    private void buildWreckage(int ox, int oy, int oz, int size) {
        Random rng = new Random(ox * 7L + oz);
        for (int pass = 0; pass < size * 6; pass++) {
            int x = ox + rng.nextInt(size);
            int y = oy + rng.nextInt(4);
            int z = oz + rng.nextInt(size);
            Material mat = switch (rng.nextInt(4)) {
                case 0 -> Material.IRON_BLOCK;
                case 1 -> Material.CHISELED_STONE_BRICKS;
                case 2 -> Material.IRON_BARS;
                default -> Material.GRAVEL;
            };
            placeBlock(x, y, z, mat);
        }
    }

    /** Elevated factory floor */
    private void buildElevatedFactory(int ox, int oy, int ozStart, int ozEnd) {
        int elevated = oy + 8;
        for (int z = ozStart; z < ozEnd; z += 6) {
            // Support columns
            for (int y = oy; y <= elevated; y++) {
                placeBlock(ox + 4, y, z, Material.IRON_BLOCK);
                placeBlock(ox + 16, y, z, Material.IRON_BLOCK);
            }
            // Walkway
            for (int x = ox + 4; x <= ox + 16; x++)
                placeBlock(x, elevated, z, Material.SMOOTH_STONE_SLAB);
        }
    }

    /** Lava tunnel */
    private void buildLavaTunnel(int ox, int oy, int ozStart, int ozEnd) {
        for (int z = ozStart; z < ozEnd; z++) {
            // Arch
            for (int r = -4; r <= 4; r++)
                for (int y = oy; y <= oy + 5; y++) {
                    double dist = Math.sqrt(r * r + Math.pow(y - oy, 2));
                    if (dist >= 3.5 && dist <= 4.5)
                        placeBlock(ox + 8 + r, y, z, Material.BLACKSTONE);
                }
            // Floor
            for (int x = ox + 4; x <= ox + 12; x++)
                placeBlock(x, oy, z, Material.POLISHED_BLACKSTONE_BRICKS);
            // Lava accent on sides
            if (z % 6 == 0) {
                placeBlock(ox + 4, oy - 1, z, Material.LAVA);
                placeBlock(ox + 12, oy - 1, z, Material.LAVA);
            }
        }
    }

    /** Obsidian pillar */
    private void buildObsidianPillar(int ox, int oy, int oz, int height) {
        for (int y = oy; y < oy + height; y++)
            for (int dx = 0; dx < 2; dx++)
                for (int dz = 0; dz < 2; dz++)
                    placeBlock(ox + dx, y, oz + dz, Material.OBSIDIAN);
        // Platform on top
        for (int dx = -1; dx <= 2; dx++)
            for (int dz = -1; dz <= 2; dz++)
                placeBlock(ox + dx, oy + height, oz + dz, Material.CRYING_OBSIDIAN);
    }

    /** Dragon sanctum inner corridor */
    private void buildDragonSanctum(int ox, int oy, int ozStart, int ozEnd) {
        for (int z = ozStart; z < ozEnd; z++) {
            for (int x = ox + 2; x <= ox + 18; x++) {
                placeBlock(x, oy, z, Material.POLISHED_BLACKSTONE_BRICKS);
                placeBlock(x, oy + 8, z, Material.BLACKSTONE);
            }
            placeBlock(ox + 2, oy + 1, z, Material.BLACKSTONE);
            placeBlock(ox + 18, oy + 1, z, Material.BLACKSTONE);
            // Dragon claw motif pillars
            if (z % 8 == 0) {
                for (int y = oy + 1; y <= oy + 7; y++) {
                    placeBlock(ox + 3, y, z, Material.OBSIDIAN);
                    placeBlock(ox + 17, y, z, Material.OBSIDIAN);
                }
            }
        }
    }

    /** Final dragon arena — grand circular stage */
    private void buildFinalDragonArena(int ox, int oy, int oz) {
        int radius = 30;
        Material floor = Material.END_STONE_BRICKS;
        Material wall  = Material.OBSIDIAN;

        for (int x = ox - radius; x <= ox + radius; x++) {
            for (int z = oz - radius; z <= oz + radius; z++) {
                double dist = Math.sqrt(Math.pow(x - ox, 2) + Math.pow(z - oz, 2));
                if (dist <= radius) {
                    placeBlock(x, oy, z, floor);
                    placeBlock(x, oy - 1, z, Material.BEDROCK);
                }
                if (dist > radius - 2 && dist <= radius) {
                    for (int y = oy + 1; y <= oy + 6; y++)
                        placeBlock(x, y, z, wall);
                }
            }
        }

        // Dragon egg throne in center
        placeBlock(ox, oy + 1, oz, Material.DRAGON_EGG);
        for (int i = 0; i < 4; i++) {
            double a = Math.PI / 2 * i;
            int px = (int)(ox + Math.cos(a) * 5);
            int pz = (int)(oz + Math.sin(a) * 5);
            for (int y = oy + 1; y <= oy + 4; y++)
                placeBlock(px, y, pz, Material.CRYING_OBSIDIAN);
            placeBlock(px, oy + 5, pz, Material.END_ROD);
        }

        // Wide entrance
        for (int dz = oz - 3; dz <= oz + 3; dz++)
            for (int y = oy + 1; y <= oy + 6; y++)
                placeBlock(ox - radius, y, dz, Material.AIR);

        // Lecterns for final NPC
        placeBlock(ox + 3, oy + 1, oz - radius + 3, Material.LECTERN);
        placeBlock(ox - 3, oy + 1, oz - radius + 3, Material.LECTERN);
    }

    // ---------------------------------------------------------------
    // DETAIL HELPERS
    // ---------------------------------------------------------------

    private void scatterDebris(int ox, int oy, int oz, int width, int depth, Material... mats) {
        Random rng = new Random(oz * 31L);
        for (int i = 0; i < width * 3; i++) {
            int x = ox + rng.nextInt(width);
            int z = oz + rng.nextInt(depth);
            placeBlock(x, oy, z, mats[rng.nextInt(mats.length)]);
        }
    }

    private void addLighting(int ox, int oy, int oz, int width, int depth) {
        for (int z = oz; z < oz + depth; z += 12) {
            for (int x = ox; x < ox + width; x += 14) {
                placeBlock(x, oy + 4, z, Material.LANTERN);
            }
        }
    }

    private void placeLavaAccents(int ox, int oy, int oz, int width, int depth) {
        Random rng = new Random(oz);
        for (int i = 0; i < 20; i++) {
            int x = ox + rng.nextInt(width);
            int z = oz + rng.nextInt(depth);
            placeBlock(x, oy - 1, z, Material.LAVA);
        }
    }

    // ---------------------------------------------------------------
    // Core block setter (thread-safe via main thread scheduling)
    // ---------------------------------------------------------------

    private void placeBlock(int x, int y, int z, Material mat) {
        if (levelWorld == null) return;
        Block block = levelWorld.getBlockAt(x, y, z);
        if (block.getType() != mat) {
            block.setType(mat, false); // false = skip physics for speed
        }
    }

    // ---------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------

    public World getLevelWorld() { return levelWorld; }

    /**
     * Returns the spawn location for the given level index (1-based).
     */
    public Location getLevelSpawn(int levelIndex) {
        int oz = (levelIndex - 1) * LEVEL_SPACING;
        return new Location(levelWorld, 6, BASE_Y + 1, oz + 6);
    }

    /**
     * Returns a list of checkpoint locations for the given level.
     */
    public List<Location> getLevelCheckpoints(int levelIndex) {
        int oz = (levelIndex - 1) * LEVEL_SPACING;
        List<Location> cps = new ArrayList<>();
        cps.add(new Location(levelWorld, 6, BASE_Y + 1, oz + 90));
        if (levelIndex >= 2) cps.add(new Location(levelWorld, 6, BASE_Y + 1, oz + 160));
        if (levelIndex >= 3) cps.add(new Location(levelWorld, 6, BASE_Y + 1, oz + 235));
        return cps;
    }

    /**
     * Returns the boss arena center for the given level.
     */
    public Location getBossArenaCenter(int levelIndex) {
        int oz = (levelIndex - 1) * LEVEL_SPACING;
        int bossZ = switch (levelIndex) {
            case 1 -> oz + 240;
            case 2 -> oz + 270;
            case 3 -> oz + 255;
            case 4 -> oz + 280;
            default -> oz + 240;
        };
        return new Location(levelWorld, 6, BASE_Y + 1, bossZ);
    }

    public boolean isGenerated() { return levelWorld != null; }
}
