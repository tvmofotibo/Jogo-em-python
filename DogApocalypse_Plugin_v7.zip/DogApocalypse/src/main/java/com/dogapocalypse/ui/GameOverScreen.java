package com.dogapocalypse.ui;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;
import java.util.HashSet;
import java.util.Set;

/**
 * GameOverScreen — Tela de game over com botões clicáveis no chat.
 *
 * Aparece quando:
 *  - Jogador está sozinho e o tempo de abatido esgota
 *  - Todo o grupo está abatido ao mesmo tempo
 *
 * Opções:
 *  [RECOMEÇAR NÍVEL]   — teleporta para o spawn do nível atual
 *  [MENU PRINCIPAL]    — teleporta para o spawn do servidor
 */
public class GameOverScreen {

    private final DogApocalypsePlugin plugin;
    private final Set<UUID> emGameOver = new HashSet<>();

    public GameOverScreen(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    /** Exibe a tela de game over para o jogador. */
    public void mostrar(Player player, String levelId) {
        if (emGameOver.contains(player.getUniqueId())) return;
        emGameOver.add(player.getUniqueId());

        // Efeitos visuais de morte
        player.setGameMode(GameMode.SPECTATOR);
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1, false, false));
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.6f, 0.5f);
        player.getWorld().spawnParticle(Particle.SMOKE_NORMAL,
                player.getLocation().add(0, 1, 0), 40, 0.5, 0.5, 0.5, 0.05);

        // Título na tela
        player.sendTitle(
            MessageUtil.color("&4&l☠  GAME OVER  ☠"),
            MessageUtil.color("&7Você foi derrotado..."),
            10, 80, 20
        );

        // Aguarda 2 segundos e exibe o menu no chat
        new BukkitRunnable() {
            @Override public void run() {
                if (!player.isOnline()) return;
                exibirMenuChat(player, levelId);
            }
        }.runTaskLater(plugin, 40L);
    }

    private void exibirMenuChat(Player player, String levelId) {
        player.sendMessage("");
        player.sendMessage(MessageUtil.color("&4&m                                        "));
        player.sendMessage(MessageUtil.color("   &4&l☠  &c&lGAME OVER  &4&l☠"));
        player.sendMessage(MessageUtil.color("&4&m                                        "));
        player.sendMessage("");

        String nomeNivel = switch (levelId) {
            case "level_1" -> "A Cidade em Ruínas";
            case "level_2" -> "A Floresta Infectada";
            case "level_3" -> "As Ruínas de Guerra";
            case "level_4" -> "O Covil do Dragão";
            default        -> levelId;
        };

        player.sendMessage(MessageUtil.color("   &7Nível: &f" + nomeNivel));
        player.sendMessage("");

        // Botão — Recomeçar
        TextComponent recomecar = new TextComponent("   ");
        TextComponent btnRecomecar = new TextComponent("[ ▶  RECOMEÇAR NÍVEL ]");
        btnRecomecar.setColor(net.md_5.bungee.api.ChatColor.GREEN);
        btnRecomecar.setBold(true);
        btnRecomecar.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/gameoverchoice restart " + levelId));
        btnRecomecar.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new ComponentBuilder(MessageUtil.color("&aTeleporta para o início do nível")).create()));
        recomecar.addExtra(btnRecomecar);
        player.spigot().sendMessage(recomecar);

        player.sendMessage("");

        // Botão — Menu Principal
        TextComponent menu = new TextComponent("   ");
        TextComponent btnMenu = new TextComponent("[ ⌂  MENU PRINCIPAL ]");
        btnMenu.setColor(net.md_5.bungee.api.ChatColor.YELLOW);
        btnMenu.setBold(true);
        btnMenu.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/gameoverchoice menu"));
        btnMenu.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new ComponentBuilder(MessageUtil.color("&eVolta para o spawn principal")).create()));
        menu.addExtra(btnMenu);
        player.spigot().sendMessage(menu);

        player.sendMessage("");
        player.sendMessage(MessageUtil.color("&4&m                                        "));
        player.sendMessage("");
    }

    /** Chamado quando o jogador clica em Recomeçar. */
    public void recomecarNivel(Player player, String levelId) {
        emGameOver.remove(player.getUniqueId());
        player.setGameMode(GameMode.SURVIVAL);
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(20f);

        // Teleporta para o spawn do nível
        var levelData = plugin.getLevelManager().getLevel(levelId);
        if (levelData != null && levelData.getSpawnLocation() != null) {
            player.teleport(levelData.getSpawnLocation());
        }

        // Re-aplica kit da classe
        plugin.getPlayerClassManager().applyClassStats(player,
                plugin.getPlayerDataManager().get(player).getPlayerClass());

        // Inicia o nível novamente
        var party = plugin.getCoopManager().getPartyMembers(player);
        plugin.getLevelManager().startLevel(levelId, party);

        player.sendTitle(
            MessageUtil.color("&a&lRECOMEÇANDO"),
            MessageUtil.color("&7Boa sorte desta vez!"),
            10, 50, 10
        );
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }

    /** Chamado quando o jogador clica em Menu Principal. */
    public void irParaMenu(Player player) {
        emGameOver.remove(player.getUniqueId());
        player.setGameMode(GameMode.SURVIVAL);
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);

        World mundo = Bukkit.getWorlds().get(0);
        player.teleport(mundo.getSpawnLocation());

        player.sendMessage(MessageUtil.color("&6[Menu] &fVocê voltou para o spawn principal."));
        player.sendMessage(MessageUtil.color("&7Use &e/level tp level_1 &7para entrar em um nível."));
    }

    public boolean estaEmGameOver(UUID uuid) {
        return emGameOver.contains(uuid);
    }

    public void limpar(UUID uuid) {
        emGameOver.remove(uuid);
    }
}
