package com.dogapocalypse.core;

import com.dogapocalypse.bosses.BossManager;
import com.dogapocalypse.classes.PlayerClassManager;
import com.dogapocalypse.combat.CombatManager;
import com.dogapocalypse.coop.ReviveSystem;
import com.dogapocalypse.coop.CoopManager;
import com.dogapocalypse.commands.*;
import com.dogapocalypse.dogpowers.DogPowerManager;
import com.dogapocalypse.enemies.EnemyManager;
import com.dogapocalypse.levels.CheckpointManager;
import com.dogapocalypse.levels.LevelManager;
import com.dogapocalypse.listeners.ListenerRegistrar;
import com.dogapocalypse.npc.NPCManager;
import com.dogapocalypse.skills.SkillTreeManager;
import com.dogapocalypse.story.DialogueManager;
import com.dogapocalypse.ui.HudManager;
import com.dogapocalypse.worldgen.WorldGenerator;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.logging.Level;

public final class DogApocalypsePlugin extends JavaPlugin {

    private static DogApocalypsePlugin instance;

    private PlayerClassManager  playerClassManager;
    private DogPowerManager     dogPowerManager;
    private SkillTreeManager    skillTreeManager;
    private BossManager         bossManager;
    private EnemyManager        enemyManager;
    private LevelManager        levelManager;
    private CheckpointManager   checkpointManager;
    private ReviveSystem        reviveSystem;
    private CoopManager         coopManager;
    private CombatManager       combatManager;
    private DialogueManager     dialogueManager;
    private PlayerDataManager   playerDataManager;
    private WorldGenerator      worldGenerator;
    private NPCManager          npcManager;
    private HudManager          hudManager;

    @Override
    public void onEnable() {
        instance = this;
        getLogger().info("===========================================");
        getLogger().info("  DogApocalypse v2 - Loading...");
        getLogger().info("===========================================");
        saveDefaultConfig();
        try {
            initManagers();
            ListenerRegistrar.registerAll(this);
            registerCommands();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Failed to initialize!", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getScheduler().runTaskLater(this, () ->
            worldGenerator.initWorld(() -> {
                levelManager.syncWithWorldGenerator(worldGenerator);
                npcManager.spawnAllNpcs(worldGenerator.getLevelWorld());
                getLogger().info("[DogApocalypse] World and NPCs ready!");
            }), 1L);
        checkSoftDependencies();
        getLogger().info("  DogApocalypse v2 enabled!");
        getLogger().info("===========================================");
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) playerDataManager.saveAll();
        if (bossManager       != null) bossManager.cleanupAll();
        if (enemyManager      != null) enemyManager.cleanupAll();
        if (npcManager        != null) npcManager.cleanupAll();
        if (hudManager        != null) hudManager.stop();
        getLogger().info("DogApocalypse disabled.");
    }

    private void initManagers() {
        playerDataManager  = new PlayerDataManager(this);
        playerClassManager = new PlayerClassManager(this);
        dogPowerManager    = new DogPowerManager(this);
        skillTreeManager   = new SkillTreeManager(this);
        combatManager      = new CombatManager(this);
        enemyManager       = new EnemyManager(this);
        bossManager        = new BossManager(this);
        checkpointManager  = new CheckpointManager(this);
        levelManager       = new LevelManager(this);
        reviveSystem       = new ReviveSystem(this);
        coopManager        = new CoopManager(this);
        dialogueManager    = new DialogueManager(this);
        worldGenerator     = new WorldGenerator(this);
        npcManager         = new NPCManager(this);
        hudManager         = new HudManager(this);
        getLogger().info("All managers initialized.");
    }

    private void registerCommands() {
        safeRegister("class",    new ClassCommand(this));
        safeRegister("dogpower", new DogPowerCommand(this));
        safeRegister("dogskill", new DogSkillCommand(this));
        safeRegister("level",    new LevelCommand(this));
        safeRegister("boss",     new BossCommand(this));
        safeRegister("story",    new StoryCommand(this));
        safeRegister("coop",     new CoopCommand(this));
        safeRegister("revive",   new ReviveCommand(this));
        safeRegister("npc",      new NpcAdminCommand(this));
        getLogger().info("All commands registered.");
    }

    private void safeRegister(String name, org.bukkit.command.CommandExecutor executor) {
        var cmd = getCommand(name);
        if (cmd != null) cmd.setExecutor(executor);
        else getLogger().warning("Command '/" + name + "' not in plugin.yml!");
    }

    private void checkSoftDependencies() {
        boolean geyser    = getServer().getPluginManager().isPluginEnabled("Geyser-Spigot");
        boolean floodgate = getServer().getPluginManager().isPluginEnabled("floodgate");
        getLogger().info(geyser    ? "Geyser detected."    : "Geyser not found.");
        getLogger().info(floodgate ? "Floodgate detected." : "Floodgate not found.");
    }

    public static DogApocalypsePlugin getInstance() { return instance; }

    public PlayerClassManager  getPlayerClassManager() { return playerClassManager; }
    public DogPowerManager     getDogPowerManager()    { return dogPowerManager; }
    public SkillTreeManager    getSkillTreeManager()   { return skillTreeManager; }
    public BossManager         getBossManager()        { return bossManager; }
    public EnemyManager        getEnemyManager()       { return enemyManager; }
    public LevelManager        getLevelManager()       { return levelManager; }
    public CheckpointManager   getCheckpointManager()  { return checkpointManager; }
    public ReviveSystem        getReviveSystem()       { return reviveSystem; }
    public CoopManager         getCoopManager()        { return coopManager; }
    public CombatManager       getCombatManager()      { return combatManager; }
    public DialogueManager     getDialogueManager()    { return dialogueManager; }
    public PlayerDataManager   getPlayerDataManager()  { return playerDataManager; }
    public WorldGenerator      getWorldGenerator()     { return worldGenerator; }
    public NPCManager          getNpcManager()         { return npcManager; }
}
