package com.dogapocalypse.dogpowers;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Central manager for the Power Absorption System.
 *
 * Rules:
 *  - Only DOG class players can hold a power.
 *  - Only one active power at a time.
 *  - Absorbing a new power replaces the previous one.
 *  - Powers expire after their configured duration.
 *  - Each power has its own per-player cooldown.
 */
public class DogPowerManager {

    private final DogApocalypsePlugin plugin;

    /** Currently active power per player UUID */
    private final Map<UUID, DogPower> activePowers = new HashMap<>();

    /** Cooldown tracker: UUID -> powerID -> expire tick */
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    /** Expiry task IDs so we can cancel them if replaced early */
    private final Map<UUID, Integer> expiryTasks = new HashMap<>();

    // All available power types
    private final Map<String, DogPower> powerRegistry = new LinkedHashMap<>();

    public DogPowerManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        registerDefaultPowers();
    }

    // ----------------------------------------------------------------
    // Registration
    // ----------------------------------------------------------------

    private void registerDefaultPowers() {
        register(new BlazePower(plugin));
        register(new SpiderPower(plugin));
        register(new GuardianPower(plugin));
        register(new PhantomPower(plugin));
        register(new IronGolemPower(plugin));
    }

    public void register(DogPower power) {
        powerRegistry.put(power.getId(), power);
    }

    public DogPower getPowerType(String id) {
        return powerRegistry.get(id.toLowerCase());
    }

    // ----------------------------------------------------------------
    // Absorption
    // ----------------------------------------------------------------

    /**
     * Absorbs a power for a player, replacing any existing power.
     */
    public void absorbPower(Player player, String powerId) {
        DogPower power = getPowerType(powerId);
        if (power == null) {
            plugin.getLogger().warning("Unknown power ID: " + powerId);
            return;
        }

        // Deactivate existing power first
        clearPower(player);
        // Atualiza cor do disfarce
        plugin.getPlayerClassManager().getDisguiseManager().atualizarCorPoder(player, powerId);

        // Calculate actual duration with skill bonuses
        int duration = calculateDuration(player, power);

        // Store and activate
        activePowers.put(player.getUniqueId(), power);
        power.activate(player);

        // Visual / sound feedback
        EffectUtil.spawnParticleCircle(player.getLocation(), Particle.TOTEM, 40, 2.0);
        player.playSound(player.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, 0.8f);
        player.sendMessage(MessageUtil.color(
                "&5[Power] &fYou absorbed &d" + power.getDisplayName() + "&f!"));

        // Schedule expiry
        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (activePowers.get(player.getUniqueId()) == power) {
                    expirePower(player, power);
                }
            }
        }.runTaskLater(plugin, duration).getTaskId();

        expiryTasks.put(player.getUniqueId(), taskId);
    }

    /**
     * Triggers the use-ability of the currently held power.
     * @return true if the ability fired.
     */
    public boolean triggerAbility(Player player) {
        DogPower power = activePowers.get(player.getUniqueId());
        if (power == null) {
            player.sendMessage(MessageUtil.color("&7Você não tem poder absorvido."));
            return false;
        }

        if (isOnCooldown(player, power.getId())) {
            long remaining = getCooldownRemaining(player, power.getId());
            player.sendMessage(MessageUtil.color(
                    "&c[Cooldown] &f" + (remaining / 20) + "s remaining."));
            return false;
        }

        boolean used = power.useAbility(player);
        if (used) {
            int cd = calculateCooldown(player, power);
            setCooldown(player, power.getId(), cd);
        }
        return used;
    }

    /**
     * Clears the active power for a player immediately.
     */
    public void clearPower(Player player) {
        UUID uuid = player.getUniqueId();
        DogPower existing = activePowers.remove(uuid);
        if (existing != null) {
            existing.deactivate(player);
        }

        // Cancel expiry task
        Integer taskId = expiryTasks.remove(uuid);
        if (taskId != null) {
            plugin.getServer().getScheduler().cancelTask(taskId);
        }
    }

    private void expirePower(Player player, DogPower power) {
        activePowers.remove(player.getUniqueId());
        power.deactivate(player);
        expiryTasks.remove(player.getUniqueId());

        player.sendMessage(MessageUtil.color("&5[Power] &7Your " + power.getDisplayName() + " &7power has faded."));
        player.playSound(player.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.8f, 1.2f);
    }

    // ----------------------------------------------------------------
    // Queries
    // ----------------------------------------------------------------

    public DogPower getActivePower(Player player) {
        return activePowers.get(player.getUniqueId());
    }

    public boolean hasPower(Player player) {
        return activePowers.containsKey(player.getUniqueId());
    }

    // ----------------------------------------------------------------
    // Cooldowns
    // ----------------------------------------------------------------

    private boolean isOnCooldown(Player player, String powerId) {
        Map<String, Long> map = cooldowns.get(player.getUniqueId());
        if (map == null) return false;
        Long expire = map.get(powerId);
        return expire != null && System.currentTimeMillis() < expire;
    }

    private long getCooldownRemaining(Player player, String powerId) {
        Map<String, Long> map = cooldowns.get(player.getUniqueId());
        if (map == null) return 0;
        Long expire = map.get(powerId);
        if (expire == null) return 0;
        long remainingMs = expire - System.currentTimeMillis();
        return Math.max(0, remainingMs / 50); // convert ms to ticks
    }

    private void setCooldown(Player player, String powerId, int ticks) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                 .put(powerId, System.currentTimeMillis() + (ticks * 50L));
    }

    // ----------------------------------------------------------------
    // Skill-based modifiers
    // ----------------------------------------------------------------

    /**
     * Calculates the effective duration considering the power_duration skill.
     */
    private int calculateDuration(Player player, DogPower power) {
        int base = power.getDurationTicks();
        int skillLevel = plugin.getPlayerDataManager().get(player)
                               .getSkillLevel("power_duration");
        int bonusSeconds = skillLevel * plugin.getConfig()
                .getInt("skill_tree.power_duration.duration_bonus_seconds", 20);
        return base + (bonusSeconds * 20);
    }

    /**
     * Calculates the effective cooldown considering the dash_upgrade skill.
     */
    private int calculateCooldown(Player player, DogPower power) {
        return power.getCooldownTicks(); // powers have their own cooldowns; no reduction for now
    }

    // ----------------------------------------------------------------
    // Cleanup
    // ----------------------------------------------------------------

    public void cleanupPlayer(Player player) {
        clearPower(player);
        cooldowns.remove(player.getUniqueId());
    }
}
