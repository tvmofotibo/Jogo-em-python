package com.dogapocalypse.core;

import com.dogapocalypse.classes.PlayerClass;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Persists player data (class, skill points, story progress, etc.)
 * to individual YAML files under /plugins/DogApocalypse/playerdata/.
 */
public class PlayerDataManager {

    private final DogApocalypsePlugin plugin;
    private final File dataFolder;

    // In-memory cache keyed by UUID
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    public PlayerDataManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "playerdata");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    // ----------------------------------------------------------------
    // Load / Save
    // ----------------------------------------------------------------

    public PlayerData load(UUID uuid) {
        if (cache.containsKey(uuid)) return cache.get(uuid);

        File file = new File(dataFolder, uuid + ".yml");
        PlayerData data = new PlayerData(uuid);

        if (file.exists()) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            data.setPlayerClass(PlayerClass.valueOf(
                    cfg.getString("class", PlayerClass.FIGHTER.name())));
            data.setSkillPoints(cfg.getInt("skill_points", 0));
            data.setStoryFragments(cfg.getInt("story_fragments", 0));
            data.setCurrentLevel(cfg.getString("current_level", "level_1"));
            data.setTotalKills(cfg.getInt("total_kills", 0));
            data.setExperience(cfg.getInt("experience", 0));

            // Load skill levels map
            if (cfg.isConfigurationSection("skills")) {
                for (String key : cfg.getConfigurationSection("skills").getKeys(false)) {
                    data.getSkillLevels().put(key, cfg.getInt("skills." + key, 0));
                }
            }
        }

        cache.put(uuid, data);
        return data;
    }

    public void save(UUID uuid) {
        PlayerData data = cache.get(uuid);
        if (data == null) return;

        File file = new File(dataFolder, uuid + ".yml");
        YamlConfiguration cfg = new YamlConfiguration();

        cfg.set("class", data.getPlayerClass().name());
        cfg.set("skill_points", data.getSkillPoints());
        cfg.set("story_fragments", data.getStoryFragments());
        cfg.set("current_level", data.getCurrentLevel());
        cfg.set("total_kills", data.getTotalKills());
        cfg.set("experience", data.getExperience());

        for (Map.Entry<String, Integer> entry : data.getSkillLevels().entrySet()) {
            cfg.set("skills." + entry.getKey(), entry.getValue());
        }

        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save data for " + uuid, e);
        }
    }

    public void saveAll() {
        for (UUID uuid : cache.keySet()) {
            save(uuid);
        }
    }

    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
    }

    public PlayerData get(UUID uuid) {
        return cache.getOrDefault(uuid, load(uuid));
    }

    public PlayerData get(Player player) {
        return get(player.getUniqueId());
    }

    // ----------------------------------------------------------------
    // Inner class: PlayerData
    // ----------------------------------------------------------------

    public static class PlayerData {

        private final UUID uuid;
        private PlayerClass playerClass = PlayerClass.FIGHTER;
        private int skillPoints = 0;
        private int storyFragments = 0;
        private String currentLevel = "level_1";
        private int totalKills = 0;
        private int experience = 0;
        private final Map<String, Integer> skillLevels = new HashMap<>();

        public PlayerData(UUID uuid) {
            this.uuid = uuid;
        }

        // ---- Getters & Setters ----

        public UUID getUuid() { return uuid; }

        public PlayerClass getPlayerClass() { return playerClass; }
        public void setPlayerClass(PlayerClass playerClass) { this.playerClass = playerClass; }

        public int getSkillPoints() { return skillPoints; }
        public void setSkillPoints(int skillPoints) { this.skillPoints = Math.max(0, skillPoints); }
        public void addSkillPoints(int amount) { this.skillPoints += amount; }

        public int getStoryFragments() { return storyFragments; }
        public void setStoryFragments(int storyFragments) { this.storyFragments = storyFragments; }
        public void addStoryFragment() { this.storyFragments++; }

        public String getCurrentLevel() { return currentLevel; }
        public void setCurrentLevel(String currentLevel) { this.currentLevel = currentLevel; }

        public int getTotalKills() { return totalKills; }
        public void setTotalKills(int totalKills) { this.totalKills = totalKills; }
        public void incrementKills() { this.totalKills++; }

        public int getExperience() { return experience; }
        public void setExperience(int experience) { this.experience = experience; }
        public void addExperience(int amount) { this.experience += amount; }

        public Map<String, Integer> getSkillLevels() { return skillLevels; }

        public int getSkillLevel(String skillId) {
            return skillLevels.getOrDefault(skillId, 0);
        }

        public void setSkillLevel(String skillId, int level) {
            skillLevels.put(skillId, level);
        }
    }
}
