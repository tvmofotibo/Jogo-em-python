package com.dogapocalypse.menu;

import com.dogapocalypse.core.DogApocalypsePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

/**
 * Menu de gerenciamento de grupo (coop).
 */
public class MenuGrupo {

    public static final String TITULO = "§8§l👥 Gerenciar Grupo";

    public static void abrir(Player player, DogApocalypsePlugin plugin) {
        Inventory inv = Bukkit.createInventory(null, 45, TITULO);

        // Bordas
        for (int i = 0; i < 9; i++) {
            inv.setItem(i,      MenuUtils.borda(Material.YELLOW_STAINED_GLASS_PANE));
            inv.setItem(36 + i, MenuUtils.borda(Material.GRAY_STAINED_GLASS_PANE));
        }
        inv.setItem(9,  MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(17, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(18, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(26, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(27, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(35, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));

        List<Player> membros = plugin.getCoopManager().getPartyMembers(player);

        // Slots dos membros (10, 12, 14, 16)
        int[] slotsMembros = {10, 12, 14, 16};
        for (int i = 0; i < 4; i++) {
            if (i < membros.size()) {
                Player membro = membros.get(i);
                var classMembro = plugin.getPlayerClassManager().getClass(membro);

                // Cabeça do jogador
                var skull = new org.bukkit.inventory.ItemStack(Material.PLAYER_HEAD);
                var skullMeta = (SkullMeta) skull.getItemMeta();
                if (skullMeta != null) {
                    skullMeta.setOwningPlayer(membro);
                    skullMeta.setDisplayName(
                        com.dogapocalypse.util.MessageUtil.color("&f" + membro.getName()));
                    skullMeta.setLore(List.of(
                        com.dogapocalypse.util.MessageUtil.color("&7Classe: " + classMembro.getDisplayName()),
                        com.dogapocalypse.util.MessageUtil.color("&7Vida: &c" +
                            (int)membro.getHealth() + "/" + (int)membro.getMaxHealth()),
                        "",
                        membro.equals(player) ? com.dogapocalypse.util.MessageUtil.color("&a(Você)") :
                        com.dogapocalypse.util.MessageUtil.color("&cClique para expulsar do grupo")
                    ));
                    skull.setItemMeta(skullMeta);
                }
                inv.setItem(slotsMembros[i], skull);
            } else {
                inv.setItem(slotsMembros[i], MenuUtils.item(Material.LIGHT_GRAY_DYE,
                    "&8Slot vazio",
                    "&7Convide um amigo para jogar junto!"
                ));
            }
        }

        // Ações do grupo
        // Convidar jogador
        inv.setItem(20, MenuUtils.item(Material.EMERALD,
            "&a&l+ Convidar Jogador",
            "&7Digite o nome de um jogador online.",
            "&7Use o chat após clicar.",
            "",
            "&eClique para convidar!"
        ));

        // Sair do grupo
        inv.setItem(22, MenuUtils.item(Material.REDSTONE,
            "&c&l✖ Sair do Grupo",
            "&7Remove você do grupo atual.",
            "",
            "&cClique para sair!"
        ));

        // Status
        inv.setItem(24, MenuUtils.item(Material.PAPER,
            "&7&lStatus do Grupo",
            "&7Membros: &f" + membros.size() + "/4",
            "&7Fase: &e" + plugin.getPlayerDataManager().get(player).getCurrentLevel()
        ));

        // Voltar
        inv.setItem(40, MenuUtils.item(Material.ARROW,
            "&e← Voltar ao Menu Principal",
            "&7Retorna ao menu anterior."
        ));

        player.openInventory(inv);
    }
}
