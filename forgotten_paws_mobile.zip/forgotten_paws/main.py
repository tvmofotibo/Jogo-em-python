import asyncio
import pygame
import math
import random
import sys

pygame.init()

# ── Constants ──────────────────────────────────────────────────────────────────
W, H = 960, 540
FPS  = 60
GRAVITY = 0.55
TILE  = 32

WHITE  = (255, 255, 255)
BLACK  = (0,   0,   0)
RED    = (200,  30,  30)
GREEN  = ( 50, 200,  50)
BLUE   = ( 50, 100, 220)
YELLOW = (230, 200,  40)
PURPLE = (160,  60, 220)
ORANGE = (220, 120,  30)
CYAN   = ( 40, 200, 200)
DARK   = ( 12,  12,  20)

screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("FORGOTTEN PAWS")
clock  = pygame.time.Clock()

# ── Fonts ──────────────────────────────────────────────────────────────────────
try:
    font_big   = pygame.font.SysFont("monospace", 48, bold=True)
    font_med   = pygame.font.SysFont("monospace", 24, bold=True)
    font_small = pygame.font.SysFont("monospace", 14)
    font_tiny  = pygame.font.SysFont("monospace", 11)
except Exception:
    font_big   = pygame.font.Font(None, 48)
    font_med   = pygame.font.Font(None, 24)
    font_small = pygame.font.Font(None, 16)
    font_tiny  = pygame.font.Font(None, 12)

# ── Helpers ────────────────────────────────────────────────────────────────────
def draw_text(surf, text, font, color, cx, cy, center=True):
    s = font.render(text, True, color)
    r = s.get_rect()
    if center:
        r.center = (cx, cy)
    else:
        r.topleft = (cx, cy)
    surf.blit(s, r)

def lerp(a, b, t):
    return a + (b - a) * t


# ══════════════════════════════════════════════════════════════════════════════
# MOBILE / TOUCH CONTROL SYSTEM
# ══════════════════════════════════════════════════════════════════════════════
# Layout (portrait-friendly landscape):
#
#  LEFT SIDE                        RIGHT SIDE
#  ┌──────────────────────────────────────────────┐
#  │                                              │
#  │   [◀]  [▶]              [SP] [ATK] [RNG]    │
#  │       [▲]                    [JMP]           │
#  └──────────────────────────────────────────────┘
#
# All buttons are rendered on-screen and respond to MOUSEBUTTONDOWN /
# MOUSEBUTTONUP events (which Pygame maps from touch events in Pygbag).

BTN_ALPHA  = 160   # button face alpha
BTN_RADIUS = 32    # default button radius

class TouchButton:
    """Single circular touch/click button."""
    def __init__(self, label, cx, cy, radius, color, action):
        self.label  = label
        self.cx     = cx
        self.cy     = cy
        self.radius = radius
        self.color  = color
        self.action = action       # string key fed into virtual_keys
        self.pressed = False

    def contains(self, x, y):
        return math.hypot(x - self.cx, y - self.cy) <= self.radius * 1.3

    def draw(self, surf):
        r = self.radius
        # shadow
        pygame.draw.circle(surf, (0, 0, 0), (self.cx + 3, self.cy + 3), r)
        # body
        col = self.color
        if self.pressed:
            col = tuple(min(255, c + 60) for c in col)
        face = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
        pygame.draw.circle(face, (*col, BTN_ALPHA), (r, r), r)
        pygame.draw.circle(face, (*col, 220),       (r, r), r, 2)
        surf.blit(face, (self.cx - r, self.cy - r))
        # label
        lbl = font_tiny.render(self.label, True, WHITE)
        surf.blit(lbl, (self.cx - lbl.get_width()//2,
                        self.cy - lbl.get_height()//2))


class MobileControls:
    """
    Full on-screen D-pad + action buttons for P1 (KIRA / single-player mobile).
    Virtual key state is merged into the keyboard state dict by the main loop.
    """
    def __init__(self):
        # virtual key state  →  injected into keys[] each frame
        self.state = {
            "left": False, "right": False, "up": False, "down": False,
            "attack": False, "ranged": False, "special": False,
        }
        self._touch_map = {}   # finger_id → button action
        self._build_buttons()
        self.visible = True

    def _build_buttons(self):
        # D-pad  (bottom-left)
        pad_cx, pad_cy = 90, H - 90
        r = BTN_RADIUS
        self.buttons = [
            TouchButton("◀", pad_cx - r - 8, pad_cy,       r, (70,70,90),  "left"),
            TouchButton("▶", pad_cx + r + 8, pad_cy,       r, (70,70,90),  "right"),
            TouchButton("▲", pad_cx,          pad_cy - r - 8, r, (70,90,70),"up"),
            TouchButton("▼", pad_cx,          pad_cy + r + 8, r, (70,70,70),"down"),
        ]
        # Action buttons  (bottom-right)
        ax = W - 90
        ay = H - 90
        self.buttons += [
            TouchButton("ATK", ax,        ay,       r,   (160, 40, 40), "attack"),
            TouchButton("TIR", ax - r*2 - 6, ay,   r,   (40, 40, 160), "ranged"),
            TouchButton("ESP", ax - r - 3,  ay - r*2 - 6, r, (120, 40, 140), "special"),
            TouchButton("⬆",  ax - r*2 - 6, ay - r*2 - 6, r, (40, 130, 60), "up"),
        ]

    def reset(self):
        for k in self.state:
            self.state[k] = False

    def handle_event(self, event):
        """Call from the event loop. Returns True if event was consumed."""
        if not self.visible:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            for btn in self.buttons:
                if btn.contains(mx, my):
                    btn.pressed = True
                    self.state[btn.action] = True
                    self._touch_map[event.button] = btn.action
                    return True

        elif event.type == pygame.MOUSEBUTTONUP:
            action = self._touch_map.pop(event.button, None)
            if action:
                self.state[action] = False
                for btn in self.buttons:
                    if btn.action == action:
                        btn.pressed = False
                return True

        elif event.type == pygame.MOUSEMOTION:
            # drag: re-evaluate which button each pressed finger is over
            mx, my = event.pos
            for btn in self.buttons:
                if btn.pressed and not btn.contains(mx, my):
                    btn.pressed = False
                    self.state[btn.action] = False

        return False

    def inject_into_keys(self, vkeys):
        """Merge virtual keys into a mutable dict-like object."""
        vkeys["mobile_left"]    = self.state["left"]
        vkeys["mobile_right"]   = self.state["right"]
        vkeys["mobile_up"]      = self.state["up"]
        vkeys["mobile_down"]    = self.state["down"]
        vkeys["mobile_attack"]  = self.state["attack"]
        vkeys["mobile_ranged"]  = self.state["ranged"]
        vkeys["mobile_special"] = self.state["special"]

    def draw(self, surf):
        if not self.visible:
            return
        for btn in self.buttons:
            btn.draw(surf)


mobile = MobileControls()


# Thin wrapper so we can merge keyboard + touch into one dict
class MergedKeys:
    """
    Wraps pygame.key.get_pressed() and overlays mobile virtual keys for P1.
    Player.update() queries this via keys[pygame_keycode] — we remap the
    P1 control set (WASD+ZXC) to also respond to mobile buttons.
    """
    # P1 key indices in CTRL[0]:  left=K_a right=K_d up=K_w down=K_s atk=K_z rng=K_x spec=K_c
    P1_MAP = {
        pygame.K_a: "mobile_left",
        pygame.K_d: "mobile_right",
        pygame.K_w: "mobile_up",
        pygame.K_s: "mobile_down",
        pygame.K_z: "mobile_attack",
        pygame.K_x: "mobile_ranged",
        pygame.K_c: "mobile_special",
    }

    def __init__(self):
        self._kb    = None   # set each frame
        self._extra = {}

    def refresh(self):
        self._kb = pygame.key.get_pressed()
        mobile.inject_into_keys(self._extra)

    def __getitem__(self, key):
        kb_val = self._kb[key] if self._kb else False
        mob_key = self.P1_MAP.get(key)
        mob_val = self._extra.get(mob_key, False) if mob_key else False
        return kb_val or mob_val


merged_keys = MergedKeys()


# ══════════════════════════════════════════════════════════════════════════════
# PARTICLE SYSTEM
# ══════════════════════════════════════════════════════════════════════════════
class Particle:
    __slots__ = ("x","y","vx","vy","color","life","max_life","size")
    def __init__(self, x, y, vx, vy, color, life, size=3):
        self.x, self.y     = float(x), float(y)
        self.vx, self.vy   = vx, vy
        self.color         = color
        self.life          = life
        self.max_life      = life
        self.size          = size

    def update(self):
        self.x  += self.vx
        self.y  += self.vy
        self.vy += 0.18
        self.vx *= 0.93
        self.life -= 1

    def draw(self, surf, cam_x):
        if self.life <= 0:
            return
        alpha  = max(0, self.life / self.max_life)
        radius = max(1, int(self.size * alpha))
        sx     = int(self.x - cam_x)
        sy     = int(self.y)
        if -10 < sx < W + 10 and -10 < sy < H + 10:
            pygame.draw.circle(surf, self.color, (sx, sy), radius)


class ParticleSystem:
    def __init__(self):
        self.particles = []

    def emit(self, x, y, vx, vy, color, life, size=3):
        self.particles.append(Particle(x, y, vx, vy, color, life, size))

    def burst(self, x, y, color, count=10, speed=4, size=3):
        for i in range(count):
            a = random.uniform(0, math.tau)
            s = random.uniform(speed * 0.4, speed)
            self.emit(x, y, math.cos(a)*s, math.sin(a)*s, color,
                      random.randint(20, 40), size)

    def blood(self, x, y):
        self.burst(x, y, (180, 20, 20), 12, 5, 3)

    def spark(self, x, y):
        self.burst(x, y, YELLOW, 8, 6, 2)

    def magic(self, x, y, color=PURPLE):
        self.burst(x, y, color, 14, 4, 3)

    def absorb(self, x, y):
        for _ in range(20):
            a = random.uniform(0, math.tau)
            r = random.uniform(20, 60)
            ox, oy = x + math.cos(a)*r, y + math.sin(a)*r
            self.emit(ox, oy, -math.cos(a)*2.5, -math.sin(a)*2.5,
                      GREEN, 40, 4)

    def update(self):
        alive = []
        for p in self.particles:
            p.update()
            if p.life > 0:
                alive.append(p)
        self.particles = alive

    def draw(self, surf, cam_x):
        for p in self.particles:
            p.draw(surf, cam_x)


ps = ParticleSystem()


# ══════════════════════════════════════════════════════════════════════════════
# FLOATING TEXT
# ══════════════════════════════════════════════════════════════════════════════
class FloatText:
    def __init__(self, x, y, text, color, life=55):
        self.x, self.y = float(x), float(y)
        self.text  = text
        self.color = color
        self.life  = life
        self.max_life = life

    def update(self):
        self.y  -= 0.9
        self.life -= 1

    def draw(self, surf, cam_x):
        alpha = max(0, self.life / self.max_life)
        col   = tuple(int(c * alpha) for c in self.color)
        s     = font_small.render(self.text, True, col)
        surf.blit(s, (int(self.x - cam_x - s.get_width()//2), int(self.y)))


floats = []

def add_float(x, y, text, color=WHITE):
    floats.append(FloatText(x, y, text, color))


# ══════════════════════════════════════════════════════════════════════════════
# PLAYER CHARACTERS
# ══════════════════════════════════════════════════════════════════════════════
CHAR_DEFS = [
    # name,  color,    sp, jump,  max_hp, max_mp, ctrl_set
    ("KIRA",  PURPLE,  4.2, 13.5,  100,    80,    0),
    ("REX",   GREEN,   4.5, 15.0,   90,   120,    1),
    ("VALE",  ORANGE,  3.8, 14.0,   85,   100,    2),
    ("ZAP",   CYAN,    3.2, 13.0,  120,    60,    3),
]

# Control sets  [left, right, up, down, attack, ranged, special]
CTRL = [
    [pygame.K_a,      pygame.K_d,      pygame.K_w,     pygame.K_s,     pygame.K_z,     pygame.K_x,     pygame.K_c    ],
    [pygame.K_LEFT,   pygame.K_RIGHT,  pygame.K_UP,    pygame.K_DOWN,  pygame.K_u,     pygame.K_i,     pygame.K_o    ],
    [pygame.K_j,      pygame.K_l,      pygame.K_i,     pygame.K_k,     pygame.K_n,     pygame.K_m,     pygame.K_COMMA],
    [pygame.K_KP4,    pygame.K_KP6,    pygame.K_KP8,   pygame.K_KP5,   pygame.K_KP7,   pygame.K_KP9,   pygame.K_KP1  ],
]

POWERS = {
    "none":     {"name": "—",        "color": GREEN},
    "fire":     {"name": "FOGO",     "color": (255, 80,  10)},
    "climb":    {"name": "ESCALAR",  "color": (139, 69,  19)},
    "swim":     {"name": "NADAR",    "color": BLUE},
    "electric": {"name": "ELÉTRICO", "color": YELLOW},
}

ENEMY_POWER = {
    "rat":    "none",
    "insect": "electric",
    "monkey": "climb",
    "robot":  "electric",
    "dragon": "fire",
}


class Player:
    SIZE = (28, 38)

    def __init__(self, char_idx, slot):
        name, color, sp, jump, hp, mp, cs = CHAR_DEFS[char_idx]
        self.name        = name
        self.color       = color
        self.speed       = sp
        self.jump_force  = jump
        self.max_hp      = hp
        self.max_mp      = mp
        self.ctrl        = CTRL[cs]
        self.is_rex      = (char_idx == 1)
        self.slot        = slot

        self.x = 80.0 + slot * 35
        self.y = 350.0
        self.vx = 0.0
        self.vy = 0.0
        self.w, self.h = self.SIZE
        self.on_ground   = False
        self.jumps_left  = 2
        self.facing      = 1
        self.hp          = float(hp)
        self.mp          = float(mp)
        self.dead        = False
        self.invincible  = 0
        self.atk_cd      = 0
        self.spec_cd     = 0
        self.anim_t      = 0
        self.anim_f      = 0
        self.state       = "idle"
        self.state_t     = 0

        # Rex powers
        self.power        = "none"
        self.power_timer  = 0
        self.power_bank   = ["none"]

        # held-key flags
        self._jump_held = self._atk_held = self._spec_held = self._slide_held = False

    # ── update ────────────────────────────────────────────────────────────────
    def update(self, keys, platforms, enemies, projectiles, dt):
        if self.dead:
            return

        c = self.ctrl
        # timers
        if self.atk_cd  > 0: self.atk_cd  -= 1
        if self.spec_cd > 0: self.spec_cd -= 1
        if self.invincible > 0: self.invincible -= 1
        if self.power_timer > 0:
            self.power_timer -= 1
        elif self.is_rex and self.power != "none":
            self.power = "none"

        # horizontal
        moving = False
        if keys[c[0]]:
            self.vx = -self.speed; self.facing = -1; moving = True
        elif keys[c[1]]:
            self.vx =  self.speed; self.facing =  1; moving = True
        else:
            self.vx *= 0.75

        # jump
        if keys[c[2]]:
            if not self._jump_held and self.jumps_left > 0:
                self.vy = -self.jump_force
                self.jumps_left -= 1
                ps.burst(self.x + self.w/2, self.y + self.h, self.color, 6, 2)
                self._jump_held = True
        else:
            self._jump_held = False

        # slide
        if keys[c[3]] and self.on_ground and not self._slide_held:
            self.vx += self.facing * 9
            ps.burst(self.x + self.w/2, self.y + self.h, (100,100,100), 4, 2)
            self._slide_held = True
        elif not keys[c[3]]:
            self._slide_held = False

        # attack
        if keys[c[4]] and self.atk_cd == 0 and not self._atk_held:
            self._do_attack(enemies, projectiles)
            self.atk_cd = 22
            self._atk_held = True
            self.state = "attack"; self.state_t = 16
        elif not keys[c[4]]:
            self._atk_held = False

        # ranged
        if keys[c[5]] and self.atk_cd == 0 and not self._atk_held:
            self._do_ranged(projectiles)
            self.atk_cd = 28
            self._atk_held = True
        elif not keys[c[5]]:
            pass  # share cooldown flag above

        # special
        if keys[c[6]] and self.spec_cd == 0 and self.mp >= 30 and not self._spec_held:
            self._do_special(enemies, projectiles)
            self.spec_cd = 90
            self.mp -= 30
            self._spec_held = True
            self.state = "special"; self.state_t = 22
        elif not keys[c[6]]:
            self._spec_held = False

        # physics
        self.vy += GRAVITY
        self.vy  = min(self.vy, 16)
        self.x  += self.vx
        self.y  += self.vy

        # boundaries
        if self.x < 0: self.x = 0
        if self.x + self.w > current_level_width():
            self.x = current_level_width() - self.w

        # platform collision
        self.on_ground = False
        rect = self.get_rect()
        for p in platforms:
            pr = p.get_rect()
            if rect.colliderect(pr):
                # from above
                if self.vy >= 0 and rect.bottom - pr.top < 18 and rect.top < pr.top:
                    self.y = pr.top - self.h
                    self.vy = 0
                    self.on_ground = True
                    self.jumps_left = 2
                # from below
                elif self.vy < 0 and pr.bottom - rect.top < 14 and rect.bottom > pr.bottom:
                    self.y = pr.bottom
                    self.vy = 0

        # fall death
        if self.y > H + 120:
            self.take_damage(9999)

        # mp regen
        self.anim_t += 1
        if self.anim_t >= 8:
            self.anim_t = 0
            self.anim_f = (self.anim_f + 1) % 4
        if self.state_t > 0:
            self.state_t -= 1
        else:
            if not self.on_ground: self.state = "jump"
            elif moving: self.state = "run"
            else: self.state = "idle"

        # slow mp regen
        self.mp = min(self.max_mp, self.mp + 0.04)

    # ── combat helpers ────────────────────────────────────────────────────────
    def _do_attack(self, enemies, projectiles):
        cx = self.x + self.w/2 + self.facing * 30
        cy = self.y + self.h/2
        hit = False
        for e in enemies:
            if e.dead: continue
            if abs(e.x + e.w/2 - cx) < 55 and abs(e.y + e.h/2 - cy) < 45:
                dmg = random.randint(18, 28)
                if self.is_rex and self.power == "fire":     dmg = int(dmg * 1.5)
                if self.is_rex and self.power == "electric": dmg = int(dmg * 1.3)
                e.take_damage(dmg, self)
                ps.blood(e.x + e.w/2, e.y + e.h/2)
                hit = True
        if game_state.boss and not game_state.boss.dead:
            b = game_state.boss
            if abs(b.x + b.w/2 - cx) < 65 and abs(b.y + b.h/2 - cy) < 65:
                b.take_damage(random.randint(14, 22))
                ps.blood(b.x + b.w/2, b.y + b.h/2)
        if not hit:
            ps.spark(cx, cy)

    def _do_ranged(self, projectiles):
        col = self.color
        spd = 9
        dmg = 12
        if self.is_rex:
            if self.power == "fire":     col = (255, 80, 10);  dmg = 20
            if self.power == "electric": col = YELLOW;          dmg = 16
        projectiles.append(Projectile(
            self.x + self.w/2, self.y + self.h/2 - 5,
            self.facing * spd, 0, col, dmg, 80, "player", self.slot))

    def _do_special(self, enemies, projectiles):
        cx, cy = self.x + self.w/2, self.y + self.h/2
        if self.is_rex:
            pwr = self.power
            if pwr == "fire":
                for dy in (-1, 0, 1):
                    projectiles.append(Projectile(cx, cy,
                        self.facing * 8, dy * 1.5,
                        (255, 80, 10), 30, 60, "player", self.slot))
                ps.burst(cx, cy, (255, 80, 10), 18, 7)
            elif pwr == "electric":
                for e in enemies:
                    if not e.dead and math.hypot(e.x - self.x, e.y - self.y) < 160:
                        e.take_damage(35, self)
                        ps.spark(e.x + e.w/2, e.y + e.h/2)
                if game_state.boss:
                    game_state.boss.take_damage(25)
                ps.burst(cx, cy, YELLOW, 20, 8)
            else:
                for i in range(8):
                    a = math.tau / 8 * i
                    projectiles.append(Projectile(cx, cy,
                        math.cos(a) * 6, math.sin(a) * 6,
                        GREEN, 22, 45, "player", self.slot))
                ps.magic(cx, cy)
        elif self.name == "KIRA":
            self.vx = self.facing * 18
            self.invincible = 22
            for e in enemies:
                if not e.dead and abs(e.x - self.x) < 180 and abs(e.y - self.y) < 50:
                    e.take_damage(42, self)
                    ps.blood(e.x + e.w/2, e.y + e.h/2)
            ps.burst(cx, cy, PURPLE, 15, 5)
        elif self.name == "VALE":
            for i in range(6):
                projectiles.append(Projectile(
                    cx + self.facing * i * 18, cy - 30,
                    self.facing * 4, -6 + i * 0.5,
                    ORANGE, 18, 80, "player", self.slot))
            ps.burst(cx, cy, ORANGE, 10, 4)
        elif self.name == "ZAP":
            for e in enemies:
                if not e.dead and math.hypot(e.x - self.x, e.y - self.y) < 130:
                    e.take_damage(45, self)
                    e.stun = 60
                    ps.spark(e.x + e.w/2, e.y + e.h/2)
            if game_state.boss:
                if math.hypot(game_state.boss.x - self.x, game_state.boss.y - self.y) < 130:
                    game_state.boss.take_damage(30)
            ps.burst(cx, cy, CYAN, 20, 6)

    def absorb_from_enemy(self, etype):
        if not self.is_rex:
            return
        pwr = ENEMY_POWER.get(etype, "none")
        if pwr != "none" and pwr not in self.power_bank:
            self.power_bank.append(pwr)
        self.power       = pwr
        self.power_timer = 600
        ps.absorb(self.x + self.w/2, self.y + self.h/2)
        if pwr != "none":
            add_float(self.x, self.y - 24,
                      f"PODER: {POWERS[pwr]['name']}!", POWERS[pwr]['color'])

    def take_damage(self, dmg):
        if self.invincible > 0 or self.dead:
            return
        self.hp -= dmg
        self.invincible = 48
        self.state = "hurt"; self.state_t = 16
        ps.blood(self.x + self.w/2, self.y + self.h/2)
        if self.hp <= 0:
            self.hp   = 0
            self.dead = True
            ps.burst(self.x + self.w/2, self.y + self.h/2, self.color, 22, 8)

    def get_rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    # ── draw ──────────────────────────────────────────────────────────────────
    def draw(self, surf, cam_x):
        if self.dead:
            return
        sx = int(self.x - cam_x)
        sy = int(self.y)
        if sx < -60 or sx > W + 60:
            return

        # flash on invincible
        if self.invincible > 0 and (self.invincible // 4) % 2 == 1:
            return

        if self.is_rex:
            self._draw_rex(surf, sx, sy)
        else:
            self._draw_human(surf, sx, sy)

        # name tag
        ns = font_tiny.render(self.name, True, self.color)
        surf.blit(ns, (sx + self.w//2 - ns.get_width()//2, sy - 14))

        # Rex power icon
        if self.is_rex and self.power != "none":
            ic = font_tiny.render(f"[{POWERS[self.power]['name']}]",
                                  True, POWERS[self.power]['color'])
            surf.blit(ic, (sx - 2, sy - 24))

    def _draw_human(self, surf, sx, sy):
        c  = self.color
        dc = tuple(max(0, v - 80) for v in c)
        bob = int(math.sin(self.anim_f * math.pi / 2) * 2) if self.state == "run" else 0
        ls  = int(math.sin(self.anim_f * math.pi / 2) * 6) if self.state == "run" else 0

        # legs
        pygame.draw.rect(surf, dc,   (sx + 2,  sy + 22 + bob, 10, 14 + ls))
        pygame.draw.rect(surf, dc,   (sx + 14, sy + 22 + bob, 10, 14 - ls))
        # body
        pygame.draw.rect(surf, dc,   (sx,      sy + 8 + bob,  self.w, 18))
        pygame.draw.rect(surf, c,    (sx + 1,  sy + 9 + bob,  self.w-2, 16))
        # head
        pygame.draw.rect(surf, (230, 190, 150), (sx + 4, sy - 6 + bob, 18, 14))
        pygame.draw.rect(surf, dc,   (sx + 4,  sy - 7 + bob,  18, 6))
        # eye
        ex = sx + 14 + (4 if self.facing > 0 else -4)
        pygame.draw.circle(surf, WHITE, (ex, sy - 2 + bob), 3)
        pygame.draw.circle(surf, BLACK, (ex + self.facing, sy - 2 + bob), 2)
        # weapon indicator
        if self.state == "attack" and self.state_t > 4:
            pygame.draw.rect(surf, WHITE,
                (sx + self.w//2 + self.facing*10, sy + 6 + bob,
                 self.facing*28 if self.facing > 0 else -self.facing*28, 4))

    def _draw_rex(self, surf, sx, sy):
        c   = GREEN
        pwr = self.power
        gc  = POWERS[pwr]['color'] if pwr != "none" else c

        # body
        pygame.draw.ellipse(surf, (90, 58, 26),
                            (sx + 2, sy + 10, 26, 22))
        if pwr != "none":
            pygame.draw.ellipse(surf, (*gc, 120) if len(gc)==3 else gc,
                                (sx + 4, sy + 12, 22, 18), 2)
        # head
        pygame.draw.ellipse(surf, (100, 66, 30),
                            (sx + 12, sy - 4, 20, 18))
        # ears
        pygame.draw.polygon(surf, (80, 48, 20),
                            [(sx+14, sy-4), (sx+12, sy-14), (sx+18, sy-4)])
        pygame.draw.polygon(surf, (80, 48, 20),
                            [(sx+22, sy-4), (sx+26, sy-12), (sx+28, sy-4)])
        # eyes
        ex = sx + 18 + (2 if self.facing > 0 else -2)
        pygame.draw.circle(surf, WHITE, (ex, sy + 2), 4)
        pygame.draw.circle(surf, gc,   (ex + self.facing, sy + 2), 2)
        # snout
        pygame.draw.ellipse(surf, (230, 160, 90),
                            (sx + 22, sy + 4, 10, 8))
        # tail
        tail_wag = int(math.sin(pygame.time.get_ticks() * 0.008) * 10)
        pygame.draw.arc(surf, (90, 58, 26),
                        (sx - 14 + tail_wag, sy + 4, 14, 18),
                        math.pi * 0.2, math.pi * 1.2, 4)
        # power glow ring
        if pwr == "fire":
            pygame.draw.circle(surf, (255, 100, 20),
                               (sx + 14, sy + 5), 18, 2)
        elif pwr == "electric":
            pygame.draw.circle(surf, YELLOW,
                               (sx + 14, sy + 5), 18, 2)


# ══════════════════════════════════════════════════════════════════════════════
# PROJECTILE
# ══════════════════════════════════════════════════════════════════════════════
class Projectile:
    def __init__(self, x, y, vx, vy, color, dmg, life, owner_type, owner_idx=0):
        self.x, self.y = float(x), float(y)
        self.vx, self.vy = vx, vy
        self.color      = color
        self.dmg        = dmg
        self.life       = life
        self.owner_type = owner_type   # "player" or "enemy"
        self.owner_idx  = owner_idx
        self.w, self.h  = 10, 6
        self.dead       = False

    def update(self, platforms, players, enemies):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.06
        self.life -= 1
        if self.life <= 0:
            self.dead = True; return

        # hit platform
        r = pygame.Rect(int(self.x), int(self.y), self.w, self.h)
        for p in platforms:
            if r.colliderect(p.get_rect()):
                ps.spark(self.x, self.y)
                self.dead = True; return

        if self.owner_type == "player":
            # hit enemies
            for e in enemies:
                if e.dead: continue
                if r.colliderect(e.get_rect()):
                    att = None
                    for pl in players:
                        if pl.slot == self.owner_idx:
                            att = pl; break
                    e.take_damage(self.dmg, att)
                    ps.spark(self.x, self.y)
                    self.dead = True; return
            # hit boss
            if game_state.boss and not game_state.boss.dead:
                if r.colliderect(game_state.boss.get_rect()):
                    game_state.boss.take_damage(self.dmg)
                    ps.spark(self.x, self.y)
                    self.dead = True; return
        else:
            for pl in players:
                if pl.dead or pl.invincible > 0: continue
                if r.colliderect(pl.get_rect()):
                    pl.take_damage(self.dmg)
                    self.dead = True; return

    def draw(self, surf, cam_x):
        sx = int(self.x - cam_x)
        if -20 < sx < W + 20:
            pygame.draw.ellipse(surf, self.color,
                                (sx, int(self.y), self.w, self.h))
            # glow
            glow = pygame.Surface((self.w + 8, self.h + 8), pygame.SRCALPHA)
            r, g, b = self.color
            pygame.draw.ellipse(glow, (r, g, b, 60),
                                (0, 0, self.w + 8, self.h + 8))
            surf.blit(glow, (sx - 4, int(self.y) - 4))


# ══════════════════════════════════════════════════════════════════════════════
# ENEMY
# ══════════════════════════════════════════════════════════════════════════════
ENEMY_DATA = {
    #           hp   w   h   spd dmg  score
    "rat":    ( 45,  22, 18, 2.2,  8,   50),
    "insect": ( 38,  20, 16, 1.8, 12,   75),
    "monkey": ( 65,  26, 32, 3.0, 15,  100),
    "robot":  ( 85,  28, 36, 2.0, 20,  150),
    "dragon": (130,  40, 36, 2.8, 25,  200),
}

ENEMY_COLORS = {
    "rat":    (130,  80,  40),
    "insect": ( 40, 110,   0),
    "monkey": (100,  55,  10),
    "robot":  ( 60,  90, 120),
    "dragon": (160,  10,  10),
}


class Enemy:
    def __init__(self, etype, x, y):
        self.etype = etype
        hp, w, h, spd, dmg, score = ENEMY_DATA[etype]
        self.hp      = float(hp)
        self.max_hp  = float(hp)
        self.w, self.h = w, h
        self.speed   = spd
        self.dmg     = dmg
        self.score   = score
        self.color   = ENEMY_COLORS[etype]

        self.x, self.y  = float(x), float(y)
        self.vx = self.vy = 0.0
        self.on_ground   = False
        self.facing      = -1
        self.dead        = False
        self.stun        = 0
        self.atk_cd      = 0
        self.patrol_dir  = -1
        self.patrol_t    = 0
        self.start_x     = float(x)
        self.anim_t      = 0
        self.anim_f      = 0
        self.aggro_range = 260
        self.atk_range   = 55

    def take_damage(self, dmg, attacker=None):
        if self.dead: return
        self.hp -= dmg
        self.stun = 18
        add_float(self.x + self.w//2, self.y - 6, f"-{int(dmg)}", RED)
        if self.hp <= 0:
            self._die(attacker)

    def _die(self, attacker):
        self.dead = True
        ps.burst(self.x + self.w//2, self.y + self.h//2, self.color, 12, 5)
        ps.blood(self.x + self.w//2, self.y + self.h//2)
        game_state.score += self.score
        # Rex absorption
        rex = next((p for p in game_state.players if p.is_rex and not p.dead), None)
        if rex and math.hypot(rex.x - self.x, rex.y - self.y) < 240:
            rex.absorb_from_enemy(self.etype)

    def update(self, platforms, players):
        if self.dead: return
        if self.stun > 0:
            self.stun -= 1
        if self.atk_cd > 0:
            self.atk_cd -= 1

        self.anim_t += 1
        if self.anim_t >= 10:
            self.anim_t = 0
            self.anim_f = (self.anim_f + 1) % 4

        # find nearest player
        nearest = None
        near_d  = 9999.0
        for p in players:
            if p.dead: continue
            d = math.hypot(p.x - self.x, p.y - self.y)
            if d < near_d:
                near_d = d; nearest = p

        if nearest and near_d < self.aggro_range:
            self.facing = 1 if nearest.x > self.x else -1
            if self.stun == 0:
                self.vx = self.facing * self.speed

            # jump to reach player
            if self.on_ground and nearest.y < self.y - 50 and random.random() < 0.025:
                self.vy = -11

            # melee
            if near_d < self.atk_range + 12 and self.atk_cd == 0:
                nearest.take_damage(self.dmg)
                self.atk_cd = 65

            # ranged (insect / robot shoot)
            if self.etype in ("insect", "robot") and self.atk_cd == 0 and 80 < near_d < 280:
                dx = nearest.x - self.x; dy = nearest.y - self.y
                dd = math.hypot(dx, dy) or 1
                game_state.projectiles.append(
                    Projectile(self.x + self.w//2, self.y + self.h//2,
                               dx/dd*5, dy/dd*5,
                               (100, 255, 80) if self.etype == "insect" else CYAN,
                               self.dmg, 65, "enemy"))
                self.atk_cd = 85
        else:
            # patrol
            self.patrol_t += 1
            if self.patrol_t > 90:
                self.patrol_dir *= -1; self.patrol_t = 0
            if abs(self.x - self.start_x) > 140:
                self.patrol_dir = 1 if self.start_x > self.x else -1
            self.vx = self.patrol_dir * self.speed * 0.45
            self.facing = self.patrol_dir

        # physics
        self.vy += GRAVITY
        self.vy  = min(self.vy, 15)
        self.x  += self.vx
        self.y  += self.vy
        self.vx *= 0.85

        self.on_ground = False
        rect = self.get_rect()
        for p in platforms:
            pr = p.get_rect()
            if rect.colliderect(pr):
                if self.vy >= 0 and rect.bottom - pr.top < 20 and rect.top < pr.top:
                    self.y = pr.top - self.h
                    self.vy = 0
                    self.on_ground = True

    def get_rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def draw(self, surf, cam_x):
        if self.dead: return
        sx = int(self.x - cam_x)
        if sx < -60 or sx > W + 60: return

        # body shape per type
        c = self.color
        if self.etype == "rat":
            pygame.draw.ellipse(surf, c, (sx, int(self.y) + 2, self.w, self.h - 4))
            pygame.draw.ellipse(surf, c, (sx + 10, int(self.y) - 4, 14, 12))
            pygame.draw.circle(surf, RED,  (sx + 18, int(self.y) - 2), 3)
        elif self.etype == "insect":
            pygame.draw.ellipse(surf, c, (sx, int(self.y) + 2, self.w, self.h - 4))
            pygame.draw.ellipse(surf, c, (sx + 12, int(self.y) - 2, 12, 10))
            pygame.draw.line(surf, (80, 200, 0), (sx+8, int(self.y)+4), (sx-8, int(self.y)+10), 2)
            pygame.draw.line(surf, (80, 200, 0), (sx+8, int(self.y)+4), (sx-6, int(self.y)-2), 2)
            pygame.draw.line(surf, (80, 200, 0), (sx+16,int(self.y)+4), (sx+26,int(self.y)+10),2)
        elif self.etype == "monkey":
            pygame.draw.ellipse(surf, c, (sx + 2, int(self.y) + 8, 22, 24))
            pygame.draw.ellipse(surf, c, (sx + 6, int(self.y) - 6, 18, 20))
            pygame.draw.ellipse(surf, (180, 140, 60), (sx + 9, int(self.y) - 3, 12, 10))
            pygame.draw.circle(surf, RED, (sx + 12, int(self.y) - 2), 3)
        elif self.etype == "robot":
            pygame.draw.rect(surf, c,        (sx + 2, int(self.y) + 6, 24, 30))
            pygame.draw.rect(surf, c,        (sx + 4, int(self.y) - 4, 20, 14))
            pygame.draw.circle(surf, CYAN,   (sx + 9, int(self.y) + 1), 4)
            pygame.draw.circle(surf, CYAN,   (sx + 19,int(self.y) + 1), 4)
            pygame.draw.rect(surf, (20,20,20),(sx + 3, int(self.y) + 8, 22, 28), 1)
        elif self.etype == "dragon":
            pygame.draw.ellipse(surf, c, (sx, int(self.y) + 4, 40, 28))
            pygame.draw.ellipse(surf, c, (sx + 20, int(self.y) - 8, 22, 18))
            pygame.draw.polygon(surf, (100, 0, 0),
                [(sx+22, int(self.y)-8),(sx+26, int(self.y)-18),(sx+30, int(self.y)-8)])
            pygame.draw.polygon(surf, (100, 0, 0),
                [(sx+28, int(self.y)-8),(sx+32, int(self.y)-18),(sx+36, int(self.y)-8)])
            pygame.draw.circle(surf, (255, 100, 0), (sx+30, int(self.y)-2), 4)
            # wings
            pygame.draw.polygon(surf, (80, 0, 0),
                [(sx+10, int(self.y)+8),(sx-10,int(self.y)-10),(sx,int(self.y)+20)])
        else:
            pygame.draw.rect(surf, c, (sx, int(self.y), self.w, self.h))

        # HP bar
        bw = self.w
        hp_pct = max(0, self.hp / self.max_hp)
        pygame.draw.rect(surf, (40,40,40), (sx, int(self.y) - 8, bw, 4))
        col = GREEN if hp_pct > 0.5 else (YELLOW if hp_pct > 0.25 else RED)
        pygame.draw.rect(surf, col, (sx, int(self.y) - 8, int(bw * hp_pct), 4))


# ══════════════════════════════════════════════════════════════════════════════
# BOSS
# ══════════════════════════════════════════════════════════════════════════════
class Boss:
    def __init__(self, btype, x, y, name):
        self.btype  = btype
        self.name   = name
        self.x, self.y = float(x), float(y)
        self.w      = 90 if btype == "dragon_boss" else 76
        self.h      = 120 if btype == "dragon_boss" else 106
        self.max_hp = 900 if btype == "dragon_boss" else 700
        self.hp     = float(self.max_hp)
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.facing  = -1
        self.dead    = False
        self.phase   = 1
        self.rage    = False
        self.atk_cd  = 0
        self.atk_pat = 0
        self.stun    = 0
        self.anim_f  = 0
        self.anim_t  = 0

    def take_damage(self, dmg):
        if self.dead: return
        self.hp -= dmg
        add_float(self.x + self.w//2, self.y - 14, f"-{int(dmg)}", RED)
        ps.spark(self.x + self.w//2 + random.randint(-30,30), self.y + self.h//2)
        if not self.rage and self.hp < self.max_hp * 0.4:
            self.rage = True
            add_float(self.x + self.w//2, self.y - 40, "⚡ FASE 2!", (255, 50, 50))
            ps.burst(self.x + self.w//2, self.y + self.h//2, RED, 30, 10)
        if self.hp <= 0:
            self._die()

    def _die(self):
        self.dead = True
        game_state.score += 5000
        for i in range(6):
            dx = random.randint(-50, 50)
            dy = random.randint(0, 60)
            ps.burst(self.x + self.w//2 + dx, self.y + dy, YELLOW, 20, 8)
        game_state.boss_bar_visible = False
        game_state.level_cleared    = True

    def get_rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def update(self, platforms, players):
        if self.dead or self.stun > 0:
            self.stun -= 1; return

        self.anim_t += 1
        if self.anim_t >= 8:
            self.anim_t = 0
            self.anim_f = (self.anim_f + 1) % 4

        alive = [p for p in players if not p.dead]
        if not alive: return
        nearest = min(alive, key=lambda p: math.hypot(p.x - self.x, p.y - self.y))

        self.facing = 1 if nearest.x > self.x else -1
        spd = 3.8 if self.rage else 2.6
        self.vx = self.facing * spd

        # clamp to arena
        lvl_w = current_level_width()
        min_x = lvl_w - 700
        if self.x < min_x:        self.vx = abs(self.vx)
        if self.x + self.w > lvl_w - 10: self.vx = -abs(self.vx)

        # jump
        if self.on_ground and nearest.y < self.y - 70 and random.random() < 0.025:
            self.vy = -15

        # attacks
        self.atk_cd -= 1
        rate = 45 if self.rage else 75
        if self.atk_cd <= 0:
            self.atk_cd = rate
            self.atk_pat = (self.atk_pat + 1) % 3
            self._attack(nearest, players)

        # physics
        self.vy += GRAVITY
        self.vy  = min(self.vy, 16)
        self.x  += self.vx
        self.y  += self.vy
        self.vx *= 0.88

        self.on_ground = False
        rect = self.get_rect()
        for p in platforms:
            pr = p.get_rect()
            if rect.colliderect(pr):
                if self.vy >= 0 and rect.bottom - pr.top < 22 and rect.top < pr.top:
                    self.y = pr.top - self.h
                    self.vy = 0
                    self.on_ground = True

        # melee contact
        for pl in players:
            if pl.dead or pl.invincible > 0: continue
            if rect.colliderect(pl.get_rect()):
                pl.take_damage(26 if self.rage else 18)

    def _attack(self, nearest, players):
        cx = self.x + self.w//2; cy = self.y + self.h//3
        if self.atk_pat == 0:  # barrage
            count = 5 if self.rage else 3
            for i in range(count):
                dx = nearest.x - self.x; dy = nearest.y - self.y
                dd = math.hypot(dx, dy) or 1
                spread = (i - count//2) * 0.35
                game_state.projectiles.append(
                    Projectile(cx, cy,
                               dx/dd*7 + spread, dy/dd*7,
                               RED, 24, 85, "enemy"))
        elif self.atk_pat == 1:  # stomp
            if self.on_ground:
                for pl in players:
                    if not pl.dead and abs(pl.x - self.x) < 220:
                        pl.vy = -11
                        pl.take_damage(16)
                ps.burst(cx, self.y + self.h, (120, 70, 0), 20, 6)
        else:  # charge
            self.vx = self.facing * 14

    def draw(self, surf, cam_x):
        if self.dead: return
        sx = int(self.x - cam_x)
        if sx < -160 or sx > W + 160: return

        rc = (180, 0, 0) if not self.rage else (255, 0, 0)

        if self.btype == "monkey_boss":
            self._draw_monkey_boss(surf, sx, rc)
        else:
            self._draw_dragon_boss(surf, sx, rc)

    def _draw_monkey_boss(self, surf, sx, rc):
        sy = int(self.y)
        bob = int(math.sin(self.anim_f * math.pi/2) * 4)
        # legs
        pygame.draw.ellipse(surf, rc, (sx+10, sy+70+bob, 24, 36))
        pygame.draw.ellipse(surf, rc, (sx+42, sy+70+bob, 24, 36))
        # body
        pygame.draw.ellipse(surf, rc, (sx+4, sy+28+bob, 68, 56))
        # arms
        pygame.draw.ellipse(surf, rc, (sx-18, sy+20+bob, 26, 60))
        pygame.draw.ellipse(surf, rc, (sx+68, sy+20+bob, 26, 60))
        # head
        pygame.draw.ellipse(surf, rc, (sx+8, sy-10+bob, 60, 52))
        # face
        pygame.draw.ellipse(surf, (180, 120, 40), (sx+16, sy-4+bob, 44, 30))
        # eyes
        eye_c = (255, 0, 0) if self.rage else (255, 100, 0)
        pygame.draw.circle(surf, eye_c, (sx+22, sy-2+bob), 8)
        pygame.draw.circle(surf, eye_c, (sx+54, sy-2+bob), 8)
        pygame.draw.circle(surf, BLACK, (sx+22+self.facing*2, sy-2+bob), 4)
        pygame.draw.circle(surf, BLACK, (sx+54+self.facing*2, sy-2+bob), 4)
        # mutation spikes
        for i in range(5):
            a = math.tau/5*i - math.pi/2
            ox = int(math.cos(a)*34)
            oy = int(math.sin(a)*26)
            pygame.draw.line(surf, (0, 200, 50),
                             (sx+38, sy+16+bob),
                             (sx+38+ox, sy+16+oy+bob), 4)

    def _draw_dragon_boss(self, surf, sx, rc):
        sy = int(self.y)
        bob = int(math.sin(self.anim_f * math.pi/2) * 5)
        # wings
        dark = tuple(max(0, v-60) for v in rc)
        pygame.draw.polygon(surf, dark,
            [(sx+20,sy+30+bob),(sx-30,sy-20+bob),(sx+10,sy+70+bob)])
        pygame.draw.polygon(surf, dark,
            [(sx+70,sy+30+bob),(sx+120,sy-20+bob),(sx+80,sy+70+bob)])
        # body
        pygame.draw.ellipse(surf, rc, (sx+5, sy+30+bob, 80, 88))
        # neck
        pygame.draw.ellipse(surf, rc, (sx+20, sy-4+bob, 44, 46))
        # head
        pygame.draw.ellipse(surf, rc, (sx+15+self.facing*8, sy-28+bob, 56, 36))
        # horns
        pygame.draw.polygon(surf, (40,40,40),
            [(sx+24,sy-28+bob),(sx+20,sy-50+bob),(sx+30,sy-28+bob)])
        pygame.draw.polygon(surf, (40,40,40),
            [(sx+36,sy-30+bob),(sx+34,sy-52+bob),(sx+44,sy-30+bob)])
        # eyes
        eye_c = (255,0,0) if self.rage else (255, 120, 0)
        pygame.draw.circle(surf, eye_c, (sx+30, sy-16+bob), 9)
        pygame.draw.circle(surf, eye_c, (sx+50, sy-14+bob), 9)
        pygame.draw.circle(surf, YELLOW, (sx+30, sy-16+bob), 5)
        pygame.draw.circle(surf, YELLOW, (sx+50, sy-14+bob), 5)
        # tail
        pygame.draw.arc(surf, rc,
                        (sx-20+bob, sy+60, 30, 50),
                        math.pi*0.3, math.pi*1.4, 8)
        # fire breath during attack
        if self.atk_pat == 0 and self.atk_cd > rate_of(self) - 12:
            fx = sx + self.w + 10 if self.facing > 0 else sx - 40
            pygame.draw.ellipse(surf, (255, 80, 0), (fx, sy+20+bob, 50, 28))
            pygame.draw.ellipse(surf, YELLOW, (fx+8, sy+24+bob, 34, 20))


def rate_of(boss):
    return 45 if boss.rage else 75


# ══════════════════════════════════════════════════════════════════════════════
# PLATFORM
# ══════════════════════════════════════════════════════════════════════════════
class Platform:
    def __init__(self, x, y, w, h, color1=(30,30,48), color2=(18,18,30)):
        self.x, self.y = x, y
        self.w, self.h = w, h
        self.color1 = color1
        self.color2 = color2

    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.w, self.h)

    def draw(self, surf, cam_x):
        sx = self.x - cam_x
        if sx + self.w < -5 or sx > W + 5: return
        r  = pygame.Rect(int(sx), self.y, self.w, self.h)
        pygame.draw.rect(surf, self.color1, r)
        pygame.draw.rect(surf, self.color2, r, 1)
        # top highlight
        pygame.draw.line(surf, (60, 60, 90),
                         (int(sx), self.y), (int(sx)+self.w, self.y), 2)
        # cracks
        for i in range(0, self.w, 70):
            cx = int(sx) + i
            pygame.draw.line(surf, (0, 0, 0),
                             (cx, self.y), (cx+20, self.y+12), 1)


# ══════════════════════════════════════════════════════════════════════════════
# SPIKE
# ══════════════════════════════════════════════════════════════════════════════
class Spike:
    def __init__(self, x, y, count=5):
        self.x, self.y = x, y
        self.count     = count
        self.w         = count * 12

    def draw(self, surf, cam_x):
        sx = int(self.x - cam_x)
        if sx + self.w < -5 or sx > W + 5: return
        for i in range(self.count):
            bx = sx + i * 12
            pygame.draw.polygon(surf, (180, 30, 0),
                [(bx, self.y+20),(bx+6, self.y),(bx+12, self.y+20)])

    def check_players(self, players):
        for p in players:
            if p.dead: continue
            if (p.x + p.w > self.x and p.x < self.x + self.w and
                    p.y + p.h > self.y and p.y + p.h < self.y + 22):
                p.take_damage(35)


# ══════════════════════════════════════════════════════════════════════════════
# COLLECTIBLE
# ══════════════════════════════════════════════════════════════════════════════
class Collectible:
    def __init__(self, x, y, ctype):
        self.x, self.y  = float(x), float(y)
        self.ctype       = ctype
        self.collected   = False
        self.bob_off     = random.uniform(0, math.tau)
        self.w = self.h  = 20

    def update(self, players):
        if self.collected: return
        for p in players:
            if p.dead: continue
            if (abs(p.x - self.x) < 28 and abs(p.y - self.y) < 28):
                self.collected = True
                self._apply(p)

    def _apply(self, p):
        if self.ctype == "health":
            p.hp = min(p.max_hp, p.hp + 32)
            add_float(self.x, self.y - 12, "+32 HP", GREEN)
            ps.burst(self.x, self.y, GREEN, 8, 3)
        elif self.ctype == "memory":
            game_state.score       += 500
            game_state.memory_count += 1
            add_float(self.x, self.y - 12, "✦ MEMÓRIA", PURPLE)
            ps.magic(self.x, self.y)
            if game_state.memory_count == 2:
                game_state.trigger_memory = True
        elif self.ctype == "powerup":
            p.mp = p.max_mp
            add_float(self.x, self.y - 12, "PODER MAX!", YELLOW)
            ps.burst(self.x, self.y, YELLOW, 10, 4)

    def draw(self, surf, cam_x):
        if self.collected: return
        sx  = int(self.x - cam_x)
        bob = int(math.sin(pygame.time.get_ticks()*0.004 + self.bob_off) * 6)
        sy  = int(self.y) + bob
        if sx < -30 or sx > W + 30: return

        if self.ctype == "health":
            pygame.draw.circle(surf, RED, (sx, sy), 10)
            pygame.draw.rect(surf,  WHITE, (sx-2, sy-6, 4, 12))
            pygame.draw.rect(surf,  WHITE, (sx-6, sy-2, 12, 4))
        elif self.ctype == "memory":
            # star shape
            for i in range(5):
                a = math.tau/5*i - math.pi/2
                ox = int(math.cos(a)*10)
                oy = int(math.sin(a)*10)
                pygame.draw.circle(surf, PURPLE, (sx+ox, sy+oy), 3)
            pygame.draw.circle(surf, (200, 160, 255), (sx, sy), 5)
        elif self.ctype == "powerup":
            pygame.draw.polygon(surf, YELLOW,
                [(sx, sy-12),(sx+6, sy-2),(sx+12, sy-2),
                 (sx+4, sy+4),(sx+8, sy+14),(sx, sy+6),
                 (sx-8, sy+14),(sx-4, sy+4),(sx-12, sy-2),(sx-6, sy-2)])


# ══════════════════════════════════════════════════════════════════════════════
# LEVEL DEFINITIONS
# ══════════════════════════════════════════════════════════════════════════════
def make_level_1():
    plats = [
        # ground chunks
        Platform(0,   460, 380, 60),
        Platform(430, 460, 320, 60),
        Platform(810, 460, 480, 60),
        Platform(1350,460, 400, 60),
        Platform(1800,460, 320, 60),
        Platform(2180,460, 560, 60),
        Platform(2800,460, 420, 60),
        Platform(3270,460, 330, 60),
        # elevated
        Platform(180, 360, 140, 18),
        Platform(480, 320, 120, 18),
        Platform(680, 275, 100, 18),
        Platform(890, 340, 170, 18),
        Platform(1120,290, 120, 18),
        Platform(1380,318, 140, 18),
        Platform(1580,258, 100, 18),
        Platform(1840,328, 130, 18),
        Platform(2050,276, 150, 18),
        Platform(2280,316, 120, 18),
        Platform(2490,264, 100, 18),
        Platform(2690,336, 180, 18),
        Platform(2940,274, 150, 18),
        Platform(3090,224, 120, 18),
        Platform(3290,308, 170, 18),
    ]
    spikes = [
        Spike(390, 440, 3),
        Spike(1300,440, 3),
        Spike(1760,440, 4),
    ]
    enemies = [
        Enemy("rat",    580, 420),
        Enemy("rat",    840, 420),
        Enemy("insect", 990, 300),
        Enemy("rat",   1180, 420),
        Enemy("insect",1450, 278),
        Enemy("robot", 1680, 420),
        Enemy("insect",1930, 238),
        Enemy("robot", 2210, 420),
        Enemy("insect",2400, 224),
        Enemy("robot", 2590, 296),
        Enemy("robot", 2880, 420),
        Enemy("insect",3070, 184),
        Enemy("rat",   3180, 420),
        Enemy("dragon",3250, 420),
    ]
    collectibles = [
        Collectible(290, 322, "memory"),
        Collectible(880, 302, "health"),
        Collectible(1570,220, "memory"),
        Collectible(2480,226, "health"),
        Collectible(3080,186, "powerup"),
    ]
    boss = Boss("dragon_boss", 3450, 330, "DRAGÃO ALFA")
    return {
        "name":  "CIDADE DESTRUÍDA — ATO I",
        "width": 3650,
        "platforms": plats,
        "spikes": spikes,
        "enemies": enemies,
        "collectibles": collectibles,
        "boss": boss,
        "bg_top":    (10, 10, 22),
        "bg_bot":    (16, 14, 30),
        "accent":    (28, 28, 56),
        "memory":    "...há uma imagem... fogo por toda parte...\ne algo quente ao meu lado...\num focinho úmido encostado no meu rosto.",
    }


def make_level_2():
    plats = [
        Platform(0,   460, 340, 60, (12,28,12),(8,18,8)),
        Platform(390, 460, 380, 60, (12,28,12),(8,18,8)),
        Platform(830, 460, 340, 60, (12,28,12),(8,18,8)),
        Platform(1230,460, 430, 60, (12,28,12),(8,18,8)),
        Platform(1730,460, 380, 60, (12,28,12),(8,18,8)),
        Platform(2180,460, 480, 60, (12,28,12),(8,18,8)),
        Platform(2730,460, 390, 60, (12,28,12),(8,18,8)),
        Platform(3190,460, 380, 60, (12,28,12),(8,18,8)),
        Platform(3640,460, 80,  60, (12,28,12),(8,18,8)),
        # elevated
        Platform(170,358,140,18,(18,40,18),(10,28,10)),
        Platform(440,308,120,18,(18,40,18),(10,28,10)),
        Platform(640,258,100,18,(18,40,18),(10,28,10)),
        Platform(890,318,160,18,(18,40,18),(10,28,10)),
        Platform(1090,268,120,18,(18,40,18),(10,28,10)),
        Platform(1340,298,150,18,(18,40,18),(10,28,10)),
        Platform(1590,238,120,18,(18,40,18),(10,28,10)),
        Platform(1840,308,140,18,(18,40,18),(10,28,10)),
        Platform(2040,258,130,18,(18,40,18),(10,28,10)),
        Platform(2340,288,120,18,(18,40,18),(10,28,10)),
        Platform(2590,228,110,18,(18,40,18),(10,28,10)),
        Platform(2840,308,180,18,(18,40,18),(10,28,10)),
        Platform(3040,258,140,18,(18,40,18),(10,28,10)),
        Platform(3290,218,130,18,(18,40,18),(10,28,10)),
        Platform(3540,278,160,18,(18,40,18),(10,28,10)),
    ]
    spikes = [
        Spike(345,440,3), Spike(790,440,3),
        Spike(1680,440,4), Spike(2690,440,3),
    ]
    enemies = [
        Enemy("monkey",490,420),
        Enemy("rat",   740,420),
        Enemy("monkey",940,278),
        Enemy("insect",1140,228),
        Enemy("monkey",1390,258),
        Enemy("insect",1640,198),
        Enemy("monkey",1890,420),
        Enemy("insect",2090,218),
        Enemy("monkey",2390,248),
        Enemy("insect",2640,188),
        Enemy("robot", 2890,268),
        Enemy("monkey",3090,218),
        Enemy("insect",3340,178),
        Enemy("monkey",3590,238),
    ]
    collectibles = [
        Collectible(240,320,"memory"),
        Collectible(790,220,"health"),
        Collectible(1580,200,"memory"),
        Collectible(2580,190,"powerup"),
        Collectible(3280,178,"health"),
    ]
    boss = Boss("monkey_boss", 3600, 340, "MACACO ALFA RADIOATIVO")
    return {
        "name":  "FLORESTA MUTANTE — ATO II",
        "width": 3800,
        "platforms": plats,
        "spikes": spikes,
        "enemies": enemies,
        "collectibles": collectibles,
        "boss": boss,
        "bg_top":  (5, 12, 5),
        "bg_bot":  (8, 20, 8),
        "accent":  (14, 36, 14),
        "memory": "...Rex... eu me lembro desse nome...\nhavia um filhote que me lambeu o rosto\nquando eu chorava no laboratório...",
    }


LEVELS = [make_level_1, make_level_2]


# ══════════════════════════════════════════════════════════════════════════════
# GAME STATE
# ══════════════════════════════════════════════════════════════════════════════
class GameState:
    def __init__(self):
        self.screen_state  = "title"   # title | char_select | game | game_over | victory | memory
        self.score         = 0
        self.num_players   = 1
        self.current_level = 0
        self.players       = []
        self.platforms     = []
        self.spikes        = []
        self.enemies       = []
        self.collectibles  = []
        self.projectiles   = []
        self.boss          = None
        self.boss_active   = False
        self.boss_bar_visible = False
        self.level_cleared = False
        self.game_over_flag= False
        self.cam_x         = 0.0
        self.target_cam_x  = 0.0
        self.memory_count  = 0
        self.trigger_memory= False
        self.memory_text   = ""
        self.level_name    = ""
        self.frame         = 0
        # title/select UI
        self.selected_num  = 1
        self.hovered       = 0
        # victory delay
        self.victory_timer = 0
        # memory screen timer
        self.memory_timer  = 0

    def load_level(self, idx):
        global floats
        floats       = []
        ps.particles = []
        data = LEVELS[idx]()
        self.platforms    = data["platforms"]
        self.spikes       = data["spikes"]
        self.enemies      = data["enemies"]
        self.collectibles = data["collectibles"]
        self.boss         = data["boss"]
        self.projectiles  = []
        self.boss_active  = False
        self.boss_bar_visible = False
        self.level_cleared = False
        self.game_over_flag= False
        self.cam_x         = 0.0
        self.target_cam_x  = 0.0
        self.level_width   = data["width"]
        self.level_name    = data["name"]
        self.bg_top        = data["bg_top"]
        self.bg_bot        = data["bg_bot"]
        self.accent        = data["accent"]
        self.level_memory  = data["memory"]
        self.victory_timer = 0
        self.score         = 0

    def start_game(self):
        self.current_level = 0
        self.memory_count  = 0
        self.load_level(0)
        char_indices = list(range(self.num_players))
        self.players = [Player(i, i) for i in char_indices]
        self.screen_state = "game"

    def restart(self):
        self.load_level(self.current_level)
        char_indices = list(range(self.num_players))
        self.players = [Player(i, i) for i in char_indices]
        self.screen_state = "game"

    def next_level(self):
        self.current_level = (self.current_level + 1) % len(LEVELS)
        self.load_level(self.current_level)
        char_indices = list(range(self.num_players))
        self.players = [Player(i, i) for i in char_indices]
        self.screen_state = "game"


game_state = GameState()


def current_level_width():
    return getattr(game_state, "level_width", 3650)


# ══════════════════════════════════════════════════════════════════════════════
# BACKGROUND DRAWING
# ══════════════════════════════════════════════════════════════════════════════
def draw_background(surf, cam_x, bg_top, bg_bot, accent):
    # sky gradient (manual bands)
    for y in range(0, H, 4):
        t  = y / H
        r  = int(lerp(bg_top[0], bg_bot[0], t))
        g  = int(lerp(bg_top[1], bg_bot[1], t))
        b  = int(lerp(bg_top[2], bg_bot[2], t))
        pygame.draw.line(surf, (r, g, b), (0, y), (W, y))

    # stars
    rng = random.Random(42)
    for _ in range(80):
        sx = rng.randint(0, W * 4)
        sy = rng.randint(0, int(H * 0.65))
        ss = rng.choice([1, 1, 2])
        px = (sx - int(cam_x * 0.08)) % W
        surf.set_at((px, sy), (200, 200, 220))
        if ss == 2:
            surf.set_at((px+1, sy), (180, 180, 200))

    # back buildings / trees
    rng2 = random.Random(7)
    off  = int(cam_x * 0.28) % (W * 2)
    for i in range(14):
        bx = (rng2.randint(0, W*2) - off % (W*2) + W*4) % (W*2) - 60
        bh = rng2.randint(70, 160)
        bw = rng2.randint(22, 44)
        col = (accent[0]+6, accent[1]+6, accent[2]+12)
        pygame.draw.rect(surf, col, (bx, H - bh - 50, bw, bh))

    # mid-layer
    rng3 = random.Random(13)
    off2 = int(cam_x * 0.52) % (W * 3)
    for i in range(20):
        bx  = (rng3.randint(0, W*3) - off2 % (W*3) + W*6) % (W*3) - 40
        bh  = rng3.randint(40, 100)
        bw  = rng3.randint(14, 30)
        col = (accent[0]+14, accent[1]+14, accent[2]+22)
        pygame.draw.rect(surf, col, (bx, H - bh - 46, bw, bh))


# ══════════════════════════════════════════════════════════════════════════════
# HUD
# ══════════════════════════════════════════════════════════════════════════════
def draw_hud(surf, players, score, level_name, boss, boss_active):
    # top bar bg
    pygame.draw.rect(surf, (0, 0, 0), (0, 0, W, 52))
    pygame.draw.line(surf, (40, 40, 60), (0, 52), (W, 52), 1)

    # player HUDs
    slot_w = 200
    for i, p in enumerate(players):
        ox = 6 + i * slot_w
        col = p.color
        # name
        ns = font_tiny.render(("💀 " if p.dead else "") + p.name, True, col)
        surf.blit(ns, (ox, 4))
        # HP bar
        bar_w = 160; bar_h = 8
        hp_pct = max(0, p.hp / p.max_hp)
        pygame.draw.rect(surf, (40,10,10), (ox, 18, bar_w, bar_h))
        hcol = GREEN if hp_pct > 0.5 else (YELLOW if hp_pct > 0.25 else RED)
        pygame.draw.rect(surf, hcol, (ox, 18, int(bar_w * hp_pct), bar_h))
        pygame.draw.rect(surf, (80,80,80), (ox, 18, bar_w, bar_h), 1)
        # HP label
        surf.blit(font_tiny.render(f"HP {int(p.hp)}", True, (160,160,160)), (ox+bar_w+4, 16))
        # MP bar
        mp_pct = max(0, p.mp / p.max_mp)
        pygame.draw.rect(surf, (10,10,40), (ox, 30, bar_w, bar_h))
        pygame.draw.rect(surf, BLUE, (ox, 30, int(bar_w * mp_pct), bar_h))
        pygame.draw.rect(surf, (80,80,80), (ox, 30, bar_w, bar_h), 1)
        surf.blit(font_tiny.render(f"MP {int(p.mp)}", True, (100,100,180)), (ox+bar_w+4, 28))
        # Power (Rex)
        if p.is_rex and p.power != "none":
            pinfo = POWERS[p.power]
            ps_txt = font_tiny.render(
                f"[{pinfo['name']} {p.power_timer//60}s]", True, pinfo['color'])
            surf.blit(ps_txt, (ox, 41))

    # center: level name + score
    ln = font_small.render(level_name, True, YELLOW)
    surf.blit(ln, (W//2 - ln.get_width()//2, 4))
    sc = font_small.render(f"PONTOS: {score:,}", True, (160,160,160))
    surf.blit(sc, (W//2 - sc.get_width()//2, 20))

    # boss bar
    if boss_active and boss and not boss.dead:
        bx, by, bw, bh = W//2 - 220, H - 38, 440, 14
        pygame.draw.rect(surf, (30,0,0), (bx, by, bw, bh))
        pct = max(0, boss.hp / boss.max_hp)
        pygame.draw.rect(surf, RED, (bx, by, int(bw * pct), bh))
        pygame.draw.rect(surf, (160,0,0), (bx, by, bw, bh), 2)
        bn = font_small.render(boss.name, True, (255, 80, 80))
        surf.blit(bn, (W//2 - bn.get_width()//2, H - 54))

    # controls hint
    hint = font_tiny.render(
        "P1:WASD+ZXC  P2:ARROWS+UIO  P3:JL I +NM,  P4:Numpad  ESC:menu  R:restart",
        True, (60,60,80))
    surf.blit(hint, (W//2 - hint.get_width()//2, H - 16))


# ══════════════════════════════════════════════════════════════════════════════
# SCREEN: TITLE
# ══════════════════════════════════════════════════════════════════════════════
def draw_title(surf, frame):
    surf.fill((8, 6, 18))
    # animated bg dots
    rng = random.Random(99)
    for _ in range(60):
        x = rng.randint(0, W); y = rng.randint(0, H)
        r = rng.choice([1,1,2])
        surf.set_at((x, y), (80, 60, 120))

    t = pygame.time.get_ticks() / 1000.0
    flicker = 1.0 if math.sin(t * 7) > -0.92 else 0.6
    fc = tuple(int(c * flicker) for c in YELLOW)

    # title
    title1 = font_big.render("FORGOTTEN", True, fc)
    title2 = font_big.render("PAWS", True, fc)
    surf.blit(title1, (W//2 - title1.get_width()//2, 100))
    surf.blit(title2,  (W//2 - title2.get_width()//2, 152))

    sub = font_small.render("Uma história pós-apocalíptica de memória e lealdade", True, PURPLE)
    surf.blit(sub, (W//2 - sub.get_width()//2, 212))

    # menu options
    opts = ["JOGAR", "CONTROLES", "SAIR"]
    for i, opt in enumerate(opts):
        y = 290 + i * 46
        sel = (game_state.hovered == i)
        col = YELLOW if sel else (140, 130, 100)
        prefix = "> " if sel else "  "
        s = font_med.render(prefix + opt, True, col)
        surf.blit(s, (W//2 - s.get_width()//2, y))

    draw_text(surf, "↑↓ navegar   ENTER confirmar", font_tiny, (60,60,80), W//2, H-20)


# ══════════════════════════════════════════════════════════════════════════════
# SCREEN: CHAR SELECT
# ══════════════════════════════════════════════════════════════════════════════
CHAR_DESCRIPTIONS = [
    ("KIRA", PURPLE, "Espada + Pistola", "Dash especial", "WASD + Z/X/C"),
    ("REX",  GREEN,  "Absorve poderes", "Especial por poder", "← → ↑ + U/I/O"),
    ("VALE", ORANGE, "Arco longo alcance","Chuva de flechas",  "J/L/I + N/M/,"),
    ("ZAP",  CYAN,   "Campo elétrico", "Overcharge",         "Numpad 4/6/8+7/9/1"),
]

def draw_char_select(surf, frame):
    surf.fill((6, 10, 6))

    title_s = font_med.render("ESCOLHA SEUS GUERREIROS", True, GREEN)
    surf.blit(title_s, (W//2 - title_s.get_width()//2, 20))

    # player count
    cnt_s = font_small.render(f"Jogadores: {game_state.selected_num}   (← → para mudar)", True, (120,180,120))
    surf.blit(cnt_s, (W//2 - cnt_s.get_width()//2, 52))

    cw, ch = 200, 190
    gap    = 16
    total  = len(CHAR_DESCRIPTIONS) * (cw + gap) - gap
    sx0    = W//2 - total//2

    for i, (name, col, atk, spec, ctrl) in enumerate(CHAR_DESCRIPTIONS):
        cx = sx0 + i * (cw + gap)
        cy = 90
        active = i < game_state.selected_num

        # card bg
        border_col = col if active else (50, 50, 50)
        bg_col     = (20, 20, 30) if active else (12,12,18)
        pygame.draw.rect(surf, bg_col,    (cx, cy, cw, ch))
        pygame.draw.rect(surf, border_col,(cx, cy, cw, ch), 2)

        # avatar circle
        av_col = col if active else (50,50,50)
        pygame.draw.circle(surf, av_col, (cx + cw//2, cy + 42), 30)
        pygame.draw.circle(surf, (20,20,20), (cx+cw//2, cy+42), 28)
        idx_s = font_med.render(str(i+1), True, av_col)
        surf.blit(idx_s, (cx+cw//2 - idx_s.get_width()//2, cy+32))

        name_s = font_small.render(name, True, col if active else (80,80,80))
        surf.blit(name_s, (cx + cw//2 - name_s.get_width()//2, cy + 78))

        for j, line in enumerate([atk, spec, ctrl]):
            ls = font_tiny.render(line, True, (150,150,120) if active else (60,60,60))
            surf.blit(ls, (cx + 8, cy + 102 + j*22))

        if active:
            p_s = font_tiny.render(f"P{i+1}", True, col)
            surf.blit(p_s, (cx+4, cy+4))

    # Start button
    pygame.draw.rect(surf, (20,60,20), (W//2-110, 300, 220, 44))
    pygame.draw.rect(surf, GREEN,      (W//2-110, 300, 220, 44), 2)
    start_s = font_med.render("INICIAR  (ENTER)", True, GREEN)
    surf.blit(start_s, (W//2 - start_s.get_width()//2, 310))

    back = font_tiny.render("ESC: voltar ao menu", True, (60,80,60))
    surf.blit(back, (W//2 - back.get_width()//2, H - 24))


# ══════════════════════════════════════════════════════════════════════════════
# SCREEN: GAME OVER
# ══════════════════════════════════════════════════════════════════════════════
def draw_game_over(surf):
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    overlay.fill((0,0,0,200))
    surf.blit(overlay, (0,0))

    t = pygame.time.get_ticks()
    ox = int(math.sin(t*0.01) * 4)
    go = font_big.render("VOCÊ CAIU", True, RED)
    surf.blit(go, (W//2 - go.get_width()//2 + ox, 160))

    sub = font_small.render("O apocalipse não perdoa os fracos...", True, (150,50,50))
    surf.blit(sub, (W//2 - sub.get_width()//2, 230))

    for i, (txt, col) in enumerate([("R  — TENTAR NOVAMENTE", GREEN),
                                      ("ESC — MENU PRINCIPAL",   YELLOW)]):
        s = font_med.render(txt, True, col)
        surf.blit(s, (W//2 - s.get_width()//2, 310 + i*50))


# ══════════════════════════════════════════════════════════════════════════════
# SCREEN: VICTORY
# ══════════════════════════════════════════════════════════════════════════════
def draw_victory(surf, score):
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    overlay.fill((0,0,0,200))
    surf.blit(overlay, (0,0))

    t = pygame.time.get_ticks() / 1000.0
    fc = tuple(int(c * (0.8 + 0.2*math.sin(t*3))) for c in YELLOW)
    vt = font_big.render("✦ VITÓRIA ✦", True, fc)
    surf.blit(vt, (W//2 - vt.get_width()//2, 130))

    sc = font_med.render(f"PONTUAÇÃO: {score:,}", True, WHITE)
    surf.blit(sc, (W//2 - sc.get_width()//2, 210))

    mem = font_small.render("Uma memória retornou...", True, PURPLE)
    surf.blit(mem, (W//2 - mem.get_width()//2, 260))

    for i, (txt, col) in enumerate([("ENTER — PRÓXIMA FASE", GREEN),
                                      ("ESC   — MENU",         YELLOW)]):
        s = font_med.render(txt, True, col)
        surf.blit(s, (W//2 - s.get_width()//2, 330 + i * 50))


# ══════════════════════════════════════════════════════════════════════════════
# SCREEN: MEMORY FLASH
# ══════════════════════════════════════════════════════════════════════════════
def draw_memory(surf, text, timer):
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    alpha   = min(220, timer * 5)
    overlay.fill((30, 0, 60, alpha))
    surf.blit(overlay, (0,0))

    title_s = font_med.render("✦ FRAGMENTO DE MEMÓRIA ✦", True, (200, 160, 255))
    surf.blit(title_s, (W//2 - title_s.get_width()//2, 160))

    lines = text.split("\n")
    for i, line in enumerate(lines):
        ls = font_small.render(line.strip(), True, (220, 200, 255))
        surf.blit(ls, (W//2 - ls.get_width()//2, 230 + i * 30))

    hint = font_tiny.render("ENTER ou ESPAÇO para continuar", True, (120, 100, 160))
    surf.blit(hint, (W//2 - hint.get_width()//2, H - 40))


# ══════════════════════════════════════════════════════════════════════════════
# CONTROLS SCREEN
# ══════════════════════════════════════════════════════════════════════════════
def draw_controls(surf):
    surf.fill((6, 6, 18))
    draw_text(surf, "CONTROLES", font_med, YELLOW, W//2, 40)

    lines = [
        ("P1 — KIRA",   "A/D: mover   W: pular   S: deslizar   Z: atacar   X: tiro   C: especial", PURPLE),
        ("P2 — REX",    "← →: mover   ↑: pular   ↓: deslizar   U: morder   I: uivar   O: absorver", GREEN),
        ("P3 — VALE",   "J/L: mover   I: pular   K: deslizar   N: atacar   M: tiro   ,: especial", ORANGE),
        ("P4 — ZAP",    "Num4/6: mover  Num8: pular  Num5: slide  Num7: atk  Num9: tiro  Num1: spec", CYAN),
        ("GERAL",       "ESC: menu   R: reiniciar   ESPAÇO: pausa", WHITE),
        ("REX — PODERES","Derrote inimigos e Rex absorve automaticamente!  O: ciclar poderes", GREEN),
    ]

    for i, (label, desc, col) in enumerate(lines):
        y = 100 + i * 56
        ls = font_small.render(label, True, col)
        surf.blit(ls, (60, y))
        ds = font_tiny.render(desc, True, (160,160,140))
        surf.blit(ds, (60, y + 22))
        pygame.draw.line(surf, (30,30,50), (60, y+44), (W-60, y+44), 1)

    back = font_small.render("ESC — VOLTAR", True, (100,100,80))
    surf.blit(back, (W//2 - back.get_width()//2, H - 40))


# ══════════════════════════════════════════════════════════════════════════════
# TAP HANDLER — called when user taps a named menu zone
# ══════════════════════════════════════════════════════════════════════════════
def _handle_tap(name, gs, paused):
    """Process a tap on a named UI zone from any screen."""
    # title
    if name == "tap_play":
        gs.screen_state = "char_select"
    elif name == "tap_exit":
        pygame.quit(); sys.exit()
    # char select
    elif name == "tap_players_less":
        gs.selected_num = max(1, gs.selected_num - 1)
        gs.num_players  = gs.selected_num
    elif name == "tap_players_more":
        gs.selected_num = min(4, gs.selected_num + 1)
        gs.num_players  = gs.selected_num
    elif name == "tap_start":
        gs.start_game()
    elif name == "tap_back":
        gs.screen_state = "title"
    # in-game overlays
    elif name == "tap_restart":
        gs.restart()
    elif name == "tap_menu":
        gs.screen_state = "title"
    elif name == "tap_next":
        gs.next_level()
    elif name == "tap_continue":
        gs.screen_state = "game"
    elif name == "tap_pause":
        pass   # toggled inline


def _reg(tap_zones, name, rect):
    """Register a tap zone and return the rect (for drawing)."""
    tap_zones[name] = rect
    return rect


# ══════════════════════════════════════════════════════════════════════════════
# DRAW HELPERS FOR TAPPABLE BUTTONS  (used in menu screens on mobile)
# ══════════════════════════════════════════════════════════════════════════════
def draw_tap_btn(surf, tap_zones, name, label, cx, cy, w, h, col, font=None):
    """Draw a rectangular tap button and register its zone."""
    if font is None:
        font = font_med
    r = pygame.Rect(cx - w//2, cy - h//2, w, h)
    _reg(tap_zones, name, r)
    pygame.draw.rect(surf, tuple(max(0,c-40) for c in col), r.move(3,3))
    pygame.draw.rect(surf, col, r)
    pygame.draw.rect(surf, WHITE, r, 2)
    ls = font.render(label, True, WHITE)
    surf.blit(ls, (cx - ls.get_width()//2, cy - ls.get_height()//2))


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ASYNC LOOP  (required by Pygbag)
# ══════════════════════════════════════════════════════════════════════════════
async def main():
    paused        = False
    show_controls = False
    gs            = game_state
    tap_zones     = {}   # name → Rect, rebuilt every draw frame

    while True:
        dt = clock.tick(FPS)
        merged_keys.refresh()
        gs.frame += 1

        # ── events ────────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            # mobile gameplay buttons
            if gs.screen_state == "game":
                mobile.handle_event(event)

            # tap / click on menu zones
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos
                for name, rect in tap_zones.items():
                    if rect.collidepoint(mx, my):
                        if name == "tap_pause":
                            paused = not paused
                        else:
                            _handle_tap(name, gs, paused)
                        break   # consume

            if event.type == pygame.KEYDOWN:
                k = event.key

                # ── title ──
                if gs.screen_state == "title" and not show_controls:
                    if k in (pygame.K_UP, pygame.K_w):
                        gs.hovered = (gs.hovered - 1) % 3
                    if k in (pygame.K_DOWN, pygame.K_s):
                        gs.hovered = (gs.hovered + 1) % 3
                    if k in (pygame.K_RETURN, pygame.K_SPACE):
                        if gs.hovered == 0:   gs.screen_state = "char_select"
                        elif gs.hovered == 1: show_controls = True
                        elif gs.hovered == 2: pygame.quit(); sys.exit()
                    if k == pygame.K_ESCAPE:
                        pygame.quit(); sys.exit()

                elif show_controls:
                    if k in (pygame.K_ESCAPE, pygame.K_RETURN):
                        show_controls = False

                elif gs.screen_state == "char_select":
                    if k == pygame.K_LEFT:
                        gs.selected_num = max(1, gs.selected_num - 1)
                    if k == pygame.K_RIGHT:
                        gs.selected_num = min(4, gs.selected_num + 1)
                    gs.num_players = gs.selected_num
                    if k in (pygame.K_RETURN, pygame.K_SPACE): gs.start_game()
                    if k == pygame.K_ESCAPE: gs.screen_state = "title"

                elif gs.screen_state == "game":
                    if k == pygame.K_ESCAPE: gs.screen_state = "title"
                    if k == pygame.K_r:      gs.restart()
                    if k == pygame.K_SPACE:  paused = not paused

                elif gs.screen_state == "memory":
                    if k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
                        gs.screen_state = "game"

                elif gs.screen_state == "game_over":
                    if k == pygame.K_r:      gs.restart()
                    if k == pygame.K_ESCAPE: gs.screen_state = "title"

                elif gs.screen_state == "victory":
                    if k in (pygame.K_RETURN, pygame.K_SPACE): gs.next_level()
                    if k == pygame.K_ESCAPE: gs.screen_state = "title"

        # rebuild tap zones each frame
        tap_zones.clear()

        # ── update ────────────────────────────────────────────────────────────
        if gs.screen_state == "game" and not paused:
            for p in gs.players:
                p.update(merged_keys, gs.platforms, gs.enemies, gs.projectiles, dt)

            for e in gs.enemies:
                e.update(gs.platforms, gs.players)

            all_e_dead = all(e.dead for e in gs.enemies)
            any_near   = any(not p.dead and p.x > gs.level_width - 750
                             for p in gs.players)
            if not gs.boss_active and (all_e_dead or any_near):
                gs.boss_active      = True
                gs.boss_bar_visible = True
                add_float(gs.boss.x + gs.boss.w//2, gs.boss.y - 60, "⚠ BOSS!", RED)
                ps.burst(gs.boss.x + gs.boss.w//2, gs.boss.y + gs.boss.h//2, RED, 30, 10)

            if gs.boss_active and not gs.boss.dead:
                gs.boss.update(gs.platforms, gs.players)

            alive_proj = []
            for proj in gs.projectiles:
                proj.update(gs.platforms, gs.players, gs.enemies)
                if not proj.dead:
                    alive_proj.append(proj)
            gs.projectiles = alive_proj

            for c in gs.collectibles:
                c.update(gs.players)
            for s in gs.spikes:
                s.check_players(gs.players)

            ps.update()
            for ft in floats:
                ft.update()
            floats[:] = [ft for ft in floats if ft.life > 0]

            alive = [p for p in gs.players if not p.dead]
            if alive:
                avg_x = sum(p.x for p in alive) / len(alive)
                gs.target_cam_x = max(0, min(gs.level_width - W, avg_x - W // 3))
                gs.cam_x = lerp(gs.cam_x, gs.target_cam_x, 0.09)

            if all(p.dead for p in gs.players) and not gs.game_over_flag:
                gs.game_over_flag = True
                gs.screen_state   = "game_over"

            if gs.level_cleared and not gs.game_over_flag:
                gs.victory_timer += 1
                if gs.victory_timer > 120:
                    gs.screen_state  = "victory"
                    gs.level_cleared = False

            if gs.trigger_memory:
                gs.trigger_memory = False
                gs.memory_text    = gs.level_memory
                gs.memory_timer   = 0
                gs.screen_state   = "memory"

        # ── draw ──────────────────────────────────────────────────────────────
        if gs.screen_state == "title":
            if show_controls:
                _draw_controls_mobile(screen, tap_zones)
            else:
                _draw_title_mobile(screen, gs.frame, tap_zones)

        elif gs.screen_state == "char_select":
            _draw_char_select_mobile(screen, gs.frame, tap_zones)

        elif gs.screen_state in ("game", "memory", "game_over", "victory"):
            # world
            if hasattr(gs, "bg_top"):
                draw_background(screen, gs.cam_x, gs.bg_top, gs.bg_bot, gs.accent)
            for p in gs.platforms:   p.draw(screen, gs.cam_x)
            for s in gs.spikes:      s.draw(screen, gs.cam_x)
            for c in gs.collectibles: c.draw(screen, gs.cam_x)
            for proj in gs.projectiles: proj.draw(screen, gs.cam_x)
            for e in gs.enemies:     e.draw(screen, gs.cam_x)
            if gs.boss_active and gs.boss and not gs.boss.dead:
                gs.boss.draw(screen, gs.cam_x)
            for p in gs.players:     p.draw(screen, gs.cam_x)
            ps.draw(screen, gs.cam_x)
            for ft in floats:        ft.draw(screen, gs.cam_x)

            draw_hud(screen, gs.players, gs.score,
                     gs.level_name, gs.boss, gs.boss_bar_visible)

            # mobile controls overlay (gameplay)
            if gs.screen_state == "game":
                mobile.draw(screen)
                # pause button top-center
                draw_tap_btn(screen, tap_zones, "tap_pause",
                             "II" if not paused else "▶",
                             W//2, 36, 60, 28, (50,50,70), font_small)
                if paused:
                    pause_s = font_big.render("PAUSADO", True, YELLOW)
                    screen.blit(pause_s, (W//2 - pause_s.get_width()//2, H//2 - 30))
                    draw_tap_btn(screen, tap_zones, "tap_menu",
                                 "MENU", W//2, H//2+50, 160, 44, (60,40,20))

            elif gs.screen_state == "memory":
                gs.memory_timer += 1
                draw_memory(screen, gs.memory_text, gs.memory_timer)
                draw_tap_btn(screen, tap_zones, "tap_continue",
                             "CONTINUAR", W//2, H - 60, 220, 44, (40,20,80))

            elif gs.screen_state == "game_over":
                draw_game_over(screen)
                draw_tap_btn(screen, tap_zones, "tap_restart",
                             "↺ TENTAR NOVAMENTE", W//2, 320, 300, 50, (60,10,10))
                draw_tap_btn(screen, tap_zones, "tap_menu",
                             "MENU", W//2, 385, 200, 44, (40,30,10))

            elif gs.screen_state == "victory":
                draw_victory(screen, gs.score)
                draw_tap_btn(screen, tap_zones, "tap_next",
                             "▶ PRÓXIMA FASE", W//2, 342, 260, 50, (10,60,10))
                draw_tap_btn(screen, tap_zones, "tap_menu",
                             "MENU", W//2, 406, 200, 44, (40,30,10))

        pygame.display.flip()
        await asyncio.sleep(0)   # yield to browser / Pygbag event loop


# ══════════════════════════════════════════════════════════════════════════════
# MOBILE-FRIENDLY MENU SCREENS
# ══════════════════════════════════════════════════════════════════════════════
def _draw_title_mobile(surf, frame, tap_zones):
    """Title screen with large tap-friendly buttons."""
    surf.fill((8, 6, 18))
    rng = random.Random(99)
    for _ in range(60):
        x = rng.randint(0, W); y = rng.randint(0, H)
        surf.set_at((x, y), (80, 60, 120))

    t       = pygame.time.get_ticks() / 1000.0
    flicker = 1.0 if math.sin(t * 7) > -0.92 else 0.6
    fc      = tuple(int(c * flicker) for c in YELLOW)

    t1 = font_big.render("FORGOTTEN", True, fc)
    t2 = font_big.render("PAWS",      True, fc)
    surf.blit(t1, (W//2 - t1.get_width()//2, 70))
    surf.blit(t2, (W//2 - t2.get_width()//2, 122))

    sub = font_small.render("Uma história pós-apocalíptica de memória e lealdade",
                             True, PURPLE)
    surf.blit(sub, (W//2 - sub.get_width()//2, 182))

    # Big tap buttons
    draw_tap_btn(surf, tap_zones, "tap_play",
                 "▶  JOGAR", W//2, 270, 300, 58, (20, 80, 20))
    draw_tap_btn(surf, tap_zones, "tap_exit",
                 "SAIR",     W//2, 346, 200, 48, (80, 20, 20))

    hint = font_tiny.render("Toque nos botões ou use o teclado", True, (60,60,80))
    surf.blit(hint, (W//2 - hint.get_width()//2, H - 20))


def _draw_char_select_mobile(surf, frame, tap_zones):
    """Character select with touch-friendly player-count picker and start button."""
    surf.fill((6, 10, 6))

    title_s = font_med.render("ESCOLHA OS JOGADORES", True, GREEN)
    surf.blit(title_s, (W//2 - title_s.get_width()//2, 16))

    gs = game_state

    # Player count picker  ← N →
    draw_tap_btn(surf, tap_zones, "tap_players_less",
                 "◀", W//2 - 80, 58, 54, 40, (30,60,30), font_med)
    cnt_s = font_med.render(f"{gs.selected_num}  jogador{'es' if gs.selected_num>1 else ''}",
                            True, WHITE)
    surf.blit(cnt_s, (W//2 - cnt_s.get_width()//2, 44))
    draw_tap_btn(surf, tap_zones, "tap_players_more",
                 "▶", W//2 + 80, 58, 54, 40, (30,60,30), font_med)

    # Character cards
    CHAR_DESCRIPTIONS = [
        ("KIRA",  PURPLE, "Espada+Pistola", "Dash especial",   "P1: WASD+ZXC"),
        ("REX",   GREEN,  "Absorve poderes","Especial por poder","P2: ←→↑+UIO"),
        ("VALE",  ORANGE, "Arco à distância","Chuva de flechas","P3: JLI+NM,"),
        ("ZAP",   CYAN,   "Campo elétrico", "Overcharge",       "P4: Numpad"),
    ]
    cw, ch = 190, 168
    gap    = 10
    total  = len(CHAR_DESCRIPTIONS) * (cw + gap) - gap
    sx0    = W//2 - total//2

    for i, (name, col, atk, spec, ctrl) in enumerate(CHAR_DESCRIPTIONS):
        cx  = sx0 + i * (cw + gap)
        cy  = 90
        active = i < gs.selected_num
        bc  = col if active else (40,40,40)
        bg  = (18,22,18) if active else (10,10,12)
        pygame.draw.rect(surf, bg,  (cx, cy, cw, ch))
        pygame.draw.rect(surf, bc,  (cx, cy, cw, ch), 2)
        pygame.draw.circle(surf, bc, (cx + cw//2, cy + 34), 26)
        pygame.draw.circle(surf, (14,14,14), (cx + cw//2, cy+34), 24)
        ns = font_small.render(str(i+1), True, bc)
        surf.blit(ns, (cx+cw//2-ns.get_width()//2, cy+24))
        nm = font_small.render(name, True, col if active else (60,60,60))
        surf.blit(nm, (cx+cw//2-nm.get_width()//2, cy+64))
        for j, line in enumerate([atk, spec, ctrl]):
            ls = font_tiny.render(line, True, (140,140,110) if active else (50,50,50))
            surf.blit(ls, (cx+6, cy+88+j*22))
        if active:
            ps_s = font_tiny.render(f"P{i+1}", True, col)
            surf.blit(ps_s, (cx+4, cy+4))

    # Big start + back buttons
    draw_tap_btn(surf, tap_zones, "tap_start",
                 "▶ INICIAR AVENTURA", W//2, 292, 320, 56, (10,80,10))
    draw_tap_btn(surf, tap_zones, "tap_back",
                 "◀ VOLTAR",           W//2, 362, 200, 44, (60,30,10))

    hint = font_tiny.render(
        "Mobile: apenas P1 usa controles na tela  |  Teclado: todos os jogadores",
        True, (60,80,60))
    surf.blit(hint, (W//2 - hint.get_width()//2, H - 18))


def _draw_controls_mobile(surf, tap_zones):
    """Controls screen (reached from title)."""
    surf.fill((6, 6, 18))
    draw_text(surf, "CONTROLES", font_med, YELLOW, W//2, 36)

    lines = [
        ("P1 — KIRA",    "A/D mover · W pular · S deslizar · Z atacar · X tiro · C especial",          PURPLE),
        ("P2 — REX",     "← → mover · ↑ pular · ↓ slide · U morder · I uivar · O absorver poder",      GREEN),
        ("P3 — VALE",    "J/L mover · I pular · K slide · N atacar · M tiro · , especial",              ORANGE),
        ("P4 — ZAP",     "Num4/6 mover · Num8 pular · Num7 atk · Num9 tiro · Num1 especial",            CYAN),
        ("MOBILE (P1)",  "Botões na tela: D-pad esquerdo + ATK/TIR/ESP direito + ⬆ pular",              WHITE),
        ("REX — PODERES","Derrote inimigos → Rex absorve poder automático!  O / botão ESP: ciclar",      GREEN),
        ("GERAL",        "ESC/botão MENU: sair · R: reiniciar · II: pausar",                            (160,160,120)),
    ]

    for i, (label, desc, col) in enumerate(lines):
        y = 76 + i * 54
        ls = font_small.render(label, True, col)
        surf.blit(ls, (40, y))
        ds = font_tiny.render(desc, True, (150,150,130))
        surf.blit(ds, (40, y + 22))
        pygame.draw.line(surf, (30,30,50), (40, y+44), (W-40, y+44), 1)

    draw_tap_btn(surf, tap_zones, "tap_back",
                 "◀ VOLTAR", W//2, H - 34, 200, 40, (40,30,10), font_small)


asyncio.run(main())
