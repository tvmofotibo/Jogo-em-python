package com.dogapocalypse.menu;

import com.dogapocalypse.core.DogApocalypsePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Menu de seleção de fases.
 *
 * Layout (36 slots):
 *  ┌────────────────────────────────┐
 *  │  B  B  B  B  B  B  B  B  B   │ borda
 *  │  B  1  B  2  B  3  B  4  B   │ fases
 *  │  B  B  B  B  B  B  B  B  B   │ borda
 *  │  B  B  B  ←  B  B  B  B  B  │ voltar
 *  └────────────────────────────────┘
 */
public class MenuFases {

    public static final String TITULO = "§8§l🗺 Escolher Fase";

    public static void abrir(Player player, DogApocalypsePlugin plugin) {
        Inventory inv = Bukkit.createInventory(null, 36, TITULO);

        // Bordas
        for (int i = 0; i < 9; i++) {
            inv.setItem(i,      MenuUtils.borda(Material.BLUE_STAINED_GLASS_PANE));
            inv.setItem(18 + i, MenuUtils.borda(Material.BLUE_STAINED_GLASS_PANE));
            inv.setItem(27 + i, MenuUtils.borda(Material.GRAY_STAINED_GLASS_PANE));
        }
        inv.setItem(9,  MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));
        inv.setItem(17, MenuUtils.borda(Material.BLACK_STAINED_GLASS_PANE));

        var data = plugin.getPlayerDataManager().get(player);
        String faseAtual = data.getCurrentLevel();
        int fragms = data.getStoryFragments();

        // Fase 1 — sempre disponível
        inv.setItem(10, MenuUtils.itemBrilhante(Material.COBBLESTONE,
            "&f&l🏙 Fase 1 — A Cidade em Ruínas",
            "&7Sobreviva pelas ruas destruídas da cidade.",
            "&7Boss: &cGorila Radioativo",
            "",
            faseAtual.equals("level_1") ? "&a▶ Fase atual" : "",
            "&eClique para jogar!"
        ));

        // Fase 2 — desbloqueada após 3 fragmentos
        boolean f2 = fragms >= 3;
        inv.setItem(12, f2
            ? MenuUtils.item(Material.OAK_LOG,
                "&a&l🌲 Fase 2 — A Floresta Infectada",
                "&7Navegue pela floresta mutante e seus perigos.",
                "&7Boss: &cMonstro do Laboratório",
                "",
                faseAtual.equals("level_2") ? "&a▶ Fase atual" : "",
                "&eClique para jogar!")
            : MenuUtils.item(Material.BARRIER,
                "&8🔒 Fase 2 — Bloqueada",
                "&7Complete a Fase 1 e colete",
                "&73 fragmentos de história para desbloquear.")
        );

        // Fase 3 — desbloqueada após 6 fragmentos
        boolean f3 = fragms >= 6;
        inv.setItem(14, f3
            ? MenuUtils.item(Material.IRON_BLOCK,
                "&7&l⚔ Fase 3 — As Ruínas de Guerra",
                "&7Atravesse o campo de batalha devastado.",
                "&7Boss: &cRobô Máquina de Guerra",
                "",
                faseAtual.equals("level_3") ? "&a▶ Fase atual" : "",
                "&eClique para jogar!")
            : MenuUtils.item(Material.BARRIER,
                "&8🔒 Fase 3 — Bloqueada",
                "&76 fragmentos de história necessários.")
        );

        // Fase 4 — desbloqueada após 9 fragmentos
        boolean f4 = fragms >= 9;
        inv.setItem(16, f4
            ? MenuUtils.itemBrilhante(Material.DRAGON_EGG,
                "&4&l🐉 Fase 4 — O Covil do Dragão",
                "&7Enfrente o General mutante final.",
                "&7Boss: &4&lDragão Mutante",
                "",
                faseAtual.equals("level_4") ? "&a▶ Fase atual" : "",
                "&eClique para jogar!")
            : MenuUtils.item(Material.BARRIER,
                "&8🔒 Fase 4 — Bloqueada",
                "&79 fragmentos de história necessários.")
        );

        // Botão voltar
        inv.setItem(31, MenuUtils.item(Material.ARROW,
            "&e← Voltar ao Menu Principal",
            "&7Retorna ao menu anterior."
        ));

        player.openInventory(inv);
    }
}
