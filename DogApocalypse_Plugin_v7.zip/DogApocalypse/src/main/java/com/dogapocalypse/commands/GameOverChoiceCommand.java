package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/**
 * /gameoverchoice restart <levelId>
 * /gameoverchoice menu
 *
 * Comando interno chamado pelos botões clicáveis da tela de Game Over.
 */
public class GameOverChoiceCommand implements CommandExecutor {

    private final DogApocalypsePlugin plugin;

    public GameOverChoiceCommand(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        if (args.length == 0) return true;

        switch (args[0].toLowerCase()) {
            case "restart" -> {
                String levelId = args.length > 1 ? args[1] : plugin.getPlayerDataManager().get(player).getCurrentLevel();
                if (!plugin.getGameOverScreen().estaEmGameOver(player.getUniqueId())) {
                    player.sendMessage(MessageUtil.color("&cVocê não está na tela de game over."));
                    return true;
                }
                plugin.getGameOverScreen().recomecarNivel(player, levelId);
            }
            case "menu" -> {
                plugin.getGameOverScreen().irParaMenu(player);
            }
            default -> player.sendMessage(MessageUtil.color("&cComando inválido."));
        }
        return true;
    }
}
