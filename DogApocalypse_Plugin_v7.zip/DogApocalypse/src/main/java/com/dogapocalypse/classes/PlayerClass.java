package com.dogapocalypse.classes;

/**
 * Represents the three playable classes in DogApocalypse.
 */
public enum PlayerClass {

    DOG("&6Mutated Dog", "A fast, adaptive fighter who absorbs enemy powers."),
    FIGHTER("&cFighter", "A powerful melee warrior with a protective shield."),
    ARCHER("&aArcher", "A precise long-range attacker with rapid fire.");

    private final String displayName;
    private final String description;

    PlayerClass(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }

    /**
     * Parse from string, case-insensitive. Returns null if invalid.
     */
    public static PlayerClass fromString(String s) {
        if (s == null) return null;
        try {
            return valueOf(s.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
