package com.dogapocalypse.skills;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * SkillTreeManager — manages the Dog class skill progression system.
 *
 * Skills are defined in config.yml under `skill_tree`.
 * Each skill has a cost (skill points), max level, and effects
 * that are applied through the relevant systems (abilities, combat, etc.).
 */
public class SkillTreeManager {

    private final DogApocalypsePlugin plugin;

    /** Ordered skill list for UI display */
    private static final List<String> SKILL_ORDER = List.of(
            "dash_upgrade", "extra_jump", "power_duration", "ability_strength", "fall_resilience"
    );

    public SkillTreeManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
    }

    // ----------------------------------------------------------------
    // Upgrade
    // ----------------------------------------------------------------

    /**
     * Attempts to upgrade a skill for a player.
     *
     * @param player  The player upgrading.
     * @param skillId The skill to upgrade.
     * @return true if successful.
     */
    public boolean upgradeSkill(Player player, String skillId) {
        if (!plugin.getPlayerClassManager().isDog(player)) {
            player.sendMessage(MessageUtil.color("&cOnly the &6Dog class &ccan upgrade skills."));
            return false;
        }

        if (!isValidSkill(skillId)) {
            player.sendMessage(MessageUtil.color("&cUnknown skill: &f" + skillId));
            return false;
        }

        var data = plugin.getPlayerDataManager().get(player);
        int currentLevel = data.getSkillLevel(skillId);
        int maxLevel = getMaxLevel(skillId);

        if (currentLevel >= maxLevel) {
            player.sendMessage(MessageUtil.color("&c" + getDisplayName(skillId) + " &cis already at max level!"));
            return false;
        }

        int cost = getCost(skillId);
        if (data.getSkillPoints() < cost) {
            player.sendMessage(MessageUtil.color(
                    "&cNot enough skill points. Need &e" + cost + "&c, have &e" + data.getSkillPoints() + "&c."));
            return false;
        }

        // Deduct and upgrade
        data.addSkillPoints(-cost);
        data.setSkillLevel(skillId, currentLevel + 1);
        plugin.getPlayerDataManager().save(player.getUniqueId());

        player.sendMessage(MessageUtil.color(
                "&a✦ &f" + getDisplayName(skillId) + " upgraded to level &e"
                + (currentLevel + 1) + "/" + maxLevel + "!"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);

        return true;
    }

    // ----------------------------------------------------------------
    // Display
    // ----------------------------------------------------------------

    /**
     * Shows the full skill tree to a player.
     */
    public void showSkillTree(Player player) {
        var data = plugin.getPlayerDataManager().get(player);
        player.sendMessage(MessageUtil.color("&8&m--------------------&r &6Dog Skill Tree &8&m--------------------"));
        player.sendMessage(MessageUtil.color("&7Skill Points: &e" + data.getSkillPoints()));
        player.sendMessage("");

        for (String skillId : SKILL_ORDER) {
            if (!plugin.getConfig().contains("skill_tree." + skillId)) continue;
            int current = data.getSkillLevel(skillId);
            int max     = getMaxLevel(skillId);
            int cost    = getCost(skillId);

            String levelBar = buildLevelBar(current, max);
            String status = current >= max ? "&a[MAXED]" : "&7[Cost: &e" + cost + " pts&7]";

            player.sendMessage(MessageUtil.color(
                    "&6" + getDisplayName(skillId)
                    + " &f" + levelBar + " " + status));
            player.sendMessage(MessageUtil.color("  &7" + getDescription(skillId)));
        }

        player.sendMessage(MessageUtil.color("&8&m-------------------------------------------"));
        player.sendMessage(MessageUtil.color("&7Use &e/dogskill upgrade <skill_id> &7to upgrade."));
    }

    // ----------------------------------------------------------------
    // Config helpers
    // ----------------------------------------------------------------

    public boolean isValidSkill(String skillId) {
        return plugin.getConfig().contains("skill_tree." + skillId);
    }

    public int getMaxLevel(String skillId) {
        return plugin.getConfig().getInt("skill_tree." + skillId + ".max_level", 1);
    }

    public int getCost(String skillId) {
        return plugin.getConfig().getInt("skill_tree." + skillId + ".cost", 3);
    }

    public String getDisplayName(String skillId) {
        return plugin.getConfig().getString("skill_tree." + skillId + ".display_name", skillId);
    }

    public String getDescription(String skillId) {
        return plugin.getConfig().getString("skill_tree." + skillId + ".description", "");
    }

    // ----------------------------------------------------------------
    // Utility
    // ----------------------------------------------------------------

    private String buildLevelBar(int current, int max) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < max; i++) {
            sb.append(i < current ? "&a█" : "&8░");
        }
        sb.append("&f]");
        return sb.toString();
    }

    public List<String> getSkillIds() {
        return Collections.unmodifiableList(SKILL_ORDER);
    }
}
