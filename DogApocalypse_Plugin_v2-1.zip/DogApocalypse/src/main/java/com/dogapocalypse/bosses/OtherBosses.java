package com.dogapocalypse.bosses;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.boss.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

// =============================================================
// WAR MACHINE ROBOT
// =============================================================

/**
 * War Machine Robot — 3-phase mechanical boss.
 *
 * Phase 1: Cannon barrage (fires Fireballs at players).
 * Phase 2: Missile spread (fires Fireballs in wide arc).
 * Phase 3: Overload mode — constant fire + shield minions.
 */
class WarMachineRobot extends AbstractBoss {

    private BossBar bossBar;
    private final List<Player> arenaPlayers = new ArrayList<>();
    private int attackCooldown = 0;

    WarMachineRobot(DogApocalypsePlugin plugin) {
        super(plugin, "war_machine", "&7War Machine Robot");
        this.maxHealth = plugin.getConfig().getDouble("bosses.war_machine.health", 450.0);
        this.phaseThresholds = Arrays.asList(0.66, 0.33);
    }

    @Override
    public LivingEntity spawn(Location location) {
        Elder guardian = (Elder) location.getWorld().spawnEntity(location, EntityType.ELDER_GUARDIAN);
        guardian.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        guardian.setCustomNameVisible(true);
        var h = guardian.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (h != null) { h.setBaseValue(maxHealth); guardian.setHealth(maxHealth); }

        this.entity = guardian;
        this.isActive = true;

        bossBar = plugin.getServer().createBossBar(
                MessageUtil.color(displayName), BarColor.WHITE, BarStyle.SEGMENTED_10);
        bossBar.setVisible(true);

        for (Player p : location.getWorld().getPlayers()) {
            if (p.getLocation().distance(location) <= 40) {
                arenaPlayers.add(p);
                bossBar.addPlayer(p);
                p.sendMessage(MessageUtil.color("&7&l⚙ WAR MACHINE ONLINE! TARGET ACQUIRED. ⚙"));
                p.sendTitle(MessageUtil.color("&7&lWAR MACHINE ROBOT"),
                        MessageUtil.color("&fInitializing combat protocols..."), 10, 60, 20);
            }
        }

        EffectUtil.spawnParticleCircle(location, Particle.CRIT, 40, 5.0);
        location.getWorld().playSound(location, Sound.ENTITY_ELDER_GUARDIAN_CURSE, 3f, 0.5f);
        return guardian;
    }

    @Override
    public void tick() {
        if (!isAlive()) return;
        tickCounter++;
        checkPhaseTransition();
        updateBossBar();
        attackCooldown++;
        int interval = switch (currentPhase) { case 1 -> 35; case 2 -> 20; default -> 50; };
        if (attackCooldown >= interval) { executePhaseAttack(); attackCooldown = 0; }
    }

    @Override
    public void transitionToPhase(int newPhase) {
        String msg = newPhase == 1 ? "&7&l[PHASE 2] &fUpgrading weapon systems!"
                                   : "&7&l[PHASE 3] &fOVERLOAD MODE ACTIVATED!";
        arenaPlayers.stream().filter(Player::isOnline).forEach(p ->
                p.sendMessage(MessageUtil.color(msg)));
        entity.getWorld().playSound(entity.getLocation(), Sound.BLOCK_ANVIL_LAND, 2f, 0.6f);
        EffectUtil.spawnParticleCircle(getLocation(), Particle.SMOKE_LARGE, 50, 4.0);
        if (newPhase == 2) bossBar.setColor(BarColor.RED);
    }

    @Override
    public void executePhaseAttack() {
        if (!isAlive()) return;
        Location loc = getLocation();
        Player target = nearestPlayer(loc);
        if (target == null) return;

        switch (currentPhase) {
            case 0 -> shootFireballAt(loc, target, 1);
            case 1 -> shootSpreadFireballs(loc, 3);
            case 2 -> {
                shootSpreadFireballs(loc, 5);
                plugin.getEnemyManager().spawnEnemy("iron_sentinel", loc.clone().add(rng(-3, 3), 0, rng(-3, 3)));
            }
        }
    }

    private void shootFireballAt(Location from, Player target, int count) {
        Location origin = from.clone().add(0, 2, 0);
        for (int i = 0; i < count; i++) {
            Vector dir = target.getLocation().add(0, 1, 0).subtract(origin).toVector().normalize().multiply(1.3);
            Fireball fb = entity.getWorld().spawn(origin, Fireball.class);
            fb.setDirection(dir);
            fb.setShooter(entity);
            fb.setYield(1.5f);
        }
        from.getWorld().playSound(from, Sound.ENTITY_BLAZE_SHOOT, 1f, 1.2f);
    }

    private void shootSpreadFireballs(Location from, int count) {
        Location origin = from.clone().add(0, 2, 0);
        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            Vector dir = new Vector(Math.cos(angle), 0, Math.sin(angle)).normalize().multiply(1.2);
            Fireball fb = entity.getWorld().spawn(origin, Fireball.class);
            fb.setDirection(dir);
            fb.setShooter(entity);
            fb.setYield(1.2f);
        }
        from.getWorld().playSound(from, Sound.ENTITY_GHAST_SHOOT, 1.5f, 0.8f);
    }

    @Override
    public void onDeath(List<Player> participants) {
        Location loc = getLocation();
        if (loc != null) {
            loc.getWorld().spawnParticle(Particle.EXPLOSION_HUGE, loc.add(0, 2, 0), 8, 1.0, 1.0, 1.0, 0);
            loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.8f);
        }
        if (bossBar != null) { bossBar.removeAll(); bossBar.setVisible(false); }
        participants.stream().filter(Player::isOnline).forEach(p -> {
            p.sendMessage(MessageUtil.color("&7&l⚙ WAR MACHINE DESTROYED! ⚙"));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            plugin.getPlayerDataManager().get(p).addExperience(400);
            plugin.getPlayerDataManager().get(p).addSkillPoints(4);
        });
        isActive = false;
    }

    private Player nearestPlayer(Location loc) {
        return arenaPlayers.stream().filter(p -> p.isOnline() && !p.isDead())
                .min(Comparator.comparingDouble(p -> p.getLocation().distanceSquared(loc)))
                .orElse(null);
    }

    private void updateBossBar() {
        if (bossBar != null && isAlive()) bossBar.setProgress(Math.max(0, Math.min(1, getHealthPercent())));
    }

    private double rng(double min, double max) { return min + Math.random() * (max - min); }
}

// =============================================================
// LABORATORY MONSTER
// =============================================================

/**
 * Laboratory Monster — 2-phase mutant experiment boss.
 *
 * Phase 1: Acid spit + tentacle slam.
 * Phase 2: Splits into two copies (damage reduced), full ability combo.
 */
class LaboratoryMonster extends AbstractBoss {

    private BossBar bossBar;
    private final List<Player> arenaPlayers = new ArrayList<>();
    private int attackCooldown = 0;
    private boolean splitDone = false;

    LaboratoryMonster(DogApocalypsePlugin plugin) {
        super(plugin, "lab_monster", "&dLaboratory Monster");
        this.maxHealth = plugin.getConfig().getDouble("bosses.lab_monster.health", 400.0);
        this.phaseThresholds = Collections.singletonList(0.5);
    }

    @Override
    public LivingEntity spawn(Location location) {
        Ravager ravager = (Ravager) location.getWorld().spawnEntity(location, EntityType.RAVAGER);
        ravager.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(displayName)));
        ravager.setCustomNameVisible(true);
        var h = ravager.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (h != null) { h.setBaseValue(maxHealth); ravager.setHealth(maxHealth); }
        ravager.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0));

        this.entity = ravager;
        this.isActive = true;

        bossBar = plugin.getServer().createBossBar(
                MessageUtil.color(displayName), BarColor.PURPLE, BarStyle.SOLID);
        bossBar.setVisible(true);

        for (Player p : location.getWorld().getPlayers()) {
            if (p.getLocation().distance(location) <= 40) {
                arenaPlayers.add(p);
                bossBar.addPlayer(p);
                p.sendMessage(MessageUtil.color("&d&l☣ LABORATORY MONSTER ESCAPES! ☣"));
                p.sendTitle(MessageUtil.color("&d&lLABORATORY MONSTER"),
                        MessageUtil.color("&5The experiment has gone wrong!"), 10, 60, 20);
            }
        }

        location.getWorld().spawnParticle(Particle.DRIP_LAVA, location.add(0, 2, 0), 40, 1.0, 1.0, 1.0, 0.1);
        location.getWorld().playSound(location, Sound.ENTITY_RAVAGER_ROAR, 3f, 0.5f);
        return ravager;
    }

    @Override
    public void tick() {
        if (!isAlive()) return;
        tickCounter++;
        checkPhaseTransition();
        updateBossBar();
        attackCooldown++;
        int interval = (currentPhase == 0) ? 55 : 30;
        if (attackCooldown >= interval) { executePhaseAttack(); attackCooldown = 0; }
    }

    @Override
    public void transitionToPhase(int newPhase) {
        arenaPlayers.stream().filter(Player::isOnline).forEach(p -> {
            p.sendMessage(MessageUtil.color("&d&l[PHASE 2] &5It's splitting apart — unstable mutations!"));
            p.sendTitle(MessageUtil.color("&5MUTATION CRISIS"), MessageUtil.color("&dWatch out!"), 5, 40, 10);
        });
        bossBar.setColor(BarColor.BLUE);

        // Spawn a weaker clone
        if (!splitDone) {
            splitDone = true;
            Location loc = getLocation();
            if (loc != null) {
                plugin.getEnemyManager().spawnEnemy("radioactive_monkey",
                        loc.clone().add(4, 0, 0));
                plugin.getEnemyManager().spawnEnemy("radioactive_monkey",
                        loc.clone().add(-4, 0, 0));
            }
        }

        entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_RAVAGER_HURT, 2f, 0.6f);
        EffectUtil.spawnParticleCircle(getLocation(), Particle.DRIP_LAVA, 40, 4.0);
    }

    @Override
    public void executePhaseAttack() {
        if (!isAlive()) return;
        Location loc = getLocation();
        Player target = nearestPlayer(loc);
        if (target == null) return;

        if (currentPhase == 0) {
            // Acid spit + stomp alternating
            if (tickCounter % 2 == 0) acidSpit(loc, target);
            else tentacleSlam(loc);
        } else {
            acidSpit(loc, target);
            tentacleSlam(loc);
        }
    }

    private void acidSpit(Location from, Player target) {
        Vector dir = target.getLocation().add(0, 1, 0).subtract(from.clone().add(0, 2, 0))
                          .toVector().normalize().multiply(1.4);
        Snowball ball = entity.getWorld().spawn(from.clone().add(0, 2, 0), Snowball.class);
        ball.setVelocity(dir);
        ball.setShooter(entity);
        from.getWorld().spawnParticle(Particle.DRIP_LAVA, from.clone().add(0, 2, 0), 5, 0.2, 0.2, 0.2, 0);
        from.getWorld().playSound(from, Sound.ENTITY_LLAMA_SPIT, 1f, 0.5f);
    }

    private void tentacleSlam(Location loc) {
        loc.getWorld().getNearbyEntities(loc, 5, 3, 5).forEach(e -> {
            if (e instanceof Player p) {
                Vector kb = p.getLocation().subtract(loc).toVector().setY(1.0).normalize().multiply(2.2);
                p.setVelocity(kb);
                p.damage(8.0, entity);
                p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 80, 1, false, true));
            }
        });
        loc.getWorld().spawnParticle(Particle.EXPLOSION_NORMAL, loc.clone().add(0, 1, 0), 10, 2.0, 0.5, 2.0, 0.05);
        loc.getWorld().playSound(loc, Sound.ENTITY_RAVAGER_ATTACK, 1.5f, 0.6f);
    }

    @Override
    public void onDeath(List<Player> participants) {
        Location loc = getLocation();
        if (loc != null) {
            loc.getWorld().spawnParticle(Particle.DRIP_LAVA, loc.add(0, 2, 0), 50, 1.0, 1.0, 1.0, 0.2);
            loc.getWorld().playSound(loc, Sound.ENTITY_RAVAGER_DEATH, 2f, 0.7f);
        }
        if (bossBar != null) { bossBar.removeAll(); bossBar.setVisible(false); }
        participants.stream().filter(Player::isOnline).forEach(p -> {
            p.sendMessage(MessageUtil.color("&d&l☣ LABORATORY MONSTER CONTAINED! ☣"));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.9f);
            plugin.getPlayerDataManager().get(p).addExperience(350);
            plugin.getPlayerDataManager().get(p).addSkillPoints(3);
        });
        isActive = false;
    }

    private Player nearestPlayer(Location loc) {
        return arenaPlayers.stream().filter(p -> p.isOnline() && !p.isDead())
                .min(Comparator.comparingDouble(p -> p.getLocation().distanceSquared(loc)))
                .orElse(null);
    }

    private void updateBossBar() {
        if (bossBar != null && isAlive()) bossBar.setProgress(Math.max(0, Math.min(1, getHealthPercent())));
    }
}
