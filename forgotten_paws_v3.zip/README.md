# 🐾 FORGOTTEN PAWS
### Jogo 2D Plataforma Multiplayer | Dark Fantasy Post-Apocalíptico

---

## 🚀 Como jogar no navegador (recomendado)

### Passo 1 — Instale as dependências

```bash
pip install pygame pygbag
```

> Precisa de Python 3.10+ e pip instalado.

---

### Passo 2 — Execute o servidor web

Abra o terminal **dentro da pasta `forgotten_paws`** (a pasta que contém outra pasta `forgotten_paws/`) e rode:

```bash
python -m pygbag forgotten_paws
```

O Pygbag vai abrir automaticamente no seu navegador em:
**http://localhost:8000**

> Aguarde o carregamento (pode demorar alguns segundos na primeira vez).

---

### Passo 3 — Jogue!

O jogo abrirá direto no navegador. Funciona em desktop e mobile!

---

## 🖥️ Como jogar direto no desktop (sem navegador)

```bash
cd forgotten_paws
python main.py
```

---

## 📦 Publicar online (itch.io / GitHub Pages)

```bash
python -m pygbag --build forgotten_paws
```

Suba o conteúdo de `build/web/` para qualquer hospedagem estática.

---

## 📱 Controles Mobile (tela touch)

O jogo detecta automaticamente toque/clique e exibe botões na tela durante o jogo:

```
┌─────────────────────────────────────────────────────┐
│              [  II  ]  ← botão pausar               │
│                                                      │
│                                         [ESP]        │
│  [◀]  [▶]                        [TIR] [ATK]        │
│       [▼]                              [⬆ pular]    │
└─────────────────────────────────────────────────────┘
```

- **D-pad esquerdo:** ◀ ▶ ▼ (mover + deslizar)
- **Botão ⬆ / ▲ direito:** pular (pulo duplo: toque 2x)
- **ATK:** ataque corpo a corpo
- **TIR:** ataque à distância
- **ESP:** habilidade especial (Rex: usar poder absorvido)
- **II:** pausar / retomar
- Menus: todos os botões são tapeáveis

> ⚠️ **Mobile controla apenas P1 (KIRA).** Para multiplayer use teclado.

---

## 🎮 Controles Teclado

| Jogador | Personagem | Mover | Pular | Deslizar | Atacar | Tiro | Especial |
|---------|-----------|-------|-------|----------|--------|------|----------|
| P1 | KIRA | A / D | W | S | Z | X | C |
| P2 | REX | ← / → | ↑ | ↓ | U | I | O |
| P3 | VALE | J / L | I | K | N | M | , |
| P4 | ZAP | Num4 / Num6 | Num8 | Num5 | Num7 | Num9 | Num1 |

| Tecla | Ação |
|-------|------|
| ESC | Menu principal |
| R | Reiniciar fase |
| ESPAÇO | Pausar |

---

## 👾 Personagens

### 🗡️ KIRA — A Protagonista
- Espada corpo a corpo + Pistola
- **Especial:** Dash de fúria (atravessa inimigos com invencibilidade)

### 🐾 REX — O Cachorro Mutante ⭐
- **Habilidade única:** Absorve poderes dos inimigos ao derrotá-los
- 🔥 **Fogo** (dragão) → projéteis de fogo + disparo triplo
- ⚡ **Elétrico** (robô/inseto) → explosão elétrica em área
- 🐒 **Escalar** (macaco) → wall-slide + pulos extras

### 🏹 VALE — A Arqueira
- **Especial:** Chuva de 6 flechas simultâneas

### ⚡ ZAP — O Cientista
- **Especial:** Overcharge — atordoa todos os inimigos próximos

---

## 🌍 Fases

| Fase | Inimigos | Boss |
|------|----------|------|
| Cidade Destruída | Ratos, Insetos, Robôs, Dragões | Dragão Alfa (2 fases) |
| Floresta Mutante | Macacos, Insetos, Robôs | Macaco Alfa Radioativo (2 fases) |

---

## 🛠️ Tecnologias

- **Python 3.10+**
- **Pygame** — engine do jogo
- **Pygbag** — compilação para WebAssembly / navegador

---

## 📁 Estrutura

```
forgotten_paws/          ← pasta raiz (rode pygbag aqui)
└── forgotten_paws/      ← pasta do jogo
    └── main.py          ← código completo do jogo
```
### Jogo 2D Plataforma Multiplayer | Dark Fantasy Post-Apocalíptico

---

## 🚀 Como jogar no navegador (recomendado)

### Passo 1 — Instale as dependências

```bash
pip install pygame pygbag
```

> Precisa de Python 3.10+ e pip instalado.

---

### Passo 2 — Execute o servidor web

Abra o terminal **dentro da pasta `forgotten_paws`** (a pasta que contém outra pasta `forgotten_paws/`) e rode:

```bash
python -m pygbag forgotten_paws
```

O Pygbag vai abrir automaticamente no seu navegador em:
**http://localhost:8000**

> Aguarde o carregamento (pode demorar alguns segundos na primeira vez).

---

### Passo 3 — Jogue!

O jogo abrirá direto no navegador. Selecione o número de jogadores e divirta-se!

---

## 🖥️ Como jogar direto no desktop (sem navegador)

Se quiser rodar localmente sem o navegador:

```bash
cd forgotten_paws
python main.py
```

---

## 📦 Publicar online (itch.io / GitHub Pages)

```bash
python -m pygbag --build forgotten_paws
```

Isso gera uma pasta `build/` com arquivos estáticos prontos para deploy.
Suba o conteúdo de `build/web/` para qualquer hospedagem estática.

---

## 🎮 Controles

| Jogador | Personagem | Mover | Pular | Deslizar | Atacar | Tiro | Especial |
|---------|-----------|-------|-------|----------|--------|------|----------|
| P1 | KIRA | A / D | W | S | Z | X | C |
| P2 | REX | ← / → | ↑ | ↓ | U | I | O |
| P3 | VALE | J / L | I | K | N | M | , |
| P4 | ZAP | Num4 / Num6 | Num8 | Num5 | Num7 | Num9 | Num1 |

| Tecla | Ação |
|-------|------|
| ESC | Menu principal |
| R | Reiniciar fase |
| ESPAÇO | Pausar |

---

## 👾 Personagens

### 🗡️ KIRA — A Protagonista
- Espada corpo a corpo + Pistola
- **Especial:** Dash de fúria (atravessa inimigos com invencibilidade)
- Alta velocidade, pulo duplo

### 🐾 REX — O Cachorro Mutante ⭐
- **Habilidade única:** Absorve poderes dos inimigos ao derrotá-los
- 🔥 **Fogo** (dragão) → projéteis de fogo + disparo triplo
- ⚡ **Elétrico** (robô/inseto) → explosão elétrica em área
- 🐒 **Escalar** (macaco) → wall-slide + pulos extras
- Usa `O` para ciclar entre poderes absorvidos

### 🏹 VALE — A Arqueira
- Arco longo alcance
- **Especial:** Chuva de 6 flechas simultâneas
- Ideal para combate à distância

### ⚡ ZAP — O Cientista
- Campo elétrico corpo a corpo
- **Especial:** Overcharge — atordoa todos os inimigos próximos
- Maior HP do grupo, mais lento

---

## 🌍 Fases

### Ato I — Cidade Destruída
- Inimigos: Ratos, Insetos, Robôs, Dragões
- **Boss:** Dragão Alfa (2 fases — fase 2 com velocidade e dano aumentados)

### Ato II — Floresta Mutante
- Inimigos: Macacos, Insetos, Robôs
- **Boss:** Macaco Alfa Radioativo (2 fases)

---

## 📖 História

O mundo sofreu um apocalipse misterioso.

Uma garota acorda sem memórias, em meio a ruínas e criaturas mutantes. Ao seu lado está seu cachorro — agora mutante, com poderes absurdos — o único elo com sua vida passada.

Conforme exploram o mundo e derrotam monstros, **fragmentos de memória** voltam...

> *"...Rex... eu me lembro desse nome... havia um filhote que me lambeu o rosto quando eu chorava no laboratório..."*

---

## 🛠️ Tecnologias

- **Python 3.10+**
- **Pygame** — engine do jogo
- **Pygbag** — compilação para WebAssembly / navegador

---

## 📁 Estrutura

```
forgotten_paws/          ← pasta raiz (rode pygbag aqui)
└── forgotten_paws/      ← pasta do jogo
    └── main.py          ← código completo do jogo
```
