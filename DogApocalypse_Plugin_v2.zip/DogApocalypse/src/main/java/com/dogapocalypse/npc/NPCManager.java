package com.dogapocalypse.npc;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.util.EffectUtil;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

// ======================================================================
// NpcData — holds one NPC's definition
// ======================================================================

/**
 * Immutable data object describing a single NPC.
 */
class NpcData {

    enum NpcType { STORY, MERCHANT, GUIDE, QUEST }

    final String id;
    final String name;
    final NpcType type;
    final String[] dialogue;   // lines to display in sequence
    final String questTrigger; // optional — null if none
    final Location location;
    final EntityType entityType;

    NpcData(String id, String name, NpcType type, String[] dialogue,
            String questTrigger, Location location, EntityType entityType) {
        this.id          = id;
        this.name        = name;
        this.type        = type;
        this.dialogue    = dialogue;
        this.questTrigger = questTrigger;
        this.location    = location;
        this.entityType  = entityType;
    }
}

// ======================================================================
// NPCManager — spawns, tracks and handles NPC interactions
// ======================================================================

/**
 * NPCManager — manages all story and guide NPCs in the game world.
 *
 * NPCs are Villager/ArmorStand entities with custom names and metadata.
 * They are persistent: respawned on plugin enable if missing.
 * Interaction is via right-click (PlayerInteractEntityEvent).
 *
 * NPC Types:
 *  STORY    — unlocks story fragments, one-time dialogue
 *  GUIDE    — repeatable hints and lore
 *  MERCHANT — sells items (simplified: gives free starter kit refill)
 *  QUEST    — triggers a level start or special event
 */
public class NPCManager implements Listener {

    private final DogApocalypsePlugin plugin;

    /** NPC entity UUID -> NpcData */
    private final Map<UUID, NpcData> activeNpcs = new HashMap<>();

    /** NPC id -> spawned entity UUID */
    private final Map<String, UUID> npcIdMap = new HashMap<>();

    /** Player UUID -> NPC id -> whether they've heard this dialogue already */
    private final Map<UUID, Set<String>> heardDialogue = new HashMap<>();

    /** Cooldown per player to prevent spam-clicking */
    private final Map<UUID, Long> interactCooldown = new HashMap<>();

    public NPCManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    // ---------------------------------------------------------------
    // Spawn all NPCs for a given level world
    // ---------------------------------------------------------------

    public void spawnAllNpcs(World world) {
        plugin.getLogger().info("[NPC] Spawning NPCs in world: " + world.getName());

        List<NpcData> npcs = buildNpcDefinitions(world);
        for (NpcData data : npcs) {
            spawnNpc(data);
        }

        plugin.getLogger().info("[NPC] Spawned " + npcs.size() + " NPCs.");
    }

    // ---------------------------------------------------------------
    // NPC definitions
    // ---------------------------------------------------------------

    private List<NpcData> buildNpcDefinitions(World w) {
        List<NpcData> list = new ArrayList<>();
        int B = 64; // BASE_Y

        // --- HUB / LOBBY NPCs ---
        list.add(new NpcData("ava_intro", "&f&lAva (Ghost Memory)", NpcData.NpcType.STORY,
            new String[]{
                "&7&o\"...Where am I? What happened to the city?\"",
                "&7&o\"I can't remember anything...\"",
                "&7&o\"But this dog — somehow I trust him.\"",
                "&6[Talk to Rex the Dog to choose your class and begin.]"
            },
            null,
            new Location(w, 8, B + 1, 4),
            EntityType.VILLAGER));

        list.add(new NpcData("rex_guide", "&6Rex (Your Dog)", NpcData.NpcType.GUIDE,
            new String[]{
                "&e*Rex sniffs the air and growls at the ruins ahead*",
                "&7[Use &e/class choose dog&7] to play as Rex.",
                "&7[Use &e/class choose fighter&7] or &e/class choose archer&7 to play as Ava's allies.",
                "&7Form a party: &e/coop invite <friend>",
                "&7Then start your journey: &e/level start level_1"
            },
            null,
            new Location(w, 10, B + 1, 4),
            EntityType.WOLF));

        list.add(new NpcData("survivor_camp", "&eSurvivor — Maria", NpcData.NpcType.STORY,
            new String[]{
                "&7\"You survived the blast? I thought everyone was gone...\"",
                "&7\"The gorillas from Lab 7 escaped three days ago.\"",
                "&7\"They're heading toward the old city. You need to stop them.\"",
                "&c\"Whatever you do — don't go near the Lab. It's not safe.\""
            },
            null,
            new Location(w, 14, B + 1, 6),
            EntityType.VILLAGER));

        list.add(new NpcData("weapons_dealer", "&bArms Dealer — Viktor", NpcData.NpcType.MERCHANT,
            new String[]{
                "&7\"Ah, survivors! I've got gear — good gear.\"",
                "&7\"Your class kit has been refreshed. Don't waste it.\"",
                "&a[Kit refreshed! Check your inventory.]"
            },
            "refresh_kit",
            new Location(w, 16, B + 1, 6),
            EntityType.PILLAGER));

        // --- LEVEL 1 CHECKPOINTS ---
        list.add(new NpcData("l1_cp1_npc", "&7Ghost — Fallen Soldier", NpcData.NpcType.STORY,
            new String[]{
                "&8&o\"We held this street for three days...\"",
                "&8&o\"They just kept coming. Dozens of them.\"",
                "&8&o\"The source is further north. In the lab ruins.\"",
                "&8&o\"Don't let them win.\""
            },
            null,
            new Location(w, 9, B + 1, 92),
            EntityType.ZOMBIE));

        list.add(new NpcData("l1_cp2_npc", "&eSurvivor — Old Man Chen", NpcData.NpcType.GUIDE,
            new String[]{
                "&7\"I saw what they did to the gorillas in that lab.\"",
                "&7\"Injected them with something glowing, green.\"",
                "&7\"The big one — they called it APEX-G1.\"",
                "&7\"It absorbed the mutations of every animal it fought.\"",
                "&7\"Sound familiar? That's what Rex does too...\""
            },
            null,
            new Location(w, 9, B + 1, 162),
            EntityType.VILLAGER));

        list.add(new NpcData("l1_boss_hint", "&4Corrupted Terminal", NpcData.NpcType.GUIDE,
            new String[]{
                "&c[SYSTEM LOG — DAY 14]",
                "&7APEX-G1 containment breached.",
                "&7Subject has absorbed 3 mutation signatures.",
                "&7Estimated combat rating: CRITICAL.",
                "&cAPPROACH ONLY WITH EXTREME CAUTION."
            },
            null,
            new Location(w, 9, B + 1, 92 + 68),
            EntityType.ARMOR_STAND));

        // --- LEVEL 2 CHECKPOINTS ---
        list.add(new NpcData("l2_cp1_npc", "&2Forest Spirit", NpcData.NpcType.STORY,
            new String[]{
                "&2&o\"The forest remembers what was done to it...\"",
                "&2&o\"Every tree twisted by radiation.\"",
                "&2&o\"The spider creatures nest in the canopy.\"",
                "&2&o\"Their silk traps everything. Even memories.\""
            },
            null,
            new Location(w, 9, B + 1, 1200 + 162),
            EntityType.VILLAGER));

        list.add(new NpcData("l2_cp2_npc", "&aBotanist — Dr. Lena", NpcData.NpcType.GUIDE,
            new String[]{
                "&7\"I've been documenting the mutations for weeks.\"",
                "&7\"The Lab Monster — they call it APEX-B2.\"",
                "&7\"It was a failed splice of 4 different species.\"",
                "&7\"At half-health it triggers an emergency mitosis.\"",
                "&7\"Split into two. Kill both parts quickly.\""
            },
            null,
            new Location(w, 9, B + 1, 1200 + 232),
            EntityType.VILLAGER));

        // --- LEVEL 3 CHECKPOINTS ---
        list.add(new NpcData("l3_cp1_npc", "&7Resistance Radio", NpcData.NpcType.STORY,
            new String[]{
                "&7[STATIC] ...this is the last broadcast...",
                "&7The War Machine prototype is still operational.",
                "&7It was designed to hunt down Project APEX escapees.",
                "&7Ironic — now it hunts everything."
            },
            null,
            new Location(w, 9, B + 1, 2400 + 92),
            EntityType.ARMOR_STAND));

        list.add(new NpcData("l3_cp2_npc", "&cMilitary Ghost", NpcData.NpcType.STORY,
            new String[]{
                "&8&o\"I built that machine... I'm sorry.\"",
                "&8&o\"Phase 2 it upgrades its weapon systems.\"",
                "&8&o\"Phase 3 — overload. It becomes unstable.\"",
                "&8&o\"Hit it fast in phase 3. It won't last long.\""
            },
            null,
            new Location(w, 9, B + 1, 2400 + 162),
            EntityType.ZOMBIE));

        list.add(new NpcData("l3_cp3_npc", "&6Ava Memory Shard #9", NpcData.NpcType.STORY,
            new String[]{
                "&5&o[Memory Flash] A sterile white room...",
                "&5&o[Memory Flash] A man in uniform signs a document.",
                "&5&o[Memory Flash] \"Project APEX is approved for Phase 3.\"",
                "&5&o[Memory Flash] Ava's voice: \"No. This has to stop.\""
            },
            null,
            new Location(w, 9, B + 1, 2400 + 237),
            EntityType.ARMOR_STAND));

        // --- LEVEL 4 CHECKPOINTS (Dragon's Lair) ---
        list.add(new NpcData("l4_cp1_npc", "&4Dragon Cultist Ghost", NpcData.NpcType.STORY,
            new String[]{
                "&4&o\"He chose this for himself...\"",
                "&4&o\"The General injected himself with everything.\"",
                "&4&o\"Dragon, gorilla, blaze, phantom — all of them.\"",
                "&4&o\"He said he would become perfect. He became a monster.\""
            },
            null,
            new Location(w, 9, B + 1, 3600 + 102),
            EntityType.ZOMBIE));

        list.add(new NpcData("l4_cp2_npc", "&5Ava's Memory — Full Recall", NpcData.NpcType.STORY,
            new String[]{
                "&f\"I remember now. All of it.\"",
                "&f\"I created the cure and hid it in Rex.\"",
                "&f\"When the General falls, Rex can release it.\"",
                "&f\"It will reverse the mutations. Save what's left.\"",
                "&6\"Rex... it's time. We finish this.\""
            },
            null,
            new Location(w, 9, B + 1, 3600 + 187),
            EntityType.VILLAGER));

        list.add(new NpcData("l4_cp3_npc", "&4General's Broadcast", NpcData.NpcType.GUIDE,
            new String[]{
                "&4[EMERGENCY BROADCAST]",
                "&c\"I AM THE APEX. I AM EVOLUTION.\"",
                "&c\"Your dog carries the cure? Let him come.\"",
                "&c\"I will absorb him too. I will absorb EVERYTHING.\"",
                "&4[End of transmission]"
            },
            null,
            new Location(w, 9, B + 1, 3600 + 257),
            EntityType.ARMOR_STAND));

        list.add(new NpcData("l4_final_npc", "&4&lBEFORE THE FINAL BATTLE", NpcData.NpcType.STORY,
            new String[]{
                "&f\"Ava stands at the entrance. Rex at her side.\"",
                "&f\"Beyond this door is the end of everything they've fought for.\"",
                "&6Rex growls. His mutations flare with light.",
                "&f\"Whatever happens in there...\" she whispers.",
                "&f\"...thank you, Rex. For everything.\"",
                "&c[ENTER THE ARENA TO FACE THE MUTANT DRAGON]"
            },
            null,
            new Location(w, 3, B + 1, 3600 + 282),
            EntityType.VILLAGER));

        return list;
    }

    // ---------------------------------------------------------------
    // Spawning
    // ---------------------------------------------------------------

    private void spawnNpc(NpcData data) {
        if (data.location == null || data.location.getWorld() == null) return;

        // Remove old entity if exists
        UUID oldUUID = npcIdMap.get(data.id);
        if (oldUUID != null) {
            Entity old = Bukkit.getEntity(oldUUID);
            if (old != null) old.remove();
        }

        Entity entity;

        if (data.entityType == EntityType.ARMOR_STAND) {
            ArmorStand stand = data.location.getWorld().spawn(data.location, ArmorStand.class, as -> {
                as.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                as.setCustomNameVisible(true);
                as.setGravity(false);
                as.setInvisible(true);
                as.setInvulnerable(true);
                as.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                as.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = stand;
        } else if (data.entityType == EntityType.VILLAGER) {
            Villager villager = data.location.getWorld().spawn(data.location, Villager.class, v -> {
                v.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                v.setCustomNameVisible(true);
                v.setInvulnerable(true);
                v.setAI(false);
                v.setSilent(false);
                v.setVillagerType(Villager.Type.PLAINS);
                v.setProfession(switch (data.type) {
                    case MERCHANT -> Villager.Profession.WEAPONSMITH;
                    case GUIDE    -> Villager.Profession.LIBRARIAN;
                    case QUEST    -> Villager.Profession.ARMORER;
                    default       -> Villager.Profession.NONE;
                });
                v.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                v.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = villager;
        } else if (data.entityType == EntityType.WOLF) {
            Wolf wolf = data.location.getWorld().spawn(data.location, Wolf.class, w -> {
                w.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                w.setCustomNameVisible(true);
                w.setInvulnerable(true);
                w.setAI(false);
                w.setTamed(true);
                w.setCollarColor(DyeColor.RED);
                w.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                w.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = wolf;
        } else if (data.entityType == EntityType.ZOMBIE) {
            Zombie zombie = data.location.getWorld().spawn(data.location, Zombie.class, z -> {
                z.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                z.setCustomNameVisible(true);
                z.setInvulnerable(true);
                z.setAI(false);
                z.setSilent(true);
                z.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                z.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
            entity = zombie;
        } else {
            // Pillager or fallback
            entity = data.location.getWorld().spawn(data.location, Villager.class, v -> {
                v.customName(net.kyori.adventure.text.Component.text(MessageUtil.color(data.name)));
                v.setCustomNameVisible(true);
                v.setInvulnerable(true);
                v.setAI(false);
                v.setMetadata("da_npc", new FixedMetadataValue(plugin, data.id));
                v.setMetadata("da_npc_id", new FixedMetadataValue(plugin, data.id));
            });
        }

        activeNpcs.put(entity.getUniqueId(), data);
        npcIdMap.put(data.id, entity.getUniqueId());

        // Ambient glow for story NPCs
        if (data.type == NpcData.NpcType.STORY && entity instanceof LivingEntity le) {
            le.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, false, false));
        }
    }

    // ---------------------------------------------------------------
    // Interaction listener
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        Entity entity = event.getRightClicked();
        if (!entity.hasMetadata("da_npc")) return;
        event.setCancelled(true);

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Cooldown check (1.5s between interactions)
        long now = System.currentTimeMillis();
        Long cd = interactCooldown.get(uuid);
        if (cd != null && now - cd < 1500) return;
        interactCooldown.put(uuid, now);

        NpcData data = activeNpcs.get(entity.getUniqueId());
        if (data == null) return;

        // Particle effect on interaction
        entity.getWorld().spawnParticle(Particle.VILLAGER_HAPPY,
                entity.getLocation().add(0, 2, 0), 8, 0.4, 0.4, 0.4, 0.02);
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_AMBIENT, 0.7f, 1.1f);

        // Handle special triggers
        if ("refresh_kit".equals(data.questTrigger)) {
            plugin.getPlayerClassManager().applyClassStats(player,
                    plugin.getPlayerDataManager().get(player).getPlayerClass());
            // Regive kit
            var cls = plugin.getPlayerDataManager().get(player).getPlayerClass();
            plugin.getPlayerClassManager().setClass(player, cls);
        }

        // Mark if one-time dialogue
        boolean isNew = !hasHeard(uuid, data.id);
        if (isNew && data.type == NpcData.NpcType.STORY) {
            markHeard(uuid, data.id);
        }

        // Play dialogue
        plugin.getDialogueManager().playDialogue(player, data.name, data.dialogue);

        // Unlock story fragment for story NPCs
        if (data.type == NpcData.NpcType.STORY && isNew) {
            new BukkitRunnable() {
                @Override public void run() {
                    plugin.getDialogueManager().unlockNextFragment(player);
                }
            }.runTaskLater(plugin, 80L);
        }
    }

    // Prevent NPCs from being damaged
    @EventHandler(ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity().hasMetadata("da_npc")) {
            event.setCancelled(true);
        }
    }

    // Prevent NPCs from being pushed/moved
    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        if (event.getEntity().hasMetadata("da_npc") || event.getTarget() != null
                && event.getTarget().hasMetadata("da_npc")) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------
    // Utility
    // ---------------------------------------------------------------

    private boolean hasHeard(UUID playerUUID, String npcId) {
        Set<String> heard = heardDialogue.get(playerUUID);
        return heard != null && heard.contains(npcId);
    }

    private void markHeard(UUID playerUUID, String npcId) {
        heardDialogue.computeIfAbsent(playerUUID, k -> new HashSet<>()).add(npcId);
    }

    public void cleanupAll() {
        for (UUID entityUUID : activeNpcs.keySet()) {
            Entity e = Bukkit.getEntity(entityUUID);
            if (e != null) e.remove();
        }
        activeNpcs.clear();
        npcIdMap.clear();
    }

    public int getNpcCount() { return activeNpcs.size(); }
}
