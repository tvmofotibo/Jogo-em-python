# 🐕 DogApocalypse — Plugin Documentation

A cooperative action platform RPG for PaperMC 1.20+, inspired by Cuphead and Super Mario,
set in a post-apocalyptic world where a girl and her mutated dog fight to reclaim humanity.

---

## 📁 Project Structure

```
DogApocalypse/
├── pom.xml
└── src/main/
    ├── resources/
    │   ├── plugin.yml
    │   └── config.yml
    └── java/com/dogapocalypse/
        ├── core/
        │   ├── DogApocalypsePlugin.java      ← Main entry point
        │   └── PlayerDataManager.java        ← Per-player YAML persistence
        ├── classes/
        │   ├── PlayerClass.java              ← DOG / FIGHTER / ARCHER enum
        │   ├── PlayerClassManager.java       ← Class assignment + stat application
        │   └── KitFactory.java               ← Starter item kits per class
        ├── dogpowers/
        │   ├── DogPower.java                 ← Interface: activate / useAbility / deactivate
        │   ├── DogPowerManager.java          ← Central power absorption system
        │   ├── BlazePower.java               ← Fire breath (cone AOE)
        │   └── OtherPowers.java              ← Spider, Guardian, Phantom, IronGolem powers
        ├── combat/
        │   └── CombatManager.java            ← Class damage modifiers + Fighter block
        ├── enemies/
        │   ├── CustomEnemy.java              ← Abstract enemy base
        │   ├── EnemyTypes.java               ← Concrete enemies + factory
        │   └── EnemyManager.java             ← Spawn, tick, death handling
        ├── bosses/
        │   ├── AbstractBoss.java             ← Boss base class with phase system
        │   ├── BossManager.java              ← Spawn + tick all bosses
        │   ├── MutantDragon.java             ← 3-phase final boss
        │   ├── RadioactiveGorilla.java       ← 2-phase berserker boss
        │   └── OtherBosses.java              ← WarMachineRobot + LaboratoryMonster
        ├── levels/
        │   ├── LevelManager.java             ← Level sessions + wave spawning
        │   └── CheckpointManager.java        ← Checkpoint save + respawn
        ├── coop/
        │   ├── CoopManager.java              ← Party system (invite/accept/leave)
        │   └── ReviveSystem.java             ← Downed state + teammate revive
        ├── skills/
        │   └── SkillTreeManager.java         ← Dog skill upgrades with points
        ├── story/
        │   └── DialogueManager.java          ← 12-fragment story + NPC dialogue
        ├── listeners/
        │   ├── DogAbilityListener.java       ← Double jump, dash, fall damage
        │   └── AllListeners.java             ← All other event listeners
        ├── commands/
        │   └── AllCommands.java              ← All command handlers
        └── util/
            ├── MessageUtil.java              ← Color code translation
            └── EffectUtil.java               ← Particle helpers
```

---

## 🎮 Systems Overview

### 1. Player Class System
Three classes, chosen with `/class choose <type>`:

| Class   | Health | Speed | Specialty                          |
|---------|--------|-------|------------------------------------|
| Dog     | 18♥    | Fast  | Double jump, dash, power absorption|
| Fighter | 24♥    | Med   | +4 melee damage, 35% shield block  |
| Archer  | 16♥    | Med   | +3 arrow damage, precision shots   |

Each class gets custom starter items and permanent stat attributes.

---

### 2. Power Absorption System (Dog only)
When the Dog class kills an absorbable enemy, it absorbs their power:

| Power      | Source Enemy   | Ability                          | Cooldown |
|------------|----------------|----------------------------------|----------|
| Blaze      | Flame Blaze    | Fire breath cone (8 block range) | 4s       |
| Spider     | Mutant Spider  | Wall climb + web shot slow       | 2s       |
| Guardian   | Sea Guardian   | Underwater dash at 2.2x speed    | 3s       |
| Phantom    | Ghost Phantom  | Launch + extended glide          | 2.5s     |
| Iron Golem | Iron Sentinel  | Ground smash + knockup           | 5s       |

Only **one power** at a time. Right-click the **Totem of Undying** to activate.

---

### 3. Dog Skill Tree
Unlocked with skill points (earned by defeating enemies and bosses).

| Skill ID         | Effect                        | Max Level | Cost |
|------------------|-------------------------------|-----------|------|
| dash_upgrade     | Faster dash, less cooldown    | 3         | 3 pts|
| extra_jump       | Triple jump (3rd air jump)    | 1         | 5 pts|
| power_duration   | Powers last +20s per level    | 3         | 4 pts|
| ability_strength | +25% power damage per level   | 3         | 4 pts|
| fall_resilience  | −15% fall damage per level    | 2         | 2 pts|

---

### 4. Boss System
Four bosses, each with 2–3 phases triggered by health thresholds:

**Mutant Dragon** (500 HP, 3 phases)
- Phase 1: Tail sweep, fire breath
- Phase 2: Enraged, spawns minions, dive attack
- Phase 3: Airborne, fire storm rain

**Radioactive Gorilla** (350 HP, 2 phases)
- Phase 1: Charge, ground pound, toxic spit
- Phase 2: Berserker mode, radiation cloud, rapid charge

**War Machine Robot** (450 HP, 3 phases)
- Phase 1: Cannon barrage
- Phase 2: Spread missiles
- Phase 3: Overload, spawns Iron Sentinels

**Laboratory Monster** (400 HP, 2 phases)
- Phase 1: Acid spit, tentacle slam
- Phase 2: Splits — spawns Radioactive Monkey clones

---

### 5. Level System
Four linear levels, each with:
- Spawn point (configurable in config.yml)
- Enemy waves (3–6 waves, scaling difficulty)
- Checkpoint system (evenly spaced respawn points)
- Mini-boss then main boss fight

Start a level: `/level start level_1` (admin)

---

### 6. Coop System (max 4 players)
- `/coop invite <player>` → send party invite
- `/coop accept` → join party
- `/coop leave` → leave party
- `/coop status` → show party members and classes

**Revive Mechanic:**
- On death during a level session, player enters **DOWNED** state (15s window)
- Teammates stand within 3 blocks to progressively revive (10s channel)
- Progress shown as action bar fill bar
- No revival = full death, respawn at last checkpoint

---

### 7. Story System
12 story fragments unlock as you defeat bosses and progress through levels.
Displayed as typewriter-style chat dialogue.

Story arc summary:
- Fragment 1–3: Ava wakes up with no memories; Rex the mutant dog finds her
- Fragment 4–6: They learn about Project APEX — government mutation program
- Fragment 7–8: Ava destroyed the lab herself to stop weaponization
- Fragment 9–12: The Dragon is the general; Rex carries the cure; final confrontation

NPC interactions via right-clicking **Lecterns** placed in the world.

---

## ⚙️ Configuration

All game values are exposed in `config.yml`:
- Class stats (health, speed, cooldowns)
- Power attributes (damage, range, duration)
- Boss health and phase thresholds
- Level spawn coordinates
- Skill tree costs and bonuses
- Coop/revive timings
- Particle effect types

---

## 🔧 Setup Instructions

### Requirements
- Java 17+
- PaperMC 1.20.4+
- (Optional) Geyser-Spigot + Floodgate for Bedrock support

### Build
```bash
mvn clean package
```
Output: `target/DogApocalypse-1.0.0.jar`

### Install
1. Drop the JAR into your `plugins/` folder
2. Start the server — `plugins/DogApocalypse/config.yml` is generated
3. Edit `config.yml` to set your level spawn coordinates matching your world
4. Use `/level tp level_1` to verify spawn points
5. Place **Lectern** blocks in the world as NPC story triggers

### First Play
```
/class choose dog        ← become the Mutated Dog
/class choose fighter    ← become the Fighter
/class choose archer     ← become the Archer

/coop invite <friend>    ← form a party
/level start level_1     ← begin the first level (admin or party leader)

/dogskill list           ← view skill tree (Dog only)
/dogskill upgrade dash_upgrade

/dogpower info           ← check current absorbed power
/dogpower activate       ← activate power (or right-click Totem)
```

---

## 🌐 Geyser / Floodgate Compatibility
The plugin detects both at startup and logs their status.
All mechanics use standard Bukkit API compatible with Bedrock players via Geyser.
No Java-exclusive packets are used. Right-click detection works cross-platform.

---

## 📊 Performance Notes
- Enemy AI runs every **10 ticks** (0.5s) — not every tick
- Boss tick loop runs every **20 ticks** (1s)
- Checkpoint detection throttled in move events
- All data stored in per-player YAML files (no database required)
- Event-driven design throughout — no heavy synchronous loops
- BukkitRunnable used for all async/delayed tasks

---

## 📝 License
Free to use, modify, and distribute for non-commercial Minecraft servers.
