package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class ReviveCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public ReviveCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player reviver)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
        if (args.length < 1) {
            Player nearby = plugin.getReviveSystem().findNearbyDowned(reviver);
            if (nearby == null) reviver.sendMessage(MessageUtil.color("&7Nenhum jogador abatido por perto."));
            else plugin.getReviveSystem().progressRevive(reviver, nearby);
            return true;
        }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !plugin.getReviveSystem().isDown(target)) {
            reviver.sendMessage(MessageUtil.color("&cEsse jogador não está abatido.")); return true;
        }
        plugin.getReviveSystem().progressRevive(reviver, target);
        return true;
    }
}
