package com.dogapocalypse.story;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class DialogueManager {

    private final DogApocalypsePlugin plugin;
    private final List<StoryFragment> fragmentos = new ArrayList<>();
    private final Set<UUID> emDialogo = new HashSet<>();

    public DialogueManager(DogApocalypsePlugin plugin) {
        this.plugin = plugin;
        carregarFragmentos();
    }

    private void carregarFragmentos() {

        fragmentos.add(new StoryFragment(0, "&d[Fragmento 1]", new String[]{
            "&7Uma jovem jaz inconsciente entre as ruínas...",
            "&7O mundo ao redor dela é irreconhecível.",
            "&7Criaturas mutantes perambulam pelas ruas.",
            "&7Ela perdeu todas as suas memórias.",
            "&6Um cachorro — igualmente mutado, igualmente perdido — a encontra."
        }));

        fragmentos.add(new StoryFragment(1, "&d[Fragmento 2]", new String[]{
            "&7O cachorro circula ao redor da garota, protetor e cauteloso.",
            "&7Algo em sua mente mutada a reconhece.",
            "&7Um vínculo se forma além da razão.",
            "&cO que quer que nos tenha feito assim... vai pagar."
        }));

        fragmentos.add(new StoryFragment(2, "&d[Fragmento 3]", new String[]{
            "&7Flashes: um laboratório, gritos, jalecos brancos.",
            "&7Uma máquina que muta seres vivos.",
            "&7Um acidente — ou foi intencional?"
        }));

        fragmentos.add(new StoryFragment(3, "&d[Fragmento 4]", new String[]{
            "&7A garota começa a lembrar fragmentos de um nome.",
            "&7&oAva... meu nome é Ava.",
            "&7O cachorro empurra sua mão suavemente.",
            "&6Ela o chama de Rex."
        }));

        fragmentos.add(new StoryFragment(4, "&d[Fragmento 5]", new String[]{
            "&7A cidade que chamavam de lar agora é um deserto.",
            "&7Máquinas de guerra patrulham as ruínas.",
            "&7Os gorilas do laboratório perambulam livremente.",
            "&cAlguém desencadeou tudo isso."
        }));

        fragmentos.add(new StoryFragment(5, "&d[Fragmento 6]", new String[]{
            "&7Um sobrevivente conta a Ava sobre o Projeto APEX.",
            "&7Um programa governamental. Mutação como arma.",
            "&7Rex era o protótipo deles.",
            "&6E Ava... Ava era a cientista que o criou."
        }));

        fragmentos.add(new StoryFragment(6, "&d[Fragmento 7]", new String[]{
            "&7O acidente não foi um acidente.",
            "&7Ava destruiu o laboratório ela mesma.",
            "&7Para impedi-los de usar Rex como arma.",
            "&7Ela pagou o preço com suas memórias."
        }));

        fragmentos.add(new StoryFragment(7, "&d[Fragmento 8]", new String[]{
            "&7As mutações de Rex não são aleatórias.",
            "&7Ele absorve a essência de outros mutantes.",
            "&7Porque Ava o projetou dessa forma.",
            "&6Ele sempre foi destinado a ser a cura."
        }));

        fragmentos.add(new StoryFragment(8, "&d[Fragmento 9]", new String[]{
            "&7No fundo das ruínas de guerra está a última máquina.",
            "&7Se ela ativar, a mutação se espalhará pelo mundo inteiro.",
            "&cAlguém está reconstruindo o Projeto APEX."
        }));

        fragmentos.add(new StoryFragment(9, "&d[Fragmento 10]", new String[]{
            "&7O Dragão... era o general.",
            "&7O homem que financiou o projeto.",
            "&7Se mutou para sobreviver ao apocalipse.",
            "&6Rex. É hora."
        }));

        fragmentos.add(new StoryFragment(10, "&d[Fragmento 11]", new String[]{
            "&7Ava lembra de tudo agora.",
            "&7A fórmula. A cura. O caminho para acabar com isso.",
            "&7Mas a máquina deve ser destruída primeiro.",
            "&cE o Dragão deve cair."
        }));

        fragmentos.add(new StoryFragment(11, "&d[Fragmento 12 — O Fim]", new String[]{
            "&7Com o Dragão derrotado, a máquina se apaga.",
            "&7Rex absorve o último da energia de mutação.",
            "&7Lentamente... o mundo começa a se curar.",
            "&6Ava olha para Rex, lágrimas nos olhos.",
            "&f&o\"Você nunca foi apenas um cachorro. Você era esperança.\"",
            "&8                — FIM —"
        }));
    }

    public void unlockNextFragment(Player player) {
        var data = plugin.getPlayerDataManager().get(player);
        int atual = data.getStoryFragments();
        if (atual >= fragmentos.size()) return;

        StoryFragment fragmento = fragmentos.get(atual);
        data.addStoryFragment();

        player.sendMessage(MessageUtil.color("&d[História] &fVocê encontrou um fragmento de memória..."));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HARP, 0.7f, 1.8f);

        new BukkitRunnable() {
            @Override public void run() { playDialogue(player, fragmento.titulo, fragmento.linhas); }
        }.runTaskLater(plugin, 20L);
    }

    public void showFragment(Player player, int index) {
        if (index < 0 || index >= fragmentos.size()) {
            player.sendMessage(MessageUtil.color("&cFragmento não encontrado."));
            return;
        }
        StoryFragment f = fragmentos.get(index);
        playDialogue(player, f.titulo, f.linhas);
    }

    public void playDialogue(Player player, String titulo, String[] linhas) {
        UUID uuid = player.getUniqueId();
        emDialogo.add(uuid);

        player.sendMessage(MessageUtil.color(""));
        player.sendMessage(MessageUtil.color("&8&m==========&r " + titulo + " &8&m=========="));

        new BukkitRunnable() {
            int i = 0;
            @Override public void run() {
                if (i >= linhas.length || !player.isOnline()) {
                    player.sendMessage(MessageUtil.color("&8&m====================================="));
                    emDialogo.remove(uuid);
                    cancel();
                    return;
                }
                player.sendMessage(MessageUtil.color(linhas[i]));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.3f, 1.2f);
                i++;
            }
        }.runTaskTimer(plugin, 10L, 25L);
    }

    public void triggerNPCDialogue(Player player, String npcId) {
        String[] linhas = switch (npcId.toLowerCase()) {
            case "survivor_1" -> new String[]{
                "&7&oEstranho... você não é um deles.",
                "&7&oO cachorro mutante... já ouvi falar.",
                "&7&oDizem que ele era a chave para parar tudo isso.",
                "&eFale com o cachorro. Encontre as ruínas. Vá para o norte."
            };
            case "scientist_ghost" -> new String[]{
                "&5&o[Eco de Memória] \"...a fórmula está dentro de Rex.\"",
                "&5&o\"Nós o projetamos para carregar a cura.\"",
                "&5&o\"Mas primeiro, a máquina deve arder.\""
            };
            case "final_gate" -> new String[]{
                "&cALÉM DESTE PONTO: O COVIL DO DRAGÃO",
                "&7Você está na entrada do fim.",
                "&7Rex rosna. Ava empunha sua arma.",
                "&6Você está pronto?"
            };
            default -> new String[]{ "&7..." };
        };

        playDialogue(player, "&7NPC", linhas);
    }

    public boolean isInDialogue(Player player) {
        return emDialogo.contains(player.getUniqueId());
    }

    private static class StoryFragment {
        final int index;
        final String titulo;
        final String[] linhas;
        StoryFragment(int index, String titulo, String[] linhas) {
            this.index = index; this.titulo = titulo; this.linhas = linhas;
        }
    }
}
