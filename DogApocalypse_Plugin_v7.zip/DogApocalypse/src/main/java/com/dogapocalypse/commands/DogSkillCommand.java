package com.dogapocalypse.commands;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.util.MessageUtil;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class DogSkillCommand implements CommandExecutor {
    private final DogApocalypsePlugin plugin;
    public DogSkillCommand(DogApocalypsePlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Apenas jogadores podem usar isso."); return true; }
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            plugin.getSkillTreeManager().showSkillTree(player); return true;
        }
        if (args[0].equalsIgnoreCase("upgrade") && args.length >= 2) {
            plugin.getSkillTreeManager().upgradeSkill(player, args[1].toLowerCase()); return true;
        }
        player.sendMessage(MessageUtil.color("&7Usage: &e/dogskill [list|upgrade <skill>]"));
        return true;
    }
}
