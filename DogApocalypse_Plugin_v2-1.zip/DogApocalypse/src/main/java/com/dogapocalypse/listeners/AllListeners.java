package com.dogapocalypse.listeners;

import com.dogapocalypse.core.DogApocalypsePlugin;
import com.dogapocalypse.classes.PlayerClass;
import com.dogapocalypse.util.MessageUtil;
import com.dogapocalypse.worldgen.WorldGenerator;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;

// =========================================================================
// PlayerJoinQuitListener
// =========================================================================

class PlayerJoinQuitListener implements Listener {
    private final DogApocalypsePlugin plugin;
    PlayerJoinQuitListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        var data = plugin.getPlayerDataManager().load(player.getUniqueId());
        plugin.getPlayerClassManager().applyClassStats(player, data.getPlayerClass());

        // BUG FIX: only enable flight if not already in creative/spectator
        if (data.getPlayerClass() == PlayerClass.DOG
                && player.getGameMode() == GameMode.SURVIVAL) {
            player.setAllowFlight(true);
            player.setFlying(false);
        }

        // Teleport to level world lobby if generated
        var wgen = plugin.getWorldGenerator();
        if (wgen.isGenerated() && wgen.getLevelWorld() != null
                && !player.getWorld().equals(wgen.getLevelWorld())) {
            player.teleport(new Location(wgen.getLevelWorld(), 8, 65, 8));
        }

        player.sendMessage(MessageUtil.color(
                "&8[&6DogApocalypse&8] &fWelcome! Class: "
                + data.getPlayerClass().getDisplayName()
                + "&f | SP: &e" + data.getSkillPoints()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getPlayerDataManager().save(player.getUniqueId());
        plugin.getDogPowerManager().cleanupPlayer(player);
        // BUG FIX: clean up coop state on disconnect
        plugin.getCoopManager().cleanupPlayer(player.getUniqueId());
        // BUG FIX: if player was downed, remove their downed state
        // (handled internally by ReviveSystem as entity dies)
    }
}

// =========================================================================
// CombatListener
// =========================================================================

class CombatListener implements Listener {
    private final DogApocalypsePlugin plugin;
    CombatListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        plugin.getCombatManager().applyClassDamageModifiers(event);
        if (event.getEntity() instanceof Player defender)
            plugin.getCombatManager().applyFighterBlock(event, defender);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        // BUG FIX: downed players take NO damage so revive state is preserved
        if (event.getEntity() instanceof Player p && plugin.getReviveSystem().isDown(p))
            event.setCancelled(true);
    }
}

// =========================================================================
// CoopListener
// =========================================================================

class CoopListener implements Listener {
    private final DogApocalypsePlugin plugin;
    CoopListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        // Don't intercept if already in downed state (prevent recursion)
        if (plugin.getReviveSystem().isDown(player)) return;

        var session = plugin.getLevelManager().getSessionByPlayer(player.getUniqueId());
        if (session == null) return; // normal death outside session

        // BUG FIX: cancel death and enter downed state BEFORE drops are cleared
        event.setCancelled(true);
        event.getDrops().clear();
        event.setDroppedExp(0);
        plugin.getReviveSystem().enterDownedState(player);
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        var data = plugin.getPlayerDataManager().get(player);
        String levelId = data.getCurrentLevel();

        Location respawnLoc = plugin.getCheckpointManager().getRespawnLocation(player, levelId);
        event.setRespawnLocation(respawnLoc);

        // BUG FIX: re-apply class stats 1 tick after respawn (inventory is reset on respawn)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            plugin.getPlayerClassManager().applyClassStats(player, data.getPlayerClass());
            if (data.getPlayerClass() == PlayerClass.DOG
                    && player.getGameMode() == GameMode.SURVIVAL) {
                player.setAllowFlight(true);
                player.setFlying(false);
            }
        }, 2L);
    }
}

// =========================================================================
// LevelListener — checkpoint detection (throttled)
// =========================================================================

class LevelListener implements Listener {
    private final DogApocalypsePlugin plugin;
    // BUG FIX: per-player cooldown map instead of a single shared counter
    private final java.util.Map<java.util.UUID, Integer> tickMap = new java.util.HashMap<>();

    LevelListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        // Only process if player moved to a different block
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        Player player = event.getPlayer();
        java.util.UUID uuid = player.getUniqueId();
        int tick = tickMap.merge(uuid, 1, Integer::sum);
        if (tick < 8) return;
        tickMap.put(uuid, 0);

        var data = plugin.getPlayerDataManager().get(player);
        plugin.getCheckpointManager().checkPlayerCheckpoints(player, data.getCurrentLevel());
    }
}

// =========================================================================
// BossListener
// =========================================================================

class BossListener implements Listener {
    private final DogApocalypsePlugin plugin;
    BossListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDeath(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof LivingEntity)) return;
        var uuid = event.getEntity().getUniqueId();
        if (!plugin.getBossManager().isBossEntity(uuid)) return;

        event.getDrops().clear();
        event.setDroppedExp(0);

        var participants = new java.util.ArrayList<>(
                event.getEntity().getWorld().getNearbyPlayers(
                        event.getEntity().getLocation(), 80));
        plugin.getBossManager().handleBossDeath(uuid, participants);
        checkLevelCompletion();
    }

    private void checkLevelCompletion() {
        for (String levelId : plugin.getLevelManager().getLevelIds()) {
            var session = plugin.getLevelManager().getSessionByLevel(levelId);
            if (session != null && session.bossSpawned && !session.completed) {
                plugin.getLevelManager().completeLevel(levelId);
                // Unlock story fragment for each participant
                session.participants.forEach(uuid -> {
                    Player p = plugin.getServer().getPlayer(uuid);
                    if (p != null && p.isOnline())
                        plugin.getDialogueManager().unlockNextFragment(p);
                });
                break;
            }
        }
    }
}

// =========================================================================
// EnemyListener
// =========================================================================

class EnemyListener implements Listener {
    private final DogApocalypsePlugin plugin;
    EnemyListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDeath(EntityDeathEvent event) {
        var uuid = event.getEntity().getUniqueId();
        if (!plugin.getEnemyManager().isCustomEnemy(uuid)) return;
        event.getDrops().clear();
        event.setDroppedExp(0);
        Player killer = event.getEntity().getKiller();
        plugin.getEnemyManager().handleDeath(uuid, killer);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!event.getDamager().hasMetadata("da_enemy_type")) return;
        String typeId = event.getDamager().getMetadata("da_enemy_type")
                .stream().findFirst().map(m -> m.asString()).orElse("");
        // Mutant insect poisons on hit
        if ("mutant_insect".equals(typeId)) {
            player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.POISON, 40, 0, false, true));
        }
        // Infected wolf bleeds on hit (weakness)
        if ("infected_wolf".equals(typeId)) {
            player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                    org.bukkit.potion.PotionEffectType.WEAKNESS, 60, 0, false, true));
        }
    }
}

// =========================================================================
// StoryListener — lectern right-click triggers NPC dialogue
// =========================================================================

class StoryListener implements Listener {
    private final DogApocalypsePlugin plugin;
    StoryListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler
    public void onPlayerInteract(org.bukkit.event.player.PlayerInteractEvent event) {
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.LECTERN) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        // BUG FIX: don't open dialogue if player is already in one
        if (plugin.getDialogueManager().isInDialogue(player)) return;

        plugin.getDialogueManager().triggerNPCDialogue(player, "survivor_1");
    }
}

// =========================================================================
// PlayerMovementListener — revive progress tick
// =========================================================================

class PlayerMovementListener implements Listener {
    private final DogApocalypsePlugin plugin;
    private int globalTick = 0;

    PlayerMovementListener(DogApocalypsePlugin p) { plugin = p; }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        // BUG FIX: throttle to every 2 calls, not every 4, for smoother revive bar
        globalTick++;
        if (globalTick % 2 != 0) return;

        Player reviver = event.getPlayer();
        if (plugin.getReviveSystem().isDown(reviver)) return;

        Player downed = plugin.getReviveSystem().findNearbyDowned(reviver);
        if (downed != null) plugin.getReviveSystem().progressRevive(reviver, downed);
    }
}
